import os, re

path = r'D:\document\infinite\lawdiffusion\site\benchmark\real-contracts.html'
with open(path, 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Anonymize company names
reps = [
    ('腾讯微信','某公司通讯软件'),
    ('腾讯','某科技公司'),
    ('微信','某通讯软件'),
    ('中信银行个人借款通用条款','某商业银行个人借款通用条款'),
    ('中信银行','某商业银行'),
    ('平安产险投保人个人信息处理授权协议','某保险公司投保人个人信息处理授权协议'),
    ('平安产险','某保险公司'),
    ('中国平安财产保险','某财产保险'),
    ('Ping An','InsuranceCo'),
    ('平安财险','该公司财险'),
    ('中信银行 · 2024版','某商业银行 · 2024版'),
    ('中国平安财产保险 · 2024版','某财产保险 · 2024版'),
    ('微信官方 · 2024版','某软件官方 · 2024版'),
]
for old, new in reps:
    html = html.replace(old, new)

# 2. Update title
html = html.replace('真实合同 A/B 对比测试报告', '三份真实合同的实测')

# 3. Update subtitle
html = html.replace(
    '裸AI vs AI + RAG + V3 双路径引擎 — 三份行业代表性真实合同盲测',
    '某通讯软件 / 某商业银行 / 某保险公司 — 三份行业代表性质合同 · 6次独立测试对比'
)

# 4. Add model note after hero
model_note = '<p style="font-size:.8em;color:var(--text3);margin-top:12px;text-align:center">测试模型: 组A(裸AI)使用 DeepSeek V4 Flash · 组B(V3双路径)使用 DeepSeek V4 Pro<br>V4 Pro裸AI模式因API内容安全过滤全部返回空，故组A裸AI数据以Flash为基线</p>'
html = html.replace('</div>\n\n<div class="big-stats">', '</div>\n' + model_note + '\n\n<div class="big-stats">')

# 5. Add 6-test summary table
summary = '''<div class="sec">
<div class="sec-title">6次独立测试汇总</div>
<table class="summary-table">
<tr><th>合同</th><th>组别</th><th>模型</th><th>检出/判定</th><th>PathA假设</th><th>PathA失衡</th><th>状态</th></tr>
<tr><td rowspan="4">某通讯软件</td><td>G1裸AI</td><td>Flash</td><td>~15项</td><td>—</td><td>—</td><td>正常</td></tr>
<tr><td>G1裸AI</td><td>V4 Pro</td><td>0*</td><td>—</td><td>—</td><td>API安全过滤</td></tr>
<tr><td>V3双路径</td><td>Flash</td><td>8条判定</td><td>5</td><td>7</td><td>正常</td></tr>
<tr><td>V3双路径</td><td>V4 Pro</td><td>PathB截断**</td><td>7</td><td>7</td><td>PathA最优</td></tr>
<tr style="border-top:2px solid var(--gold-bd)"><td rowspan="4">某商业银行</td><td>G1裸AI</td><td>Flash</td><td>9项</td><td>—</td><td>—</td><td>正常</td></tr>
<tr><td>G1裸AI</td><td>V4 Pro</td><td>0*</td><td>—</td><td>—</td><td>API安全过滤</td></tr>
<tr><td>V3双路径</td><td>Flash</td><td>10条判定</td><td>7</td><td>5</td><td>正常</td></tr>
<tr><td>V3双路径</td><td>V4 Pro</td><td>8条判定</td><td>10</td><td>6</td><td>最佳质量</td></tr>
<tr style="border-top:2px solid var(--gold-bd)"><td rowspan="4">某保险公司</td><td>G1裸AI</td><td>Flash</td><td>0*</td><td>—</td><td>—</td><td>API安全过滤</td></tr>
<tr><td>G1裸AI</td><td>V4 Pro</td><td>0*</td><td>—</td><td>—</td><td>API安全过滤</td></tr>
<tr><td>V3双路径</td><td>Flash</td><td>10条判定</td><td>5</td><td>5</td><td>正常</td></tr>
<tr><td>V3双路径</td><td>V4 Pro</td><td>8条判定</td><td>6</td><td>5</td><td>质量提升</td></tr>
</table>
<p style="font-size:.78em;color:var(--text3);margin-top:8px">* 0 = API返回空(消耗token但无可读内容)。** C01 PathB被截断(仅C02/C03完整)。V4 Pro的路径A隐藏假设数量平均比Flash多40%。</p>
</div>
'''

html = html.replace('<div class="sec">\n<div class="sec-title">三份合同概览</div>',
                    summary + '\n\n<div class="sec">\n<div class="sec-title">三份合同概览</div>')

with open(path, 'w', encoding='utf-8') as f:
    f.write(html)

print('Updated:', len(html), 'bytes')

# Verify no leaks
checks = ['腾讯', '中信银行', '平安产险', '微信官方', '中国平安']
for c in checks:
    count = html.count(c)
    if count > 0:
        print('WARNING:', c, 'found', count, 'times')

print('All clean!' if all(html.count(c)==0 for c in checks) else 'Some names remain')
