import json

with open(r'C:\Users\infinite\Desktop\合同测试集二\all_results.json', 'r', encoding='utf-8') as f:
    contracts = json.load(f)

# Severity badges
def sev_badge(s):
    m = {'严重':'s','严重违规':'s','重要':'w','需关注':'i','合规':'c','违规':'w'}
    c = m.get(s, 'i')
    return '<span class="badge badge-%s">%s</span>' % (c, s)

def score_bar(s):
    w = s * 20
    color = '#e0556a' if s >= 4 else '#d4a853' if s >= 3 else '#5cb878'
    return '<span class="bar"><span class="bar-fill" style="width:%d%%;background:%s">%d</span></span>' % (w, color, s)

# Build comparison table rows for each contract
def build_g1_table(contract):
    rows = ''
    for item in contract['g1']:
        rows += '<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n' % (
            item['clause'], item['risk'], item['law'], sev_badge(item['severity']))
    return rows

def build_v3b_table(contract):
    rows = ''
    for item in contract['v3_pathB']:
        rows += '<tr><td>%s</td><td>%s%s</td><td>%s</td><td>%s</td></tr>\n' % (
            item['rule'], sev_badge(item['status']), score_bar(item['score']),
            item['finding'], item['score'])
    return rows

def build_v3a_assumptions(contract):
    items = contract['v3_pathA']['assumptions']
    return ''.join('<li>%s</li>\n' % a for a in items)

def build_v3a_imbalances(contract):
    items = contract['v3_pathA']['imbalances']
    rows = ''
    for item in items:
        rows += '<tr><td>%s</td><td>%s</td><td>%s</td></tr>\n' % (item['clause'], item['bias'], item['risk'])
    return rows

# Stats
total_g1 = sum(len(c['g1']) for c in contracts)
total_v3b = sum(len(c['v3_pathB']) for c in contracts)
total_v3a_imb = sum(len(c['v3_pathA']['imbalances']) for c in contracts)
total_v3a_ass = sum(len(c['v3_pathA']['assumptions']) for c in contracts)

html = '''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>真实合同 A/B 对比测试报告 — lawdiffusion.com</title>
<style>
:root {
  --bg:#0a0e14;--card:#12161e;--card2:#181c26;--text:#c8ccd4;--text2:#8b92a0;--text3:#5c6370;
  --gold:#d4a853;--gold2:#b8943a;--gold-bg:rgba(212,168,83,.08);--gold-bd:rgba(212,168,83,.2);
  --green:#5cb878;--green-bg:rgba(92,184,120,.08);
  --red:#e0556a;--red-bg:rgba(224,85,106,.08);
  --blue:#5c8edc;--blue-bg:rgba(92,142,220,.08);
  --border:#1e2430;--radius:10px;
}
*{margin:0;padding:0;box-sizing:border-box}
body{background:var(--bg);color:var(--text);font-family:"PingFang SC","Microsoft YaHei",sans-serif;line-height:1.7;-webkit-font-smoothing:antialiased}
.wrap{max-width:1100px;margin:0 auto;padding:48px 24px 80px}
.hero{text-align:center;padding:60px 0 48px}
.hero h1{font-size:2.2em;font-weight:800;letter-spacing:.04em;background:linear-gradient(135deg,var(--gold),#f0d78c);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hero .sub{font-size:1em;color:var(--text2);margin:12px 0}
.hero .meta{font-size:.82em;color:var(--text3)}
.hero .meta span{margin:0 12px}

.big-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:32px 0}
.bs{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:20px;text-align:center}
.bs .val{font-size:2.2em;font-weight:900;color:var(--gold)}
.bs .lbl{font-size:.78em;color:var(--text2);font-weight:600;letter-spacing:.04em}

.sec{margin:48px 0}
.sec-title{font-size:1.1em;font-weight:700;color:var(--gold);letter-spacing:.04em;margin-bottom:20px;padding-bottom:10px;border-bottom:1px solid var(--gold-bd)}

.contract-hero{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:28px 32px;margin:24px 0;display:flex;gap:24px;align-items:flex-start}
.contract-hero .ch-id{font-size:2em;font-weight:900;color:var(--gold);flex-shrink:0;width:60px}
.contract-hero .ch-body{flex:1}
.contract-hero .ch-name{font-size:1.3em;font-weight:700;color:var(--text);margin-bottom:6px}
.contract-hero .ch-meta{font-size:.8em;color:var(--text3);margin-bottom:8px}
.contract-hero .ch-meta span{margin-right:16px}
.contract-hero .ch-desc{font-size:.85em;color:var(--text2);line-height:1.7}

.cmp-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px;margin:20px 0}
.cmp-card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden}
.cmp-card .cmp-head{padding:16px 20px;font-weight:700;font-size:.9em;letter-spacing:.04em;border-bottom:1px solid var(--border)}
.cmp-card .cmp-head.g1{background:var(--blue-bg);color:var(--blue)}
.cmp-card .cmp-head.v3{background:var(--gold-bg);color:var(--gold)}
.cmp-card .cmp-body{padding:0}

table{width:100%;border-collapse:collapse;font-size:.82em}
th{background:var(--card2);color:var(--text3);font-weight:600;font-size:.72em;letter-spacing:.06em;padding:10px 14px;text-align:left;border-bottom:1px solid var(--border)}
td{padding:9px 14px;border-bottom:1px solid var(--border);color:var(--text2)}
.badge{display:inline-block;font-size:.7em;padding:2px 8px;border-radius:4px;font-weight:600}
.badge-s{background:var(--red-bg);color:var(--red)}
.badge-w{background:var(--gold-bg);color:var(--gold)}
.badge-i{background:var(--card2);color:var(--text3)}
.badge-c{background:var(--green-bg);color:var(--green)}

.bar{display:inline-block;width:50px;height:16px;background:var(--card2);border-radius:3px;overflow:hidden;vertical-align:middle;margin-left:6px}
.bar-fill{height:100%;display:flex;align-items:center;justify-content:center;font-size:.65em;font-weight:700;color:#fff;min-width:20px}

.v3-section{margin:16px 0;padding:0 20px}
.v3-section h5{font-size:.82em;font-weight:700;color:var(--gold);margin:16px 0 8px}
.v3-section ul{list-style:none;font-size:.82em;color:var(--text2)}
.v3-section li{padding:3px 0}
.v3-section li::before{content:'→';color:var(--gold);margin-right:8px}

.summary-table{margin:24px 0}
.summary-table td{text-align:center}
.summary-table td:first-child{text-align:left;font-weight:600;color:var(--text)}

.finding{background:var(--card);border-left:3px solid var(--gold);padding:20px 24px;margin:16px 0;border-radius:0 var(--radius) var(--radius) 0}
.finding h4{font-size:.9em;font-weight:700;color:var(--gold);margin-bottom:8px}
.finding p{font-size:.84em;color:var(--text2)}

.conclusion{background:linear-gradient(160deg,var(--card) 0%,rgba(212,168,83,.06) 100%);border:1px solid var(--gold-bd);border-radius:var(--radius);padding:32px;margin:32px 0}
.conclusion h3{color:var(--gold);margin-bottom:16px}

.footer{text-align:center;font-size:.75em;color:var(--text3);margin-top:60px;padding-top:30px;border-top:1px solid var(--border)}

@media(max-width:768px){.cmp-grid{grid-template-columns:1fr}.big-stats{grid-template-columns:repeat(2,1fr)}.contract-hero{flex-direction:column}}
</style>
</head>
<body>
<div class="wrap">

<div class="hero">
<h1>真实合同 A/B 对比测试报告</h1>
<p class="sub">裸AI vs AI + RAG + V3 双路径引擎 — 三份行业代表性真实合同盲测</p>
<p class="meta"><span>测试日期: 2026-06-26</span><span>合同总字数: 24,127字</span><span>模型: DeepSeek V4 Flash</span></p>
</div>

<div class="big-stats">
<div class="bs"><div class="val">3</div><div class="lbl">行业代表性合同</div></div>
<div class="bs"><div class="val">''' + str(total_g1) + '''</div><div class="lbl">裸AI检出总风险</div></div>
<div class="bs"><div class="val">''' + str(total_v3b) + '''</div><div class="lbl">V3 规则逐项判定</div></div>
<div class="bs"><div class="val">''' + str(total_v3a_imb + total_v3a_ass) + '''</div><div class="lbl">V3 系统性发现</div></div>
</div>

<div class="sec">
<div class="sec-title">三份合同概览</div>
<table class="summary-table">
<tr><th>合同</th><th>行业</th><th>字数</th><th>段落</th><th>裸AI检出</th><th>V3规则判定</th><th>V3路径A失衡</th><th>合规率</th></tr>
'''
for c in contracts:
    g1n = len(c['g1'])
    v3b = c['v3_pathB']
    v3b_total = len(v3b)
    v3b_comp = sum(1 for r in v3b if r['status'] in ('合规',))
    v3a_imb = len(c['v3_pathA']['imbalances'])
    html += '<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s/%s</td></tr>\n' % (
        c['name'][:18], c['type'], '{:,}'.format(c['chars']), c['paragraphs'],
        g1n, v3b_total, v3a_imb, v3b_comp, v3b_total)

html += '''</table>
</div>
'''

# Per-contract detail
for c in contracts:
    g1n = len(c['g1'])
    v3b = c['v3_pathB']
    v3b_comp = sum(1 for r in v3b if r['status'] in ('合规',))
    v3b_viol = sum(1 for r in v3b if r['status'] in ('违规','严重违规'))
    v3a_imb = len(c['v3_pathA']['imbalances'])
    v3a_ass = len(c['v3_pathA']['assumptions'])

    html += '''
<div class="sec">
<div class="contract-hero">
<div class="ch-id">''' + c['id'] + '''</div>
<div class="ch-body">
<div class="ch-name">''' + c['name'] + '''</div>
<div class="ch-meta"><span>''' + c['type'] + '''</span><span>''' + c['source'] + '''</span><span>''' + '{:,}'.format(c['chars']) + '''字</span><span>''' + str(c['paragraphs']) + '''段</span></div>
<div class="ch-desc">''' + c['desc'] + '''</div>
</div>
</div>

<div class="cmp-grid">
<!-- GROUP A: BARE AI -->
<div class="cmp-card">
<div class="cmp-head g1">组A · 裸AI — ''' + str(g1n) + '''项检出</div>
<div class="cmp-body">
<table>
<tr><th>条款</th><th>风险</th><th>法条</th><th>严重度</th></tr>
''' + build_g1_table(c) + '''
</table>
</div>
</div>

<!-- GROUP B: V3 -->
<div class="cmp-card">
<div class="cmp-head v3">组B · +RAG+V3 双路径 — ''' + str(v3b_comp) + '''合规 + ''' + str(v3b_viol) + '''违规</div>
<div class="cmp-body">
<table>
<tr><th>审查规则</th><th>判定</th><th>发现</th><th>分</th></tr>
''' + build_v3b_table(c) + '''
</table>
</div>
</div>
</div>

<!-- V3 Path A: Hidden Assumptions & Systemic Imbalances -->
<div class="cmp-card" style="margin-top:16px">
<div class="cmp-head v3">V3 路径A · 知识域自述 — ''' + str(v3a_ass) + '''个隐藏假设 + ''' + str(v3a_imb) + '''项系统性失衡</div>
<div class="v3-section">
<h5>隐藏假设（协议默认成立但未明说的前提）</h5>
<ul>''' + build_v3a_assumptions(c) + '''</ul>

<h5>系统性利益失衡</h5>
<table>
<tr><th>条款</th><th>偏向性</th><th>风险</th></tr>
''' + build_v3a_imbalances(c) + '''
</table>
</div>
</div>
</div>
'''

# Final summary
html += '''
<div class="sec">
<div class="sec-title">结论：V3 双路径引擎在三份真实合同上的核心优势</div>

<div class="finding">
<h4>发现 1 · V3 做到了裸AI做不到的事——区分合规与违规</h4>
<p>裸AI倾向于把所有「看起来不公平的条款」都标成违规。V3路径B基于预设审查规则逐项判定，正确区分了：微信TOS的格式条款提示是合规的，中信银行的罚息1.5倍在法定范围内，平安产险的告知同意框架基本合规。<strong>真正的违规需要精准定位，而不是一刀切全标红。</strong></p>
</div>

<div class="finding">
<h4>发现 2 · 路径A暴露了裸AI完全看不到的东西——隐藏假设</h4>
<p>三份合同共暴露了<span style="color:var(--gold)">''' + str(total_v3a_ass) + '''个隐藏假设</span>。这些假设是协议设计的底层逻辑——「用户已完整阅读理解所有条款」「银行单方决定具有终局性」「继续使用即同意变更」——它们是系统性偏误的根源，但裸AI只能逐条找违规，看不到这个层次。</p>
</div>

<div class="finding">
<h4>发现 3 · 三份合同的合规水平存在明显梯度</h4>
<p>平安产险(5/10合规) > 中信银行(3/10合规) > 腾讯微信(2/8合规)。这个排序符合行业预期——保险业受到更严格的个人信息保护监管，银行次之，互联网平台最宽松。V3的规则判定能客观反映这个梯度，而裸AI只能给出「一堆违规」的平面结论。</p>
</div>

<div class="finding">
<h4>发现 4 · 每一项「严重违规」判定背后都有精确的法条锚点</h4>
<p>微信TOS的单方修改权(电子商务法第34条)、中信银行的最终解释权(消保法第26条)、平安产险的敏感信息无单独同意(个保法第28/29条)——这三项被V3判为严重违规(风险分5分)，各自指向明确的法律强制性规定。<strong>它们是「如果被起诉，法院几乎肯定会判无效」的条款。</strong></p>
</div>

<div class="finding">
<h4>发现 5 · V3的多出成本(2x API调用)换来了什么</h4>
<p>每份合同多花1次API调用(V3路径A+路径B = 2次 vs 裸AI = 1次)。换来了：①''' + str(total_v3a_ass) + '''个隐藏假设的暴露 ②''' + str(total_v3b) + '''条规则的结构化合规判定 ③''' + str(total_v3a_imb) + '''项系统性利益失衡分析 ④裸AI完全无法提供的风险评分和修改建议。<strong>对于需要做出商业决策的合同审查，这2x成本的价值远大于1x。</strong></p>
</div>
</div>

<div class="conclusion">
<h3>测试方法论说明</h3>
<p style="font-size:.84em;color:var(--text2);line-height:1.8">
<strong>公平性保障：</strong>三份合同均未向AI提供任何风险标注或提示。裸AI和V3接收的是同一份合同原文。V3的审查规则是通用的法律合规检查点(个人信息保护法、民法典、电子商务法等)，不是针对特定合同预制的。<br><br>
<strong>局限性声明：</strong>①测试合同为简体中文法律文本，AI在英文/普通法系合同上的表现未经验证。②DeepSeek V4 Flash的训练数据截止日期未知，引用的法条可能不是最新版本。③本测试不构成法律意见，AI产出不能替代律师的专业判断。<br><br>
<strong>测试模型：</strong>DeepSeek V4 Flash (via lawdiffusion.com /api/call) · 2026-06-26
</p>
</div>

<div class="footer">
<p>直觉引导 · lawdiffusion.com | 真实合同 A/B 对比测试</p>
<p>引擎版本: contract-engine v3.0 + contract-masks v1.1 | 专利保护: 基于多蒙版动态激活的法律文书风险识别方法及系统(申请中)</p>
</div>

</div>
</body>
</html>'''

with open(r'C:\Users\infinite\Desktop\合同测试集二\real_contract_report.html', 'w', encoding='utf-8') as f:
    f.write(html)
print('Report generated:', len(html), 'bytes')
print('Contracts:', len(contracts))
