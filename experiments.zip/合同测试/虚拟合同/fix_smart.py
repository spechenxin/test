#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Fix gen_answers.py by checking each line individually"""

import re

def fix_inner(s):
    positions = [i for i, c in enumerate(s) if c == '"']
    if len(positions) < 4:
        return s
    chars = list(s)
    keep = {positions[0], positions[-1]}
    inner = [p for p in positions if p not in keep]
    for i, p in enumerate(inner):
        chars[p] = '\u300c' if i % 2 == 0 else '\u300d'
    return ''.join(chars)

def is_valid_python(line):
    """Check if a line is valid Python by itself"""
    try:
        compile(line.strip(), '<test>', 'eval')
        return True
    except SyntaxError:
        pass
    try:
        compile(line.strip(), '<test>', 'exec')
        return True
    except SyntaxError:
        return False

with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Restore original
content = ''.join(lines)
content = content.replace('\u300c', '"').replace('\u300d', '"')
lines = content.split('\n')
lines = [l + '\n' for l in lines[:-1]] + ([lines[-1]] if lines[-1] else [])

fixed = []
for line in lines:
    s = line.strip()
    if not s:
        fixed.append(line)
        continue

    cnt = line.count('"')
    if cnt < 4:
        fixed.append(line)
        continue

    if is_valid_python(line):
        # Line is already valid - leave as is
        fixed.append(line)
        continue

    # Line has syntax issues - fix inner quotes
    fixed.append(fix_inner(line))

with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'w', encoding='utf-8') as f:
    f.writelines(fixed)

# Verify
with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'r', encoding='utf-8') as f:
    try:
        compile(f.read(), 'gen_answers.py', 'exec')
        print('SUCCESS: File compiles!')
    except SyntaxError as e:
        print(f'Syntax error at line {e.lineno}: {e.msg}')
