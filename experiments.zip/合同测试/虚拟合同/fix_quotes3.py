#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Fix Chinese quotation marks v3 - smarter delimiter detection"""

import re

def fix_line(line):
    positions = [i for i, c in enumerate(line) if c == '"']
    if len(positions) < 4:
        return line

    chars = list(line)
    cjk_pattern = re.compile(r'[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]')

    # A " is a Python delimiter if:
    # - It's followed by [,:)\]] or whitespace+[,:)\]]  (closing delimiter)
    # - It's preceded by [(,\[=] or whitespace+[(,\[=]  (opening delimiter)
    def is_python_delimiter(pos):
        next_ch = chars[pos+1] if pos < len(chars)-1 else ''
        prev_ch = chars[pos-1] if pos > 0 else ''

        # Closing delimiter: " followed by , ) ] : or end-of-line
        if next_ch in ',):]\n' or pos == len(chars)-1:
            return True
        if next_ch == '':
            return True

        # Opening delimiter: " preceded by ( , [ = : or newline
        if prev_ch in '([,=:\n\t ':
            return True

        return False

    # Find inner quotes: adjacent to CJK AND not a Python delimiter
    inner_positions = []
    for pos in positions:
        if is_python_delimiter(pos):
            continue
        prev_ch = chars[pos-1] if pos > 0 else ''
        next_ch = chars[pos+1] if pos < len(chars)-1 else ''
        prev_cjk = bool(cjk_pattern.match(prev_ch))
        next_cjk = bool(cjk_pattern.match(next_ch))
        if prev_cjk or next_cjk:
            inner_positions.append(pos)

    if len(inner_positions) < 2:
        return line

    for i, pos in enumerate(inner_positions):
        if i % 2 == 0:
            chars[pos] = '\u300c'
        else:
            chars[pos] = '\u300d'

    return ''.join(chars)


with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Undo all previous fixes
content = ''.join(lines)
content = content.replace('\u300c', '"').replace('\u300d', '"')
lines = content.split('\n')
lines = [l + '\n' for l in lines[:-1]] + ([lines[-1]] if lines[-1] else [])

skipped_prefixes = (
    '"""', '#', 'def ', 'import ', 'from ', 'for ', 'if ', 'elif ',
    'h =', 'add_', 'p ', 'p2', 'p3', 'p4', 'run ', 'output_', 'doc.',
    'print(', 'with ', 'return', 'else', 'try', 'except', 'finally',
    'style', 'font', 'content', 'h.alignment', 'ans[',
)

fixed = []
for line in lines:
    stripped = line.strip()

    if not stripped:
        fixed.append(line)
        continue

    if any(stripped.startswith(p) for p in skipped_prefixes):
        fixed.append(line)
        continue

    # Dict key-value lines
    if re.match(r'^\s*"[^"]+"\s*:', stripped):
        fixed.append(line)
        continue

    fixed.append(fix_line(line))

with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'w', encoding='utf-8') as f:
    f.writelines(fixed)

print('Fixed v3')
