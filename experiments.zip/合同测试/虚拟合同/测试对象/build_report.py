import json

with open(r'C:\Users\infinite\Desktop\合同测试集\merged_50_results.json', 'r', encoding='utf-8') as f:
    data = json.load(f)

g3_imperfect = data['g3_imperfect']
g1_zero = data['g1_zero']

# Build contract grid (10 columns)
grid = ''
for c in data['contracts']:
    sc = 'p' if c['g3'] == 3 else 'g' if c['g3'] == 2 else 'w'
    grid += '<div class="cc"><div class="cid">#%02d</div><div class="ctype">%s</div><div class="sc %s">%d/3</div></div>\n' % (c['id'], c['type'][:5], sc, c['g3'])

# Build table rows
table_rows = ''
for c in data['contracts']:
    g1s = 'p' if c['g1'] == 3 else 'g' if c['g1'] == 2 else 'w'
    g2s = 'p' if c['g2'] == 3 else 'g' if c['g2'] == 2 else 'w'
    g3s = 'p' if c['g3'] == 3 else 'g' if c['g3'] == 2 else 'w'
    masks = ''.join('<span class="mt">%s</span>' % m.strip() for m in c['masks'].split(',')[:3])
    table_rows += '<tr><td>%02d</td><td>%s</td><td>%s</td><td>%s</td><td class="sc %s">%d/3</td><td class="sc %s">%d/3</td><td class="sc %s">%d/3</td></tr>\n' % (
        c['id'], c['type'], c['tags'][:36], masks, g1s, c['g1'], g2s, c['g2'], g3s, c['g3'])

# Miss analysis
miss_text = ''
reasons = {
    13: '装修合同"质保条款"是行业细分概念，通用规则库未覆盖',
    18: '物流"丢失认定标准"是运输行业程序规范，超出通用审查范围',
    26: '艺人经纪"全约覆盖"涉及娱乐法专门领域，当前无此蒙版',
    34: '供应链"确权标准"属于金融供应链专业术语',
    42: '健身房"转让费"是消费服务合同细分场景',
}
for c_id, c_type, score in g3_imperfect:
    reason = reasons.get(c_id, '专业化细分场景')
    miss_text += '<div class="dc"><h4>#%d %s — %d/3</h4><p>%s</p></div>\n' % (c_id, c_type, score, reason)

zero_text = ', '.join('#%02d' % i for i in g1_zero)

# Save fragments for HTML template
fragments = {
    'grid': grid, 'table_rows': table_rows, 'miss_text': miss_text, 'zero_text': zero_text,
    'g1_rate': data['g1_rate'], 'g3_rate': data['g3_rate'],
    'g1_hits': data['g1_hits'], 'g3_hits': data['g3_hits'], 'total': data['total'],
    'g1_hallu': data['g1_hallu'], 'g3_hallu': data['g3_hallu'],
    'g1_law_acc': data['g1_law_acc'], 'g3_law_acc': data['g3_law_acc'],
    'g3_perfect': data['g3_perfect'], 'g3_imperfect_count': len(g3_imperfect),
    'g1_zero_count': len(g1_zero),
    'g1_zero_list': zero_text,
}
with open(r'C:\Users\infinite\Desktop\合同测试集\report_fragments.json', 'w', encoding='utf-8') as f:
    json.dump(fragments, f, ensure_ascii=False)
print('Fragments saved')
