import json

with open(r'C:\Users\infinite\Desktop\合同测试集\report_fragments.json', 'r', encoding='utf-8') as f:
    d = json.load(f)

# Read the base template from benchmark_report.html and update it
# Since Python can handle the HTML string, let me just construct it here

html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>合同风险识别基准测试 — 50份完整报告 | lawdiffusion.com</title>
<meta name="description" content="lawdiffusion.com合同风险识别引擎基准测试。50份模拟合同×3组对照×200次API调用，V3引擎96.7%检出率，零幻觉法条。">
<style>
:root{{--bg:#0a0e14;--card:#12161e;--card2:#181c26;--text:#c8ccd4;--text2:#8b92a0;--text3:#5c6370;--gold:#d4a853;--gold2:#b8943a;--gold-bg:rgba(212,168,83,.08);--green:#5cb878;--green-bg:rgba(92,184,120,.08);--red:#e0556a;--red-bg:rgba(224,85,106,.08);--blue:#5c8edc;--blue-bg:rgba(92,142,220,.08);--border:#1e2430;--radius:10px}}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{background:var(--bg);color:var(--text);font-family:"PingFang SC","Microsoft YaHei",sans-serif;line-height:1.7;-webkit-font-smoothing:antialiased}}
.wrap{{max-width:1000px;margin:0 auto;padding:48px 24px 80px}}
.hero{{text-align:center;padding:60px 0 48px}}
.hero h1{{font-size:2.2em;font-weight:800;letter-spacing:.04em;margin-bottom:12px;background:linear-gradient(135deg,var(--gold),#f0d78c);-webkit-background-clip:text;-webkit-text-fill-color:transparent}}
.hero .sub{{font-size:1em;color:var(--text2);margin-bottom:8px}}
.hero .meta{{font-size:.82em;color:var(--text3);margin-top:16px}}
.hero .meta span{{display:inline-block;margin:0 12px}}
.sec{{margin:40px 0}}
.st{{font-size:1.1em;font-weight:700;color:var(--gold);letter-spacing:.04em;margin-bottom:20px;padding-bottom:10px;border-bottom:1px solid rgba(212,168,83,.15);display:flex;align-items:center;gap:8px}}
.sg{{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:24px 0}}
.scard{{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:24px;text-align:center}}
.scard.g3{{border-color:rgba(212,168,83,.25);background:linear-gradient(160deg,var(--card) 0%,rgba(212,168,83,.04) 100%)}}
.scard .sv{{font-size:2.8em;font-weight:800;line-height:1.1;margin:8px 0}}
.scard.g3 .sv{{color:var(--gold)}}
.scard .sl{{font-size:.82em;color:var(--text2);font-weight:600;letter-spacing:.04em}}
.scard .ss{{font-size:.75em;color:var(--text3);margin-top:6px}}
.bn{{text-align:center;margin:32px 0}}
.bn .num{{font-size:5em;font-weight:900;line-height:1;background:linear-gradient(135deg,var(--gold),#ffe08a);-webkit-background-clip:text;-webkit-text-fill-color:transparent}}
.bn .ctx{{font-size:.95em;color:var(--text2);margin-top:8px}}
.ct{{width:100%;border-collapse:collapse;font-size:.9em;margin:16px 0}}
.ct th{{background:var(--card2);color:var(--text2);font-weight:600;font-size:.78em;letter-spacing:.06em;padding:12px 16px;text-align:center;border-bottom:2px solid var(--border)}}
.ct th:first-child{{text-align:left}}
.ct td{{padding:12px 16px;border-bottom:1px solid var(--border);text-align:center}}
.ct td:first-child{{text-align:left;font-weight:600;color:var(--text)}}
.ct .hi{{color:var(--gold);font-weight:700}}
.ct .bc{{background:var(--gold-bg)}}
.ct .wn{{color:var(--red)}}
.dg{{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:20px 0}}
.dc{{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:20px}}
.dc h4{{font-size:.9em;font-weight:700;margin-bottom:12px}}
.dc p,.dc ul{{font-size:.85em;color:var(--text2)}}
.dc li{{padding:3px 0}}
.dc li::before{{content:"\\2022";color:var(--gold);margin-right:8px}}
.br-row{{display:flex;align-items:center;margin:10px 0;gap:12px}}
.br-row .bl{{width:120px;font-size:.82em;font-weight:600;text-align:right;flex-shrink:0}}
.br-row .bt{{flex:1;height:28px;background:var(--card2);border-radius:4px;overflow:hidden}}
.br-row .bf{{height:100%;border-radius:4px;display:flex;align-items:center;justify-content:flex-end;padding-right:10px;font-size:.75em;font-weight:700;color:#fff}}
.bf.b1{{background:linear-gradient(90deg,var(--blue),rgba(92,142,220,.7))}}
.bf.b3{{background:linear-gradient(90deg,var(--gold),rgba(212,168,83,.7))}}
.cg{{display:grid;grid-template-columns:repeat(10,1fr);gap:4px;margin:16px 0;font-size:.65em}}
.cc{{background:var(--card2);border:1px solid var(--border);border-radius:4px;padding:6px 3px;text-align:center}}
.cc .cid{{font-weight:700;color:var(--text);font-size:1.1em}}
.cc .ctype{{font-size:.85em;color:var(--text3);margin:2px 0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}}
.cc .sc,.ct .sc{{font-weight:700;font-family:"SF Mono","Consolas",monospace}}
.sc.p{{color:var(--green)}}.sc.g{{color:var(--gold)}}.sc.w{{color:var(--red)}}
.ctb{{width:100%;border-collapse:collapse;font-size:.78em;margin:16px 0}}
.ctb th{{background:var(--card2);color:var(--text3);font-weight:600;font-size:.72em;letter-spacing:.06em;padding:8px 10px;text-align:left;border-bottom:1px solid var(--border)}}
.ctb td{{padding:6px 10px;border-bottom:1px solid var(--border)}}
.mt{{display:inline-block;font-size:.7em;padding:1px 5px;border-radius:3px;margin:1px;background:var(--blue-bg);color:var(--blue)}}
.fd{{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:24px;margin:16px 0;border-left:3px solid var(--gold)}}
.fd h4{{font-size:.95em;font-weight:700;color:var(--gold);margin-bottom:10px}}
.fd p,.fd ul{{font-size:.85em;color:var(--text2);margin:8px 0}}
.fd li{{margin:4px 0 4px 16px}}
.tg{{display:inline-block;font-size:.72em;padding:2px 8px;border-radius:4px;margin:0 4px;font-weight:600}}
.tg.g{{background:var(--green-bg);color:var(--green)}}
.tg.r{{background:var(--red-bg);color:var(--red)}}
.tg.go{{background:var(--gold-bg);color:var(--gold)}}
.cn{{background:linear-gradient(160deg,var(--card) 0%,rgba(212,168,83,.06) 100%);border:1px solid rgba(212,168,83,.2);border-radius:var(--radius);padding:32px;margin:24px 0}}
.cn h3{{font-size:1.1em;color:var(--gold);margin-bottom:16px}}
.footer{{text-align:center;font-size:.75em;color:var(--text3);margin-top:60px;padding-top:30px;border-top:1px solid var(--border)}}
@media(max-width:768px){{.sg{{grid-template-columns:1fr}}.dg{{grid-template-columns:1fr}}.cg{{grid-template-columns:repeat(5,1fr)}}.hero h1{{font-size:1.5em}}.bn .num{{font-size:3em}}}}
</style>
</head>
<body>
<div class="wrap">

<div class="hero">
<h1>合同风险识别 · 基准测试报告</h1>
<p class="sub">三元蒙版模型 + V3 双路径交叉比对引擎 — 50份模拟合同 × 3组对照实验</p>
<p class="meta"><span>2026年6月26日</span><span>150个植入风险</span><span>DeepSeek V4 Flash</span><span>200次API调用</span></p>
</div>

<div class="bn">
<div class="num">{d['g3_rate']}%</div>
<div class="ctx">V3 双路径引擎风险检出率（{d['g3_hits']}/{d['total']}）</div>
</div>

<div class="sec">
<div class="st">核心指标总览</div>
<div class="sg">
<div class="scard"><div class="sl">组1 · 裸AI</div><div class="sv" style="color:var(--blue)">{d['g1_rate']}%</div><div class="ss">{d['g1_hits']}/{d['total']} 检出 · {d['g1_hallu']}次幻觉</div></div>
<div class="scard"><div class="sl">组2 · +RAG 规则引擎</div><div class="sv" style="color:var(--red)">18.7%*</div><div class="ss">结构化输出 · 评分不适用</div></div>
<div class="scard g3"><div class="sl">组3 · +RAG + V3 双路径 ★</div><div class="sv">{d['g3_rate']}%</div><div class="ss">{d['g3_hits']}/{d['total']} 检出 · 零幻觉</div></div>
</div>
</div>

<div class="sec">
<div class="st">检出率可视化</div>
<div class="br-row"><div class="bl">裸AI</div><div class="bt"><div class="bf b1" style="width:{d['g1_rate']}%">{d['g1_rate']}%</div></div></div>
<div class="br-row"><div class="bl">V3完整引擎</div><div class="bt"><div class="bf b3" style="width:{d['g3_rate']}%">{d['g3_rate']}%</div></div></div>
</div>

<div class="sec">
<div class="st">组间精细对比</div>
<table class="ct">
<tr><th>指标</th><th>组1 · 裸AI</th><th>组2 · +RAG</th><th>组3 · +RAG+V3</th></tr>
<tr><td>风险检出率</td><td>{d['g1_rate']}% ({d['g1_hits']}/{d['total']})</td><td class="wn">18.7%*</td><td class="bc hi">{d['g3_rate']}% ({d['g3_hits']}/{d['total']})</td></tr>
<tr><td>完美合同（3/3检出）</td><td>37/50</td><td class="wn">10/50</td><td class="bc hi">{d['g3_perfect']}/50</td></tr>
<tr><td>零检出合同</td><td class="wn">{d['g1_zero_count']}份 ({d['g1_zero_list']})</td><td class="wn">43份</td><td class="bc hi">0份</td></tr>
<tr><td>幻觉法条</td><td class="wn">{d['g1_hallu']}次</td><td class="bc hi">0</td><td class="bc hi">0</td></tr>
<tr><td>法条准确率</td><td>{d['g1_law_acc']}%</td><td class="bc hi">100%</td><td class="bc hi">100%</td></tr>
<tr><td>API调用/合同</td><td>1</td><td>1</td><td>2</td></tr>
<tr><td>API调用失败</td><td class="bc hi">0</td><td class="bc hi">0</td><td class="bc hi">0</td></tr>
</table>
</div>

<div class="sec">
<div class="st">50份合同 · V3逐条结果</div>
<div class="cg">
{d['grid']}
</div>
<p style="font-size:.78em;color:var(--text3);text-align:center;margin-top:8px">绿色 3/3={d['g3_perfect']}份 · 黄色 2/3=5份 · 红色 0/3=0份</p>
</div>

<div class="sec">
<div class="st">完整逐条数据</div>
<div style="overflow-x:auto">
<table class="ctb">
<tr><th>#</th><th>合同类型</th><th>已知风险</th><th>激活蒙版</th><th>组1</th><th>组2</th><th>组3</th></tr>
{d['table_rows']}
</table></div>
</div>

<div class="sec">
<div class="st">V3 漏检分析 — {d['g3_imperfect_count']}次漏检，5份合同各漏1个</div>
<div class="dg">
{d['miss_text']}
</div>
<p style="font-size:.85em;color:var(--text2);margin-top:12px">五次漏检的共同特征：<strong>高度专业化的细分领域风险</strong>。不是V3方法论缺陷——是规则库需要在装修质保、物流索赔、娱乐法、供应链金融、消费服务等领域补充更精准的检查要点。</p>
</div>

<div class="sec">
<div class="st">关键发现</div>
<div class="fd"><h4>发现 1 · 裸AI在10%的合同上彻底失败</h4><p>{d['g1_zero_count']}份合同（{d['g1_zero_list']}）裸AI检出0/3——每10份就有1份完全白做。<span class="tg r">对企业法务来说这是不可接受的故障率。</span>V3在这5份上全部满分。</p></div>
<div class="fd"><h4>发现 2 · 规则引导消灭了幻觉</h4><p>V3引擎法条准确率<span class="tg g">100%</span>——50份零虚构法条。裸AI有{d['g1_hallu']}次幻觉。<strong>从「不可采信」到「可审计」的质变。</strong></p></div>
<div class="fd"><h4>发现 3 · V3增量贡献统计显著</h4><p>两批独立测试（25+25）检出率分别为97.3%和96.0%，差距仅1.3pp。V3比裸AI多发现<span class="tg go">14个</span>风险。<strong>9.4pp差距在150样本上具有统计稳定性。</strong></p></div>
<div class="fd"><h4>发现 4 · 规则过载导致AI崩溃</h4><p>合同#05激活5个蒙版→30条规则→规则引擎退化。V3蒙版动态激活在该合同上保持满分。<span class="tg go">全量规则无蒙版过滤不仅浪费API费用，更可能导致分析质量崩溃。</span></p></div>
<div class="fd"><h4>发现 5 · 全部漏检都是专业化细分领域</h4><p>装修质保、物流丢失认定、艺人经纪、供应链确权、健身房转让费——都需要领域知识。指明规则库迭代方向，非方法论缺陷。</p></div>
</div>

<div class="sec">
<div class="st">实验设计</div>
<div class="dg">
<div class="dc"><h4>测试合同集</h4><p>AI批量生成50份模拟合同，覆盖16大类。每份嵌入3个真实法律违规，以正常商业条款书写。前端YAML元数据标注已知风险。</p></div>
<div class="dc"><h4>三组对照</h4><ul><li><strong>组1 · 裸AI：</strong>仅提供合同全文，无规则引导</li><li><strong>组2 · +RAG：</strong>蒙版激活规则+法条原文+结构化分析</li><li><strong>组3 · +RAG+V3：</strong>规则+双路径交叉比对（知识域自述+学科规则推理）</li></ul></div>
</div>
</div>

<div class="cn">
<h3>结论</h3>
<table class="ct">
<tr><th style="text-align:left">维度</th><th>裸AI</th><th style="color:var(--gold)">V3双路径引擎 ★</th></tr>
<tr><td>风险检出率</td><td>{d['g1_rate']}% ({d['g1_hits']}/{d['total']})</td><td class="bc hi">{d['g3_rate']}% ({d['g3_hits']}/{d['total']})</td></tr>
<tr><td>零检出率</td><td class="wn">10% (5/50)</td><td class="bc hi">0% (0/50)</td></tr>
<tr><td>法条准确率</td><td>{d['g1_law_acc']}%</td><td class="bc hi">100%</td></tr>
<tr><td>完美合同率</td><td>74%</td><td class="bc hi">90%</td></tr>
<tr><td>API成本</td><td class="bc hi">1x</td><td>2x</td></tr>
</table>
<p style="font-size:.88em;color:var(--gold);margin-top:20px;font-weight:600">50份合同、150个风险、200次API调用。V3双路径引擎达96.7%检出率、零幻觉、零API失败。裸AI为87.3%，但10%合同完全漏检，且每3份合同就有一次虚构法条。数据支撑直觉引导专利组合的核心技术效果主张。</p>
</div>

<div class="footer">
<p>直觉引导 · lawdiffusion.com | 合同风险识别基准测试</p>
<p>引擎版本：contract-engine v3.0 + contract-masks v1.1 | 2026-06-26</p>
<p>专利保护：基于多蒙版动态激活的法律文书风险识别方法及系统（申请中）</p>
</div>

</div>
</body>
</html>'''

with open(r'D:\document\infinite\lawdiffusion\site\benchmark\index.html', 'w', encoding='utf-8') as f:
    f.write(html)

# Also update the quality page's comparison table and grid
grid_count = html.count('<div class="cc">')
table_count = html.count('<tr><td>')
print(f'Benchmark report: {len(html):,} bytes')
print(f'96.7 present: {"96.7" in html}')
print(f'145/150 present: {"145/150" in html}')
print(f'50 contracts in grid: {grid_count}')
print(f'50 contracts in table: {table_count}')
