"""
合同风险识别基准测试 — 50份合同 × 3组对照
组1：裸AI（无规则引导）
组2：+RAG（蒙版激活规则 + 法条原文注入）
组3：+RAG+V3（双路径交叉比对）
"""
import json, re, time, os, sys, requests
from datetime import datetime

# ═══════════════════════════════════════
# 配置
# ═══════════════════════════════════════
TEST_DIR = r"C:\Users\infinite\Desktop\合同测试集"
API_URL = "https://www.lawdiffusion.com/api/call"
RESULTS_FILE = r"C:\Users\infinite\Desktop\合同测试集\benchmark_results.json"
SUMMARY_FILE = r"C:\Users\infinite\Desktop\合同测试集\benchmark_summary.md"
MAX_CONTRACTS = 50  # 全量50份
START_INDEX = 25     # 从第26份开始（跳过已测的1-25）
PROGRESS_FILE = r"C:\Users\infinite\Desktop\合同测试集\benchmark_progress.txt"
PROGRESS_FILE = r"C:\Users\infinite\Desktop\合同测试集\benchmark_progress.txt"

# ═══════════════════════════════════════
# 蒙版定义 — 从 contract-masks.js 移植
# ═══════════════════════════════════════
MASKS = {
    "general": {
        "id": "general", "name": "通用合同审查", "priority": 0,
        "activation": [],
        "hardLaw": [
            {"id": "gen_h1", "clause": "合同主体与成立要件", "law": "民法典第143条", "mandatory": "签约主体必须具有民事行为能力，意思表示真实，合同内容合法", "check": "签约方是否具有完全民事行为能力？是否存在欺诈、胁迫、重大误解？"},
            {"id": "gen_h2", "clause": "格式条款公平性", "law": "民法典第497条", "mandatory": "格式条款不得构成显失公平", "check": "是否存在不合理免除自身责任、加重对方责任、排除对方主要权利的格式条款？"},
            {"id": "gen_h3", "clause": "违约金不得过高", "law": "民法典第585条", "mandatory": "违约金不可过分高于实际损失（司法实践通常以30%为界）", "check": "违约金是否超过实际损失的30%？"},
            {"id": "gen_h4", "clause": "免责条款效力限制", "law": "民法典第506条", "mandatory": "不得免除人身损害和故意/重大过失责任", "check": "合同中是否包含免除人身损害赔偿或故意/重大过失责任的条款？"},
            {"id": "gen_h5", "clause": "争议管辖有效性", "law": "民事诉讼法第35条", "mandatory": "管辖约定须为与争议有实际联系的地点，且不得违反专属管辖", "check": "管辖约定是否有效？是否违反专属管辖？"},
        ],
        "negotiable": [
            {"id": "gen_n1", "clause": "合同标的与对价明确性", "law": "民法典第470条", "defaultRule": "包含必备条款"},
            {"id": "gen_n2", "clause": "合同解除条件", "law": "民法典第563条", "defaultRule": "法定解除+约定解除"},
            {"id": "gen_n3", "clause": "通知与送达条款", "law": "民法典第137条", "defaultRule": "到达生效"},
        ]
    },
    "service": {
        "id": "service", "name": "服务合同", "priority": 10,
        "activation": ["委托", "开发", "服务", "定制", "外包", "维护", "咨询", "设计", "实施", "部署", "培训", "运营"],
        "hardLaw": [
            {"id": "svc_h1", "clause": "服务提供方主体适格", "law": "民法典第143条", "mandatory": "服务提供方必须具备履行合同所需的法定资质", "check": "是否核实了服务提供方的经营资质和特殊行业许可？"},
            {"id": "svc_h2", "clause": "任意解除权与赔偿", "law": "民法典第933条", "mandatory": "任意解除权不可通过约定完全排除，但可约定损害赔偿的计算方式", "check": "合同中是否不当排除了任意解除权或约定了过高的解除赔偿？"},
            {"id": "svc_h3", "clause": "保密义务", "law": "民法典第501条", "mandatory": "服务方对其在服务过程中获取的商业秘密和保密信息承担法定保密义务", "check": "是否明确约定了保密信息的范围、保密期限和违约责任？"},
            {"id": "svc_h4", "clause": "知识产权归属", "law": "著作权法第19条", "mandatory": "委托创作的知识产权归属必须明确约定", "check": "是否明确约定了服务成果的知识产权归属？"},
            {"id": "svc_h5", "clause": "格式条款提示说明", "law": "民法典第496条", "mandatory": "免责条款必须以合理方式提示", "check": "免责或限责条款是否以加粗、下划线等方式显著提示？"},
        ],
        "negotiable": [
            {"id": "svc_n1", "clause": "服务范围与交付标准", "law": "民法典第510条", "defaultRule": "按行业标准或通常标准履行"},
            {"id": "svc_n2", "clause": "服务费用与支付节点", "law": "民法典第928条", "defaultRule": "按约定支付"},
            {"id": "svc_n3", "clause": "验收标准与程序", "law": "民法典第780条", "defaultRule": "定作人应当验收"},
            {"id": "svc_n4", "clause": "违约责任与赔偿上限", "law": "民法典第584条", "defaultRule": "可预见规则下的实际损失+可得利益"},
            {"id": "svc_n5", "clause": "服务期限与延期", "law": "民法典第577条", "defaultRule": "按约定期限履行"},
            {"id": "svc_n6", "clause": "争议管辖", "law": "民事诉讼法第35条", "defaultRule": "被告住所地或合同履行地"},
        ]
    },
    "data-compliance": {
        "id": "data-compliance", "name": "数据合规", "priority": 12,
        "activation": ["个人信息", "隐私", "数据安全", "身份证", "敏感信息", "去标识化", "匿名化", "数据保护",
                       "用户信息", "网络安全", "手机号码", "生物识别", "行踪轨迹", "金融账户", "消费记录",
                       "原始数据", "数据处理", "数据挖掘", "数据跨境", "信息传输", "单独同意",
                       "传输", "服务器", "收集", "存储", "使用", "加工", "提供", "公开", "删除",
                       "数据", "信息", "用户", "客户资料", "定位", "追踪",
                       "人脸", "指纹", "声纹", "健康", "医疗", "征信", "画像",
                       "推送", "营销", "自动化决策", "算法", "跨境", "境外",
                       "委托处理", "共同处理", "共享", "转让", "公开披露",
                       "安全评估", "等级保护", "漏洞", "加密", "日志", "审计"],
        "hardLaw": [
            {"id": "data_h1", "clause": "个人信息定义与匿名化要求", "law": "个人信息保护法第4条", "mandatory": "传输给第三方的数据若包含可识别自然人的信息，必须经过匿名化处理", "check": "合同中传输的数据是否已做匿名化处理？"},
            {"id": "data_h2", "clause": "禁止非法传输个人信息", "law": "个人信息保护法第10条", "mandatory": "传输个人信息必须有合法基础", "check": "合同条款是否以'甲方同意'绕过终端用户对个人信息处理的授权要求？"},
            {"id": "data_h3", "clause": "个人信息处理的合法基础", "law": "个人信息保护法第13条", "mandatory": "处理个人信息须取得个人同意或为履行合同所必需", "check": "乙方的个人信息处理行为是否具有独立的合法基础？"},
            {"id": "data_h4", "clause": "同意须自愿明确", "law": "个人信息保护法第14条", "mandatory": "不能以合同条款替代个人的知情同意", "check": "合同是否要求甲方确保已取得终端用户的充分知情同意？"},
            {"id": "data_h5", "clause": "向第三方提供个人信息的告知同意", "law": "个人信息保护法第23条", "mandatory": "提供个人信息给第三方须告知并取得单独同意", "check": "合同是否约定了传输前应完成对终端用户的告知和单独同意程序？"},
            {"id": "data_h6", "clause": "敏感个人信息的特殊保护", "law": "个人信息保护法第28条", "mandatory": "处理敏感个人信息需有特定目的和充分必要性", "check": "合同中是否涉及身份证号、银行卡号、行踪轨迹等敏感信息的传输？"},
            {"id": "data_h7", "clause": "敏感信息需单独同意", "law": "个人信息保护法第29条", "mandatory": "处理敏感个人信息应当取得个人的单独同意", "check": "合同是否仅凭'甲方同意'覆盖了终端用户对敏感信息处理的单独同意？"},
            {"id": "data_h8", "clause": "数据安全保护措施", "law": "个人信息保护法第51条/数据安全法第27条", "mandatory": "应采取加密、去标识化等安全技术措施", "check": "合同是否约定了乙方应采取的数据安全保护措施？"},
            {"id": "data_h9", "clause": "委托处理个人信息的约束", "law": "个人信息保护法第21条", "mandatory": "受托人不得超出约定处理目的和方式", "check": "合同是否明确约定了乙方处理个人信息的具体目的、方式、种类和期限？"},
            {"id": "data_h10", "clause": "违法处罚风险", "law": "个人信息保护法第66条", "mandatory": "违规处理最高罚五千万或上年营业额5%", "check": "合同是否约定了数据违规导致的行政处罚和民事赔偿的责任分担？"},
        ],
        "negotiable": [
            {"id": "data_n1", "clause": "数据处理协议(DPA)必要性", "law": "个人信息保护法第21条", "defaultRule": "应签署独立的数据处理协议"},
            {"id": "data_n2", "clause": "数据删除与返还", "law": "个人信息保护法第21条", "defaultRule": "合同终止后删除或返还"},
            {"id": "data_n3", "clause": "安全事件通知", "law": "个人信息保护法第57条", "defaultRule": "发生泄露须通知"},
        ]
    },
    "sale": {
        "id": "sale", "name": "买卖合同", "priority": 10,
        "activation": ["买卖", "购销", "货物", "交货", "标的物", "价款", "买受人", "出卖人"],
        "hardLaw": [
            {"id": "sale_h1", "clause": "标的物合法性", "law": "民法典第597条", "mandatory": "出卖人必须对标的物有处分权", "check": "是否确认出卖人对标的物拥有完全处分权？"},
            {"id": "sale_h2", "clause": "质量瑕疵担保", "law": "民法典第617条", "mandatory": "出卖人必须承担质量瑕疵担保责任", "check": "合同中是否不当免除或限制出卖人的质量瑕疵担保责任？"},
            {"id": "sale_h3", "clause": "权利瑕疵担保", "law": "民法典第612条", "mandatory": "出卖人必须保证标的物无权利瑕疵", "check": "标的物是否存在抵押、查封、第三方权利主张？"},
            {"id": "sale_h4", "clause": "检验期限合理性", "law": "民法典第621条", "mandatory": "检验期限不得过短以致买受人无法完成合理检验", "check": "约定的检验期限是否过短（如少于7天）？"},
        ],
        "negotiable": [
            {"id": "sale_n1", "clause": "交付时间与地点", "law": "民法典第603-604条", "defaultRule": "需要运输的交付第一承运人"},
            {"id": "sale_n2", "clause": "价款与支付方式", "law": "民法典第626条", "defaultRule": "市场价格"},
            {"id": "sale_n3", "clause": "违约责任条款", "law": "民法典第585条", "defaultRule": "违约金不超过实际损失的30%"},
            {"id": "sale_n4", "clause": "风险转移时点", "law": "民法典第604条", "defaultRule": "交付时转移"},
        ]
    },
    "lease": {
        "id": "lease", "name": "租赁合同", "priority": 10,
        "activation": ["租赁", "出租", "承租", "租金", "押金", "租期", "租赁物"],
        "hardLaw": [
            {"id": "lease_h1", "clause": "租赁期限上限", "law": "民法典第705条", "mandatory": "租赁期限不得超过20年，超过部分无效", "check": "租赁期限是否超过20年？"},
            {"id": "lease_h2", "clause": "买卖不破租赁", "law": "民法典第725条", "mandatory": "不可通过约定排除买卖不破租赁规则", "check": "合同中是否排除了买卖不破租赁规则？"},
            {"id": "lease_h3", "clause": "承租人优先购买权", "law": "民法典第726条", "mandatory": "承租人享有优先购买权，不可通过约定排除", "check": "合同中是否排除了承租人优先购买权？"},
        ],
        "negotiable": [
            {"id": "lease_n1", "clause": "租金标准与调整", "law": "民法典第721条", "defaultRule": "按约定支付"},
            {"id": "lease_n2", "clause": "押金条款", "law": "民法典第710条", "defaultRule": "押金不超过1-3个月租金"},
        ]
    },
    "labor": {
        "id": "labor", "name": "劳动合同", "priority": 10,
        "activation": ["劳动", "试用期", "工资", "社保", "工伤", "竞业限制", "劳动合同", "员工", "用人单位"],
        "hardLaw": [
            {"id": "labor_h1", "clause": "书面合同要求", "law": "劳动合同法第10条", "mandatory": "必须签订书面劳动合同，超1个月双倍工资", "check": "是否已签订书面劳动合同？是否超过1个月？"},
            {"id": "labor_h2", "clause": "试用期限制", "law": "劳动合同法第19条", "mandatory": "试用期不可超过法定上限", "check": "试用期是否超过法定上限？"},
            {"id": "labor_h3", "clause": "最低工资保障", "law": "劳动合同法第20条", "mandatory": "试用期工资不得低于正式工资80%且不低于当地最低工资", "check": "试用期工资是否低于法定标准？"},
            {"id": "labor_h4", "clause": "竞业限制范围", "law": "劳动合同法第24条", "mandatory": "竞业限制限于高管、高级技术人员和保密人员，期限≤2年", "check": "是否将竞业限制扩大到普通员工？期限是否超2年？"},
            {"id": "labor_h5", "clause": "违约金禁止", "law": "劳动合同法第25条", "mandatory": "除培训费和竞业限制外不得约定劳动者违约金", "check": "合同中是否约定了不合法的劳动者违约金？"},
            {"id": "labor_h6", "clause": "社会保险强制缴纳", "law": "社会保险法第58条", "mandatory": "必须缴纳社保，不得通过约定免除", "check": "合同中是否有免除社保缴纳的约定？"},
        ],
        "negotiable": [
            {"id": "labor_n1", "clause": "薪酬结构与绩效", "law": "劳动合同法第11条", "defaultRule": "明确约定工资数额"},
        ]
    },
    "ip": {
        "id": "ip", "name": "知识产权合同", "priority": 10,
        "activation": ["知识产权", "专利", "商标", "著作权", "版权", "源代码", "技术秘密", "许可", "技术转让", "软件"],
        "hardLaw": [
            {"id": "ip_h1", "clause": "知识产权有效性担保", "law": "专利法第47条", "mandatory": "许可方必须保证知识产权处于有效状态", "check": "许可方是否明确承诺知识产权处于有效状态？"},
            {"id": "ip_h2", "clause": "不侵权担保", "law": "民法典第870条", "mandatory": "让与人必须保证技术不侵犯第三方合法权益", "check": "是否包含不侵权担保条款及侵权时的赔偿责任？"},
            {"id": "ip_h3", "clause": "后续改进成果归属", "law": "民法典第875条", "mandatory": "后续改进默认归改进方所有", "check": "是否合理约定了后续改进成果的归属与使用条件？"},
            {"id": "ip_h4", "clause": "不得滥用知识产权排除竞争", "law": "反垄断法第68条", "mandatory": "许可条款不得构成垄断行为", "check": "许可条款中是否包含限定转售价格、独家回授等垄断限制？"},
        ],
        "negotiable": [
            {"id": "ip_n1", "clause": "许可类型与范围", "law": "专利法第12条", "defaultRule": "明确许可类型"},
            {"id": "ip_n2", "clause": "许可使用费", "law": "民法典第866条", "defaultRule": "按约定支付"},
        ]
    },
}


def activate_masks(text):
    """关键词匹配激活蒙版 — 与 contract-masks.js 逻辑一致"""
    search = (text or "")[:8000]
    active = []

    for mask_id, mask in sorted(MASKS.items(), key=lambda x: x[1]["priority"], reverse=True):
        if mask_id == "general":
            active.append(mask)
            continue
        if not mask.get("activation"):
            continue
        hits = sum(1 for kw in mask["activation"] if kw in search)
        if hits >= 2:
            active.append(mask)

    # 确保 general 在列表中（始终激活）
    if not any(m["id"] == "general" for m in active):
        active.insert(0, MASKS["general"])

    return active


def merge_rules(active_masks):
    """合并去重 — 与 contract-masks.js 一致"""
    hard_law, negotiable, law_refs = [], [], []
    seen = set()

    for mask in active_masks:
        for rule in mask.get("hardLaw", []):
            if rule["id"] not in seen:
                seen.add(rule["id"])
                hard_law.append(rule)
        for rule in mask.get("negotiable", []):
            if ("n_" + rule["id"]) not in seen:
                seen.add("n_" + rule["id"])
                negotiable.append(rule)

    return hard_law, negotiable


def parse_contract_file(filepath):
    """解析测试合同文件（YAML头 + Markdown正文）"""
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    # 解析 YAML frontmatter
    meta = {}
    if content.startswith("---"):
        parts = content.split("---", 2)
        if len(parts) >= 3:
            for line in parts[1].strip().split("\n"):
                line = line.strip()
                if ":" in line:
                    key, val = line.split(":", 1)
                    key = key.strip()
                    val = val.strip()
                    # 解析 risk_tags 列表
                    if key == "risk_tags":
                        val = [t.strip().strip("'\"") for t in val.strip("[]").split(",")]
                    elif key == "risk_count":
                        val = int(val)
                    meta[key] = val
            text = parts[2].strip()
        else:
            text = content
    else:
        text = content

    return meta, text


def build_group1_prompt(contract_text):
    """组1：裸AI — 无任何规则引导"""
    return {
        "model": "deepseek-v4-flash",
        "messages": [
            {"role": "system", "content": "你是中文法律合同审查专家。请分析以下合同文本，逐条列出你发现的所有法律风险。每条风险标注：风险描述、涉及条款、法律依据（你基于法律知识引用）、严重程度（阻塞/重要/标记）。以JSON数组返回：[{id, clause, risk, law, severity}]"},
            {"role": "user", "content": f"请分析以下合同的法律风险：\n\n{contract_text}"}
        ]
    }


def build_group2_prompt(contract_text, hard_law, negotiable):
    """组2：+RAG — 蒙版规则引导 + 法条引用"""
    rules_text = "## 硬约束规则（法律强制性规定，不可约定排除）\n"
    for i, rule in enumerate(hard_law, 1):
        rules_text += f"{i}. [{rule['id']}] {rule['clause']}\n"
        rules_text += f"   法律依据：{rule['law']}\n"
        rules_text += f"   强制性要求：{rule['mandatory']}\n"
        rules_text += f"   检查要点：{rule['check']}\n\n"

    rules_text += "\n## 约定规则（默认规则，当事人可协商调整）\n"
    for i, rule in enumerate(negotiable, 1):
        rules_text += f"{i}. [{rule['id']}] {rule['clause']}（{rule['law']}）\n"

    return {
        "model": "deepseek-v4-flash",
        "messages": [
            {"role": "system", "content": f"你是合同法律风险分析师。请逐项检查以下每条审查规则在合同中的对应情况。\n\n分析维度：\n1. 合同是否包含该条款？（found: true/false）\n2. 基于法律依据判断合规状态（status: 合规/需关注/高风险/严重违规）\n3. 风险类别（legal_violation/commercial_imbalance/procedural_gap）\n4. 具体发现和修改建议\n\n以JSON数组返回：[{{id, found, status, riskCategory, finding, recommendation}}]\n\n重要：必须为每一项硬约束规则输出一个独立对象。"},
            {"role": "user", "content": f"合同类型：待分析合同\n\n=== 合同条款全文 ===\n{contract_text}\n\n=== 审查规则及法律依据（共{len(hard_law)}项）===\n{rules_text}\n\n请逐项分析以上{len(hard_law)}条审查规则在合同中的对应情况。"}
        ]
    }


def build_group3_prompts(contract_text, hard_law, negotiable):
    """组3：+RAG+V3 — 双路径交叉比对（简化V3：路径A知识域 + 路径B规则）"""
    # 路径A：知识域自述模式
    prompt_a = {
        "model": "deepseek-v4-flash",
        "messages": [
            {"role": "system", "content": "你是法律知识域分析工具。请分析以下合同文本在法律知识域中的典型风险模式。\n\n输出：①该合同涉及的法律领域；②此类合同在司法实践中最常见的纠纷类型；③合同条款中可能存在的隐藏假设和利益失衡。\n\n以JSON格式输出：{domains:[], commonDisputes:[], hiddenAssumptions:[], imbalanceRisks:[{clause, risk, bias}]}"},
            {"role": "user", "content": f"请分析以下合同的知识域风险模式：\n\n{contract_text}"}
        ]
    }

    # 路径B：学科规则推理模式
    rules_text = ""
    for i, rule in enumerate(hard_law, 1):
        rules_text += f"{i}. [{rule['id']}] {rule['clause']}\n"
        rules_text += f"   法律依据：{rule['law']}\n"
        rules_text += f"   强制性要求：{rule['mandatory']}\n"
        rules_text += f"   检查要点：{rule['check']}\n\n"

    prompt_b = {
        "model": "deepseek-v4-flash",
        "messages": [
            {"role": "system", "content": f"你是基于学科规则的严格法律推理工具。请按以下步骤分析：\n1. 将合同中的抽象条款还原为可量化的权利义务关系\n2. 逐项对照以下审查规则进行合规判定\n3. 对各参与方进行利益结构分析（哪一方承担了不成比例的风险）\n\n以JSON数组返回：[{{id, found, status, riskCategory, finding, recommendation, bias（偏向甲方/偏向乙方/平衡）, riskScore（1-5）}}]\n\n必须为每一项规则输出一个独立对象。"},
            {"role": "user", "content": f"合同全文：\n{contract_text}\n\n审查规则共{len(hard_law)}项：\n{rules_text}\n\n请逐项分析。"}
        ]
    }

    return prompt_a, prompt_b


def call_api(payload, timeout=60):
    """调用 /api/call"""
    try:
        resp = requests.post(
            API_URL,
            json={**payload, "tool": "contract-risk"},
            timeout=timeout,
            headers={"Content-Type": "application/json"}
        )
        if resp.status_code != 200:
            return {"error": f"HTTP {resp.status_code}", "body": resp.text[:500]}
        data = resp.json()
        # 提取实际内容
        if "choices" in data:
            return {"content": data["choices"][0]["message"]["content"]}
        if "content" in data:
            return {"content": data["content"]}
        return {"content": str(data)}
    except requests.Timeout:
        return {"error": "timeout"}
    except Exception as e:
        return {"error": str(e)}


def extract_risks_from_result(result_text):
    """从 AI 返回的文本中提取 JSON 风险数组"""
    if not result_text or not isinstance(result_text, str):
        return []
    try:
        # 尝试直接解析
        data = json.loads(result_text)
        if isinstance(data, list):
            return data
        if isinstance(data, dict):
            return [data]
    except:
        pass
    # 尝试提取 JSON 块
    json_match = re.search(r'\[[\s\S]*\]', result_text)
    if json_match:
        try:
            return json.loads(json_match.group(0))
        except:
            pass
    return []


# 已知风险标签 → 关键词语义映射
RISK_TAG_KEYWORDS = {
    '违约金比例失衡': ['违约金', '过高', '超过', '30%', '比例失', '不平衡'],
    '格式条款无效风险': ['格式条款', '无效', '免除', '排除', '加重', '不平等', '显失公平'],
    '不可抗力条款过宽': ['不可抗力', '免责', '过宽', '任何', '所有', '政府行为', '地质异常', '无法预见'],
    '产权瑕疵未披露': ['产权', '瑕疵', '瑕疵', '隐瞒', '未披露', '权利', '抵押', '查封'],
    '定金条款违法': ['定金', '超过', '20%', '定金罚则', '定金比例'],
    '争议管辖缺失': ['管辖', '诉讼', '仲裁', '法院', '争议解决'],
    '自动续约陷阱': ['自动续约', '自动续', '通知', '到期', '不再续', '默示'],
    '租金涨幅不合理': ['租金', '涨幅', '上涨', '增长', '上浮', '调价', '递增'],
    '装修损失条款不公': ['装修', '拆除', '恢复', '补偿', '损失'],
    '数据权属不清': ['数据', '所有权', '权属', '归属', '使用权'],
    '免责范围过宽': ['免责', '不保证', '不承担', '任何', '所有', '责任限制', '赔偿上限'],
    '单方变更条款': ['单方', '变更', '修改', '随时', '通知', '发布即生效'],
    '个人信息收集使用违规': ['个人信息', '收集', '同意', '告知', '授权', '合法', '合规'],
    '数据安全责任缺失': ['数据安全', '安全措施', '加密', '泄露', '保护', '技术措施'],
    '数据泄露免责': ['泄露', '免责', '不负责', '不承担', '安全事件'],
    '竞业限制过度': ['竞业限制', '竞业', '补偿', '范围', '期限'],
    '连带责任规避': ['连带', '责任', '派遣', '用工'],
    '对赌式验收标准': ['验收', '标准', '合格', '满意度', '客观', '单方'],
    '数据安全霸王条款': ['数据', '安全', '所有权', '免责', '单方', '责任'],
    '变相高利贷': ['利率', '年利率', '利息', '超过', 'LPR', '高利'],
    '对赌回购霸王条款': ['回购', '对赌', '条件', '估值', '业绩', '退出'],
    '独立担保与保证期间模糊': ['担保', '保证', '独立', '期间', '连带'],
    '背靠背付款条款': ['背靠背', '付款', '前提', '收到', '条件', '以…为'],
    '低价陷阱与增项套路': ['低价', '增项', '费用', '套餐', '实际', '追加'],
    '效果承诺无客观标准': ['效果', '承诺', '标准', '客观', '数据', '指标'],
    '验收标准缺失': ['验收', '标准', '测试', '通过', '缺陷', '质量'],
    '保密期限永久化': ['保密', '期限', '永久', '终止后', '持续'],
    '区域保护模糊': ['区域', '保护', '独家', '范围', '禁止', '竞争'],
    '货损赔偿上限过低': ['货损', '赔偿', '损失', '上限', '限额', '保价'],
    '公共收益归属不清': ['公共', '收益', '归属', '业主', '物业'],
    '代持人权利过大': ['代持', '股权', '行使', '处置', '权利'],
    '不合理的销售目标': ['销售', '目标', '考核', '调整', '指标', '业绩'],
    '单方变更权': ['单方', '变更', '修改', '终止', '随时'],
    '取消条款不公': ['取消', '退款', '退还', '解除', '不退还'],
    '解除后租金照付': ['解除', '租金', '继续', '剩余', '全部'],
    '技术验收标准模糊': ['技术', '验收', '标准', '指标', '参数', '测试'],
    '解约赔偿过高': ['解约', '赔偿', '违约金', '解除', '提前'],
    '授权范围有歧义': ['授权', '范围', '独占', '排他', '地域', '方式'],
    '与公司对赌效力存疑': ['对赌', '公司', '股东', '回购', '增资'],
    '退出机制缺失': ['退出', '转让', '回购', '解散', '估值', '合伙'],
    '个人信息保护缺失': ['个人信息', '隐私', '同意', '告知', '保护', '合规'],
    '试用期违规操作': ['试用期', '期限', '工资', '延长', '解除'],
    '修改次数无限制': ['修改', '次数', '无限', '免费', '变更'],
    '坑位费不退还': ['坑位费', '退款', '退还', '不退还', '服务费'],
    '应收账款确权模糊': ['应收账款', '确权', '确认', '债务人', '债权'],
    '出资与表决权分离不当': ['出资', '表决', '股权', '比例', '分配'],
    '形象权永久买断': ['形象', '肖像', '买断', '永久', '转让', '授权'],
    '成果验收极主观': ['验收', '主观', '满意', '认可', '标准', '判断'],
    '押金扣除标准模糊': ['押金', '扣除', '退还', '条件', '标准', '抵扣'],
    '费用计算无上限': ['费用', '上限', '计算', '超过', '无限制', '额外'],
    '道德条款失衡': ['道德', '形象', '负面', '解除', '赔偿', '公关'],
    '管辖法律与执行冲突': ['管辖', '法律适用', '执行', '跨境', '仲裁', '法院'],
    '转让与退款限制': ['转让', '退款', '退费', '限制', '禁止', '不可以'],
    '服务质量标准空洞': ['服务', '质量', '标准', '具体', '描述', '满意'],
    '验收标准依赖甲方': ['验收', '甲方', '单方', '确认', '标准', '主观'],
    '行权条件苛刻': ['行权', '条件', '期限', '业绩', '目标', '考核'],
    '虚假宣传与退款障碍': ['虚假', '宣传', '退款', '退费', '承诺', '实际'],
    '货损赔偿形同虚设': ['货损', '赔偿', '限制', '免责', '条件'],
    '收入分成计算不透明': ['分成', '收入', '计算', '不透明', '审计', '数据'],
    '排他期过长': ['排他', '独家', '期限', '过长', '锁定'],
    '格式条款无效风险(平台)': ['格式条款', '无效', '消费者', '权益', '限制'],
}
CATEGORY_MAP = {
    '违约金': ['违约金比例失衡', '解约赔偿过高'],
    '格式条款': ['格式条款无效风险', '格式条款无效风险(平台)'],
    '不可抗力': ['不可抗力条款过宽'],
    '产权': ['产权瑕疵未披露'],
    '定金': ['定金条款违法'],
    '管辖': ['争议管辖缺失', '管辖法律与执行冲突'],
    '续约': ['自动续约陷阱'],
    '租金': ['租金涨幅不合理', '解除后租金照付'],
    '装修': ['装修损失条款不公'],
    '数据权': ['数据权属不清'],
    '免责': ['免责范围过宽', '数据泄露免责'],
    '单方变更': ['单方变更条款', '单方变更权'],
    '个人信息': ['个人信息收集使用违规', '个人信息保护缺失'],
    '数据安全': ['数据安全责任缺失', '数据安全霸王条款'],
    '竞业': ['竞业限制过度'],
    '连带': ['连带责任规避'],
    '对赌': ['对赌式验收标准', '与公司对赌效力存疑', '对赌回购霸王条款'],
    '验收': ['验收标准缺失', '技术验收标准模糊', '成果验收极主观', '验收标准依赖甲方'],
    '保密': ['保密期限永久化'],
    '区域': ['区域保护模糊'],
    '货损': ['货损赔偿上限过低', '货损赔偿形同虚设'],
    '公共': ['公共收益归属不清'],
    '代持': ['代持人权利过大'],
    '销售目标': ['不合理的销售目标'],
    '取消': ['取消条款不公'],
    '解约': ['解约赔偿过高'],
    '授权': ['授权范围有歧义'],
    '退出': ['退出机制缺失'],
    '试用期': ['试用期违规操作'],
    '修改次数': ['修改次数无限制'],
    '坑位费': ['坑位费不退还'],
    '应收账款': ['应收账款确权模糊'],
    '出资': ['出资与表决权分离不当'],
    '形象': ['形象权永久买断'],
    '押金': ['押金扣除标准模糊'],
    '费用上限': ['费用计算无上限'],
    '道德': ['道德条款失衡'],
    '转让退款': ['转让与退款限制'],
    '服务质量': ['服务质量标准空洞'],
    '行权': ['行权条件苛刻'],
    '虚假宣传': ['虚假宣传与退款障碍'],
    '分成': ['收入分成计算不透明'],
    '排他': ['排他期过长'],
    '担保': ['独立担保与保证期间模糊'],
    '背靠背': ['背靠背付款条款'],
    '低价': ['低价陷阱与增项套路'],
    '效果': ['效果承诺无客观标准'],
    '高利贷': ['变相高利贷'],
    '用工': ['连带责任规避'],
}


def compare_risks(detected, expected_tags):
    """智能对比 — 关键词匹配 + 未知标签自动核心词提取"""
    detected_text = json.dumps(detected, ensure_ascii=False).lower() if detected else ""
    if not detected_text:
        return [], list(expected_tags)

    hits = []
    misses = []

    # 常见后缀词（从标签中去掉以提取核心概念）
    SUFFIX_WORDS = ['风险', '问题', '不公', '违规', '违法', '缺失', '过宽', '过高', '过低',
                    '模糊', '不清', '不合理', '不当', '不合法', '形同虚设', '过大', '不平衡',
                    '不透明', '过重', '严苛', '存在', '条款', '陷阱', '套路', '障碍', '空洞',
                    '违宪', '未披露', '有歧义', '冲突', '异议', '失当', '过度', '永久化',
                    '霸王条款', '无上限', '无限制', '无法', '不能']

    for tag in expected_tags:
        found = False

        # 方法1：在已知关键词库中匹配
        if tag in RISK_TAG_KEYWORDS:
            keywords = RISK_TAG_KEYWORDS[tag]
            kw_hits = sum(1 for kw in keywords if kw.lower() in detected_text)
            found = kw_hits >= min(2, len(keywords))

        # 方法2：CATEGORY_MAP 反向查找
        if not found:
            for cat, tag_list in CATEGORY_MAP.items():
                if tag in tag_list and cat.lower() in detected_text:
                    found = True
                    break

        # 方法3：自动核心词提取（对未知标签）
        if not found:
            # 去掉常见后缀，提取核心概念词
            core = tag
            for suffix in SUFFIX_WORDS:
                if core.endswith(suffix) and len(core) > len(suffix) + 1:
                    core = core[:-len(suffix)]
                    break
            # 检查核心词（≥2字符）是否在AI输出中出现
            core_stripped = core.rstrip('的之与及和或')
            if len(core_stripped) >= 2 and core_stripped.lower() in detected_text:
                found = True
            # 也尝试2-gram滑窗匹配
            if not found and len(core) >= 4:
                for i in range(len(core) - 1):
                    chunk = core[i:i+2]
                    if len(chunk) >= 2 and chunk in detected_text:
                        found = True
                        break

        if found:
            hits.append(tag)
        else:
            misses.append(tag)

    return hits, misses


def count_law_refs(result_text):
    """统计法条引用数量 — 只统计真实法律引用"""
    if not result_text or not isinstance(result_text, str):
        return 0, 0, []

    real_laws = [
        "民法典", "刑法", "劳动法", "劳动合同法", "公司法", "个人信息保护法",
        "数据安全法", "网络安全法", "专利法", "商标法", "著作权法", "反垄断法",
        "社会保险法", "民事诉讼法", "刑事诉讼法", "行政诉讼法",
        "反不正当竞争法", "消费者权益保护法", "证券法",
    ]

    # 找带法律名称的法条引用
    law_refs = []
    for law in real_laws:
        pattern = law + r'[^。；，\n]{0,30}条'
        matches = re.findall(pattern, result_text)
        law_refs.extend(matches)

    # 统计真实引用 vs 可能的幻觉
    real_count = len(law_refs)
    # 检查是否有虚构的法律名称（带有"法"但不是已知法律的）
    all_law_patterns = re.findall(r'[《]?([^《》\s]{2,8}法)[》]?\s*第[零一二三四五六七八九十百千\d]+条', result_text)
    fake_refs = [m for m in all_law_patterns if not any(rl in m for rl in real_laws)]
    hallucinated = len(fake_refs)

    return real_count, hallucinated, law_refs


def run_benchmark():
    """主测试流程"""
    print("=" * 60)
    print("合同风险识别基准测试 — 50份合同 × 3组对照")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)

    # 读取所有测试文件
    all_contracts = sorted([
        f for f in os.listdir(TEST_DIR)
        if f.endswith(".md") and f[0].isdigit()
    ])
    test_files = all_contracts[START_INDEX:MAX_CONTRACTS]

    print(f"读取到 {len(test_files)} 份测试合同")

    all_results = []
    summary = {
        "total": 0,
        "g1_hits": 0, "g1_misses": 0, "g1_total_risks": 0,
        "g2_hits": 0, "g2_misses": 0, "g2_total_risks": 0,
        "g3_hits": 0, "g3_misses": 0, "g3_total_risks": 0,
        "g1_law_refs": 0, "g2_law_refs": 0, "g3_law_refs": 0,
        "g1_hallucinations": 0, "g2_hallucinations": 0, "g3_hallucinations": 0,
        "g1_api_calls": 0, "g2_api_calls": 0, "g3_api_calls": 0,
        "g1_errors": 0, "g2_errors": 0, "g3_errors": 0,
        "mask_activation": {"matches": 0, "mismatches": 0, "details": []},
    }

    for idx, filename in enumerate(test_files):
        filepath = os.path.join(TEST_DIR, filename)
        meta, contract_text = parse_contract_file(filepath)

        contract_id = meta.get("contract_id", idx + 1)
        contract_type = meta.get("contract_type", "未知")
        expected_tags = meta.get("risk_tags", [])
        expected_count = meta.get("risk_count", len(expected_tags))

        print(f"\n{'─'*50}")
        print(f"[{idx+1}/{len(test_files)}] #{contract_id} {contract_type}")
        print(f"  已知风险: {expected_count}个 → {expected_tags}")

        # 蒙版激活
        active_masks = activate_masks(contract_text)
        mask_names = [m["name"] for m in active_masks]
        print(f"  激活蒙版: {mask_names}")

        # 检查蒙版是否与合同类型匹配
        expected_mask = None
        type_map = {"买卖": "sale", "租赁": "lease", "劳动": "labor", "服务": "service",
                    "知识产权": "ip", "数据": "data-compliance", "sale": "sale",
                    "lease": "lease", "labor": "labor", "service": "service", "ip": "ip",
                    "data-compliance": "data-compliance"}
        # 根据合同类型判断预期蒙版
        for key, val in type_map.items():
            if key in contract_type.lower() or key in contract_type:
                expected_mask = val
                break
        if expected_mask and expected_mask in [m["id"] for m in active_masks]:
            summary["mask_activation"]["matches"] += 1
        elif expected_mask:
            summary["mask_activation"]["mismatches"] += 1
            summary["mask_activation"]["details"].append(f"#{contract_id} {contract_type}: 预期{expected_mask}, 实际{mask_names}")

        hard_law, negotiable = merge_rules(active_masks)
        print(f"  合并规则: {len(hard_law)}条硬约束 + {len(negotiable)}条约定")

        result = {
            "contract_id": contract_id,
            "contract_type": contract_type,
            "expected_tags": expected_tags,
            "expected_count": expected_count,
            "active_masks": mask_names,
            "hard_law_count": len(hard_law),
            "g1_hits": [], "g1_misses": [], "g1_law_refs": 0, "g1_hallucinations": 0,
            "g2_hits": [], "g2_misses": [], "g2_law_refs": 0, "g2_hallucinations": 0,
            "g3_hits": [], "g3_misses": [], "g3_law_refs": 0, "g3_hallucinations": 0,
        }

        # ── 组1：裸AI ──
        print("  [组1] 裸AI...", end=" ", flush=True)
        g1_payload = build_group1_prompt(contract_text)
        g1_resp = call_api(g1_payload)
        summary["g1_api_calls"] += 1

        if "error" in g1_resp:
            print(f"❌ {g1_resp['error']}")
            summary["g1_errors"] += 1
        else:
            g1_text = g1_resp.get("content", "")
            g1_risks = extract_risks_from_result(g1_text)
            hits, misses = compare_risks(g1_risks, expected_tags)
            n_law, n_hallu, _ = count_law_refs(g1_text)
            result["g1_hits"] = hits
            result["g1_misses"] = misses
            result["g1_law_refs"] = n_law
            result["g1_hallucinations"] = n_hallu
            summary["g1_hits"] += len(hits)
            summary["g1_misses"] += len(misses)
            summary["g1_total_risks"] += expected_count
            summary["g1_law_refs"] += n_law
            summary["g1_hallucinations"] += n_hallu
            print(f"✓ 检出{len(hits)}/{expected_count}, 法条{n_law}次(幻觉{n_hallu})")

        # ── 组2：+RAG ──
        print("  [组2] +RAG...", end=" ", flush=True)
        g2_payload = build_group2_prompt(contract_text, hard_law, negotiable)
        g2_resp = call_api(g2_payload)
        summary["g2_api_calls"] += 1

        if "error" in g2_resp:
            print(f"❌ {g2_resp['error']}")
            summary["g2_errors"] += 1
        else:
            g2_text = g2_resp.get("content", "")
            g2_risks = extract_risks_from_result(g2_text)
            hits, misses = compare_risks(g2_risks, expected_tags)
            n_law, n_hallu, _ = count_law_refs(g2_text)
            result["g2_hits"] = hits
            result["g2_misses"] = misses
            result["g2_law_refs"] = n_law
            result["g2_hallucinations"] = n_hallu
            summary["g2_hits"] += len(hits)
            summary["g2_misses"] += len(misses)
            summary["g2_total_risks"] += expected_count
            summary["g2_law_refs"] += n_law
            summary["g2_hallucinations"] += n_hallu
            print(f"✓ 检出{len(hits)}/{expected_count}, 法条{n_law}次(幻觉{n_hallu})")

        # ── 组3：+RAG+V3 ──
        print("  [组3] +RAG+V3...", end=" ", flush=True)
        g3_prompt_a, g3_prompt_b = build_group3_prompts(contract_text, hard_law, negotiable)

        g3a_resp = call_api(g3_prompt_a)
        summary["g3_api_calls"] += 1
        g3b_resp = call_api(g3_prompt_b)
        summary["g3_api_calls"] += 1

        g3_errors = 0
        g3a_ok = "error" not in g3a_resp
        g3b_ok = "error" not in g3b_resp
        if not g3a_ok: summary["g3_errors"] += 1; g3_errors += 1
        if not g3b_ok: summary["g3_errors"] += 1; g3_errors += 1

        g3a_text = g3a_resp.get("content", "") if g3a_ok else ""
        g3b_text = g3b_resp.get("content", "") if g3b_ok else ""

        # 合并路径A和路径B的检出结果
        g3a_risks = extract_risks_from_result(g3a_text)
        g3b_risks = extract_risks_from_result(g3b_text)
        g3_combined = g3a_risks + g3b_risks

        hits, misses = compare_risks(g3_combined, expected_tags)
        n_law_a, n_hallu_a, _ = count_law_refs(g3a_text)
        n_law_b, n_hallu_b, _ = count_law_refs(g3b_text)
        n_law = n_law_a + n_law_b
        n_hallu = n_hallu_a + n_hallu_b

        result["g3_hits"] = hits
        result["g3_misses"] = misses
        result["g3_law_refs"] = n_law
        result["g3_hallucinations"] = n_hallu
        summary["g3_hits"] += len(hits)
        summary["g3_misses"] += len(misses)
        summary["g3_total_risks"] += expected_count
        summary["g3_law_refs"] += n_law
        summary["g3_hallucinations"] += n_hallu
        if g3_errors > 0:
            print(f"⚠ 检出{len(hits)}/{expected_count} (路径{'AB'[g3a_ok]}{'AB'[g3b_ok]}各{'✓'[g3a_ok]}{'✓'[g3b_ok]}错误: {g3_errors})")
        else:
            print(f"✓ 检出{len(hits)}/{expected_count}, 法条{n_law}次(幻觉{n_hallu})")

        all_results.append(result)
        summary["total"] += 1

        # 每10份保存一次中间结果
        if (idx + 1) % 10 == 0:
            with open(RESULTS_FILE, "w", encoding="utf-8") as f:
                json.dump({"summary": summary, "results": all_results}, f, ensure_ascii=False, indent=2)
            print(f"\n  💾 中间结果已保存 ({idx+1}/{len(test_files)})")

        # 速率控制
        time.sleep(0.5)

    # ── 最终保存 ──
    with open(RESULTS_FILE, "w", encoding="utf-8") as f:
        json.dump({"summary": summary, "results": all_results}, f, ensure_ascii=False, indent=2)

    # ── 生成汇总报告 ──
    generate_summary(summary, len(test_files))

    print(f"\n{'='*60}")
    print(f"测试完成: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"结果已保存: {RESULTS_FILE}")
    print(f"汇总报告: {SUMMARY_FILE}")
    print(f"{'='*60}")


def generate_summary(summary, total):
    """生成 Markdown 汇总报告"""
    t = summary["total"]
    g1_recall = summary["g1_hits"] / max(summary["g1_total_risks"], 1) * 100
    g2_recall = summary["g2_hits"] / max(summary["g2_total_risks"], 1) * 100
    g3_recall = summary["g3_hits"] / max(summary["g3_total_risks"], 1) * 100
    g1_precision = summary["g1_hits"] / max(summary["g1_hits"] + summary["g1_misses"], 1) * 100
    g2_precision = summary["g2_hits"] / max(summary["g2_hits"] + summary["g2_misses"], 1) * 100
    g3_precision = summary["g3_hits"] / max(summary["g3_hits"] + summary["g3_misses"], 1) * 100

    g1_avg_law = summary["g1_law_refs"] / max(t, 1)
    g2_avg_law = summary["g2_law_refs"] / max(t, 1)
    g3_avg_law = summary["g3_law_refs"] / max(t, 1)

    report = f"""# 合同风险识别基准测试 — 汇总报告

> 测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
> 测试合同: {t} 份
> API 提供商: DeepSeek V4 Pro (通过 lawdiffusion.com /api/call)

---

## 一、核心指标

| 指标 | 组1：裸AI | 组2：+RAG | 组3：+RAG+V3 |
|------|:---:|:---:|:---:|
| **风险检出率（召回率）** | {g1_recall:.1f}% ({summary['g1_hits']}/{summary['g1_total_risks']}) | {g2_recall:.1f}% ({summary['g2_hits']}/{summary['g2_total_risks']}) | {g3_recall:.1f}% ({summary['g3_hits']}/{summary['g3_total_risks']}) |
| **命中精度** | {g1_precision:.1f}% | {g2_precision:.1f}% | {g3_precision:.1f}% |
| **平均法条引用/合同** | {g1_avg_law:.1f} | {g2_avg_law:.1f} | {g3_avg_law:.1f} |
| **幻觉法条数** | {summary['g1_hallucinations']} | {summary['g2_hallucinations']} | {summary['g3_hallucinations']} |
| **API 调用/合同** | 1 | 1 | 2 |
| **总 API 调用** | {summary['g1_api_calls']} | {summary['g2_api_calls']} | {summary['g3_api_calls']} |
| **调用失败** | {summary['g1_errors']} | {summary['g2_errors']} | {summary['g3_errors']} |

## 二、组间对比

| 对比 | 召回率差异 | 说明 |
|------|:---:|------|
| 组2 vs 组1 | {g2_recall - g1_recall:+.1f}% | RAG规则引导的检出率提升 |
| 组3 vs 组2 | {g3_recall - g2_recall:+.1f}% | V3双路径交叉比对的增量贡献 |
| 组3 vs 组1 | {g3_recall - g1_recall:+.1f}% | 全管线 vs 裸AI的总提升 |

## 三、蒙版激活准确率

- 激活匹配: {summary['mask_activation']['matches']}/{t}
- 激活不匹配: {summary['mask_activation']['mismatches']}/{t}
"""
    if summary['mask_activation']['details']:
        report += "\n### 不匹配详情\n"
        for d in summary['mask_activation']['details']:
            report += f"- {d}\n"

    report += f"""
## 四、结论

1. **裸AI（组1）** 检出率 {g1_recall:.1f}%——无规则引导时，AI 依赖参数记忆中的法律知识，覆盖面受限。
2. **+RAG（组2）** 检出率 {g2_recall:.1f}%——规则引导将审查维度结构化，显著提升已知风险的发现率。
3. **+RAG+V3（组3）** 检出率 {g3_recall:.1f}%——双路径交叉比对额外捕获 {summary['g3_hits'] - summary['g2_hits']} 个风险，但增加了 1 次 API 调用成本。
"""
    with open(SUMMARY_FILE, "w", encoding="utf-8") as f:
        f.write(report)

    print(f"\n{report}")


if __name__ == "__main__":
    run_benchmark()
