"""测试真实上市公司披露合同 — 3份 × 3组对照"""
import json, re, time, os, requests

API_URL = 'https://www.lawdiffusion.com/api/call'
TEST_DIR = r'C:\Users\infinite\Desktop\合同测试集\real_contracts'

MASKS_ACT = {
    'service': ['委托','开发','服务','定制','外包','维护','咨询','设计','实施','部署','培训','运营'],
    'data-compliance': ['个人信息','隐私','数据安全','身份证','敏感信息','数据','信息','用户','传输','服务器','收集','存储','加密'],
    'sale': ['买卖','购销','货物','交货','价款','买受人','出卖人'],
    'lease': ['租赁','出租','承租','租金','押金','租期'],
    'labor': ['劳动','试用期','工资','社保','工伤','竞业限制','员工','用人单位'],
    'ip': ['知识产权','专利','商标','著作权','版权','源代码','技术秘密','许可','技术转让'],
}

RISK_KW = {
    '付款与验收脱钩': ['付款','验收','节点','分次'],
    '知识产权归属缺失': ['知识产权','归属','专利','成果'],
    '甲方单方审核权': ['甲方','单方','审核','需求','主观'],
    '乙方义务不对等': ['乙方','义务','配合','不对等','单方'],
    '违约金条款文本错误': ['违约金','供方','需方','错误','逻辑'],
    '争议管辖签订地不明': ['管辖','签订地','法院','不明'],
    '质量标准单一': ['质量','标准','单一','仅','参数'],
    '先款后货无担保': ['先款后货','预付','担保','风险','先款'],
    '违约责任笼统无量化': ['违约','民法典','笼统','具体','金额','量化'],
    '验收标准主观化': ['验收','甲方','标准','主观','量化','SLA'],
    '二期服务锁定风险': ['二期','另行','协商','锁定','依赖'],
    '数据安全条款缺失': ['数据安全','隐私','删除','保密','缺失','数据'],
    # English contract risk tags (SEC filings)
    '付款与交付脱钩': ['付款与交付脱钩','payment','milestone','deliverable','acceptance','installment','no payment milestone','paid in','linked to delivery'],
    '验收标准缺失': ['验收标准','acceptance criteria','acceptance test','specification','no acceptance','no testing','no objective','no criteria'],
    'IP归属模糊': ['IP归属','intellectual property','IP rights','ownership','assignment','IP ownership','owns all','who owns','title to'],
    '单方终止权缺失': ['termination','terminate','convenience','without cause','no provision for','no right to terminate','may terminate'],
    '不可抗力条款过宽': ['不可抗力','force majeure','act of god','beyond reasonable control','any other circumstances','epidemic','pandemic','broadly'],
    '许可范围过度受限': ['license','scope','territory','restricted','limited','non-transferable','field of use','solely for'],
    '服务终止权单方化': ['discontinue','cease providing','unilateral','without obligation','reserves all rights','sole discretion','no obligation to continue'],
    '竞业限制模糊': ['compete','competitive','competing with','restrict','non-compete','competitor','antitrust'],
    '数据权利归属不明': ['data','end user','data ownership','data rights','processed','collected','owns','data belongs'],
    # R06 劳动合同 risks
    '试用期工资低于法定标准': ['试用期','工资','80%','15000','20000','低于','比例','75%'],
    '竞业限制期限超法定上限': ['竞业限制','3年','期限','超过','2年','24个月','上限','三年'],
    '竞业限制补偿金违法': ['补偿金','补偿','包含','月薪','不再另行','不另行','不支付','最低工资','2360'],
    '竞业限制地域范围过宽': ['全球范围','地域','范围','全球'],
    '竞业限制对象范围过宽': ['互联网','软件开发','所有','任何','竞争','同业'],
    '违约金畸高且退还补偿金违法': ['违约金','300万','300万元','退还','补偿金','退回','继续履行'],
}

ALL_RULES = [
    ('gen_h1','合同主体与成立要件','民法典第143条：签约主体须具有民事行为能力'),
    ('gen_h2','格式条款公平性','民法典第497条：格式条款不得显失公平'),
    ('gen_h3','违约金不得过高','民法典第585条：违约金不超实际损失30%'),
    ('gen_h4','免责条款效力','民法典第506条：不得免除人身损害和故意/重大过失责任'),
    ('gen_h5','争议管辖有效性','民事诉讼法第35条：管辖约定须明确有效'),
    ('svc_h1','服务内容与验收标准','民法典第510条：质量约定不明按行业标准履行'),
    ('svc_h2','知识产权归属','著作权法第19条：委托创作知产归属须明确约定'),
    ('svc_h3','任意解除权','民法典第933条：委托人可随时解除委托合同'),
    ('svc_h4','保密义务','民法典第501条：合同订立中知悉的商业秘密不得泄露'),
    ('svc_h5','付款与交付','民法典第928条：受托人完成委托事务应支付报酬'),
    ('sale_h1','质量瑕疵担保','民法典第617条：出卖人须承担质量瑕疵担保责任'),
    ('sale_h2','检验期限合理性','民法典第621条：检验期限不得过短'),
    ('sale_h3','标的物合法性','民法典第597条：出卖人须对标的物有处分权'),
    ('data_h1','数据安全保护措施','个人信息保护法第51条/数据安全法第27条：须采取安全措施'),
    ('data_h2','委托处理个人信息约束','个人信息保护法第21条：受托人不得超出约定目的处理'),
    ('data_h3','合同终止后数据删除','个人信息保护法第21条：合同终止后应返还或删除个人信息'),
]


def parse_contract(fp):
    with open(fp, 'r', encoding='utf-8') as f:
        content = f.read()
    meta = {}
    if content.startswith('---'):
        parts = content.split('---', 2)
        for line in parts[1].strip().split('\n'):
            if ':' in line:
                k, v = line.split(':', 1)
                k = k.strip(); v = v.strip()
                if k == 'risk_tags':
                    meta[k] = [t.strip().strip("'\"") for t in v.strip('[]').split(',')]
                elif k == 'risk_count':
                    meta[k] = int(v)
                else:
                    meta[k] = v
        text = parts[2].strip()
    else:
        text = content
    return meta, text


def activate_masks(text):
    search = (text or '')[:8000]
    active = ['general']
    for mid, kws in MASKS_ACT.items():
        if sum(1 for kw in kws if kw in search) >= 2:
            active.append(mid)
    return active


def call_ai(payload, timeout=60):
    try:
        r = requests.post(API_URL, json={'tool': 'contract-risk', **payload}, timeout=timeout)
        if r.status_code != 200:
            return {'error': f'HTTP {r.status_code}'}
        d = r.json()
        return {'content': d.get('content', str(d)), 'usage': d.get('usage', {})}
    except Exception as e:
        return {'error': str(e)}


def check_risk(text, tag):
    if tag not in RISK_KW:
        return False
    kws = RISK_KW[tag]
    t = text.lower()
    hits = sum(1 for kw in kws if kw in t)
    return hits >= 2


def build_prompts(text):
    g1 = {
        'model': 'deepseek-v4-flash',
        'messages': [
            {'role': 'system', 'content': '你是法律合同审查专家。逐条列出合同中的所有法律风险、商业风险、程序缺失。每条标注：风险描述、涉及条款、法律依据、严重程度。以JSON数组返回：[{risk, clause, law, severity}]。只输出JSON。'},
            {'role': 'user', 'content': '请分析以下合同：\n' + text}
        ]
    }
    rules_txt = '\n'.join(f'{i+1}. [{r[0]}] {r[1]} — {r[2]}' for i, r in enumerate(ALL_RULES))
    g3a = {
        'model': 'deepseek-v4-flash',
        'messages': [
            {'role': 'system', 'content': '你是法律知识域分析工具。分析合同文本在法律知识域中的典型风险模式。输出涉及的法律领域、条款中隐藏的假设和利益失衡。以JSON输出：{domains:[], hiddenAssumptions:[], imbalanceRisks:[{clause, risk, bias}]}'},
            {'role': 'user', 'content': '请分析以下合同：\n' + text}
        ]
    }
    g3b = {
        'model': 'deepseek-v4-flash',
        'messages': [
            {'role': 'system', 'content': '你是严格的法律推理工具。逐项对照审查规则进行合规判定。对各参与方进行利益结构分析——哪一方承担了不成比例的风险。以JSON数组返回：[{id, found, status, riskCategory, finding, recommendation, bias, riskScore}]'},
            {'role': 'user', 'content': '合同全文：\n' + text + '\n\n审查规则：\n' + rules_txt + '\n\n请逐项分析。只输出JSON数组。'}
        ]
    }
    return g1, g3a, g3b


def main():
    files = sorted([f for f in os.listdir(TEST_DIR) if f.endswith('.md')])
    results = []

    for fn in files:
        fp = os.path.join(TEST_DIR, fn)
        meta, text = parse_contract(fp)
        masks = activate_masks(text)
        tags = meta.get('risk_tags', [])
        source = meta.get('source', '')

        print(f'\n{"="*60}')
        print(f'{fn}')
        print(f'来源: {source}')
        print(f'已知风险({len(tags)}): {tags}')
        print(f'激活蒙版: {masks}')

        g1_prompt, g3a_prompt, g3b_prompt = build_prompts(text)

        # G1: bare AI
        print('  [G1] 裸AI...', end=' ', flush=True)
        g1_resp = call_ai(g1_prompt)
        g1_hits = []; g1_miss = list(tags)
        if 'error' in g1_resp:
            print(f'ERROR: {g1_resp["error"]}')
            g1_hallu = 0
        else:
            g1_text = g1_resp.get('content', '')
            g1_hits = [t for t in tags if check_risk(g1_text, t)]
            g1_miss = [t for t in tags if t not in g1_hits]
            # Count law refs
            law_refs = re.findall(r'(民法典|劳动合同法|专利法|著作权法|个人信息保护法|数据安全法)\s*第[零一二三四五六七八九十百千\d]+条', g1_text)
            fake_refs = re.findall(r'[《]?([^《》\s]{2,8}法)[》]?\s*第[零一二三四五六七八九十百千\d]+条', g1_text)
            real_laws = ['民法典','刑法','劳动法','劳动合同法','公司法','个人信息保护法','数据安全法','网络安全法','专利法','商标法','著作权法','反垄断法','社会保险法','民事诉讼法']
            g1_hallu = sum(1 for r in fake_refs if not any(l in r for l in real_laws))
            print(f'检出{len(g1_hits)}/{len(tags)} | 法条{len(law_refs)}次(幻觉{g1_hallu})')
            if g1_miss: print(f'    漏检: {g1_miss}')
            if g1_hits: print(f'    命中: {g1_hits}')
            # Show a snippet
            snippet = g1_text[:300].replace('\n', ' ')
            print(f'    输出: {snippet}...')

        # G3: V3 dual-path
        print('  [G3] +RAG+V3...', end=' ', flush=True)
        g3a_resp = call_ai(g3a_prompt)
        time.sleep(0.3)
        g3b_resp = call_ai(g3b_prompt)

        g3a_ok = 'error' not in g3a_resp
        g3b_ok = 'error' not in g3b_resp
        g3a_text = g3a_resp.get('content', '') if g3a_ok else ''
        g3b_text = g3b_resp.get('content', '') if g3b_ok else ''
        g3_combined = (g3a_text + '\n' + g3b_text).lower()

        g3_hits = [t for t in tags if check_risk(g3_combined, t)]
        g3_miss = [t for t in tags if t not in g3_hits]
        errors = (0 if g3a_ok else 1) + (0 if g3b_ok else 1)

        # Count law refs
        law_refs_g3 = re.findall(r'(民法典|劳动合同法|专利法|著作权法|个人信息保护法|数据安全法)\s*第[零一二三四五六七八九十百千\d]+条', g3b_text)
        fake_refs_g3 = re.findall(r'[《]?([^《》\s]{2,8}法)[》]?\s*第[零一二三四五六七八九十百千\d]+条', g3b_text)
        real_laws = ['民法典','刑法','劳动法','劳动合同法','公司法','个人信息保护法','数据安全法','网络安全法','专利法','商标法','著作权法','反垄断法','社会保险法','民事诉讼法']
        g3_hallu = sum(1 for r in fake_refs_g3 if not any(l in r for l in real_laws))

        status = '✓' if errors == 0 else f'⚠({errors}err)'
        print(f'{status} 检出{len(g3_hits)}/{len(tags)} | 法条{len(law_refs_g3)}次(幻觉{g3_hallu})')
        if g3_miss: print(f'    漏检: {g3_miss}')
        if g3_hits: print(f'    命中: {g3_hits}')

        results.append({
            'file': fn, 'source': source,
            'tags': tags, 'masks': masks,
            'g1_hits': g1_hits, 'g1_miss': g1_miss, 'g1_hallu': g1_hallu,
            'g3_hits': g3_hits, 'g3_miss': g3_miss, 'g3_hallu': g3_hallu,
        })

        time.sleep(0.5)

    # Summary
    total_risks = sum(len(r['tags']) for r in results)
    g1_total = sum(len(r['g1_hits']) for r in results)
    g3_total = sum(len(r['g3_hits']) for r in results)
    g1_hallu_total = sum(r['g1_hallu'] for r in results)
    g3_hallu_total = sum(r['g3_hallu'] for r in results)

    print(f'\n{"="*60}')
    print(f'真实合同测试汇总')
    print(f'{len(results)}份合同, {total_risks}个已知风险')
    print(f'组1 裸AI: {g1_total}/{total_risks} = {g1_total/total_risks*100:.1f}% | 幻觉{g1_hallu_total}次')
    print(f'组3 V3:   {g3_total}/{total_risks} = {g3_total/total_risks*100:.1f}% | 幻觉{g3_hallu_total}次')
    for r in results:
        print(f'  {r["file"]}: G1={len(r["g1_hits"])}/{len(r["tags"])} G3={len(r["g3_hits"])}/{len(r["tags"])} | 漏检: G1={r["g1_miss"]} G3={r["g3_miss"]}')

    # Save results
    with open(os.path.join(TEST_DIR, 'real_results.json'), 'w', encoding='utf-8') as f:
        json.dump({'summary': {
            'total_contracts': len(results), 'total_risks': total_risks,
            'g1_hits': g1_total, 'g3_hits': g3_total,
            'g1_rate': round(g1_total/total_risks*100, 1),
            'g3_rate': round(g3_total/total_risks*100, 1),
            'g1_hallu': g1_hallu_total, 'g3_hallu': g3_hallu_total,
        }, 'results': results}, f, ensure_ascii=False, indent=2)
    print(f'\n结果已保存: real_results.json')


if __name__ == '__main__':
    main()
