---
contract_id: R05
contract_type: 软件许可及服务合同（AI生物科技）
source: FOXO Technologies vs KR8 AI · SEC Exhibit 99.1 · 2024-01-12
risk_tags: [许可范围过度受限, 服务终止权单方化, 验收标准缺失, 竞业限制模糊, 数据权利归属不明]
risk_count: 5
annotator: 人工标注（非AI）
---

MASTER SOFTWARE AND SERVICES AGREEMENT

BETWEEN: KR8 AI Inc. ("Licensor"), a Nevada corporation
AND: FOXO Technologies Inc. ("Licensee"), a Delaware corporation

RECITAL: Licensee desires to develop and launch an AI machine learning epigenetic APP to enhance health, wellness and longevity. Licensor shall provide a license to use Licensor Products underlying the KR8 AI ecosystem.

1. LICENSE GRANT
Licensor grants Licensee a limited, non-sublicensable, non-transferable perpetual license to use the Licensor Products to develop, launch and maintain Licensee Applications within the United States, Canada and Mexico (the "Territory"). Licensee shall use Licensor Products solely for Licensee's business purposes and shall not provide any Licensor Products to any party other than individual consumer End Users.

2. LICENSE RESTRICTIONS
Licensee shall not: (i) copy, modify, or create derivative works; (ii) rent, lease, lend, sell, sublicense, assign, distribute, publish, transfer, or otherwise make available the Software; (iii) reverse engineer, disassemble, decompile, decode, or attempt to derive source code; (iv) remove proprietary notices; (v) use the Software for competing with Licensor; (vi) use the Software in any manner that infringes any intellectual property right.

(The prohibition on "competing with Licensor" is broadly defined and could restrict Licensee's legitimate business activities in adjacent health-tech markets.)

3. SERVICE TERMINATION
Nothing in this Agreement shall obligate Licensor to continue providing access to any Service beyond the date when Licensor ceases providing such Service to Licensees generally. Licensor reserves all rights not expressly granted to Licensee.

(Licensor can unilaterally discontinue any service without obligation to Licensee. Licensee's business depends on continued access to AI models and infrastructure.)

4. PROFESSIONAL SERVICES AND DELIVERABLES
Licensor shall provide Services to develop algorithms and assist with the development of cross-platform capabilities. Upon receipt of a request, Licensor may provide Professional Services including deployment, customization, integration services.

(No service level agreement, no delivery milestones, no acceptance criteria specified.)

5. DATA AND INTELLECTUAL PROPERTY
Licensee Applications shall process information and provide data and recommendations to End Users. (The Agreement does not address ownership of End User data processed through the platform, nor the intellectual property rights in any customizations or integrations developed by Licensor for Licensee.)

Signed by the Parties on 12 January 2024.
