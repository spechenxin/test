---
contract_id: R04
contract_type: 技术服务合同（AI开发）
source: Treasure Global Inc vs V Gallant Sdn Bhd · SEC Exhibit 10.1 · 2024-10-29
risk_tags: [付款与交付脱钩, 验收标准缺失, IP归属模糊, 单方终止权缺失, 不可抗力条款过宽]
risk_count: 5
annotator: 人工标注（非AI）
---

SERVICE AGREEMENT

BETWEEN: Treasure Global Inc ("TGL"), a Delaware corporation
AND: V Gallant Sdn Bhd ("V Gallant"), a Malaysian company

RECITAL: TGL wishes to develop an AI-enabled live streaming platform and AI digital human solutions. V Gallant has expertise in developing generative AI solutions and AI digital human technology using technology supplied by NVIDIA Corporation.

1. SERVICES
V Gallant shall design, develop and deliver the Live Streaming Platform for TGL. The Platform shall be engineered to enable high-quality live streaming capabilities enhanced by AI Digital Human Solutions, providing interactive experiences that align with industry technical standards and user experience (UX) requirements.

V Gallant shall develop the Live Streaming Platform in accordance with TGL's detailed specifications, including but not limited to AI model development and training, digital human appearance and personality customization, language processing and generation capabilities, emotional intelligence and expression systems, and real-time interaction mechanisms.

V Gallant shall ensure that the Live Streaming Platform and the AI Digital Human Solutions comply with all applicable technical standards, industry best practices, data security protocols, data privacy laws, encryption standards, any specific requirements mandated by Third-Party Platforms, and adherence to streaming media standards and protocols.

2. FEES AND PAYMENT
TGL agrees to pay V Gallant a total consideration of USD 16,000,000 for the Services and all associated hardware and software under this Agreement.

Payment schedule:
- 50% (USD 8,000,000) shall be settled via the issuance of TGL Shares
- 50% (USD 8,000,000) shall be paid in twelve (12) equal monthly instalments, commencing from 31 January 2025

(No payment milestones linked to delivery milestones or acceptance criteria.)

3. TERM
The Services under this Agreement shall commence on the date of this Agreement and shall be valid until 31 December 2025, unless terminated by either Party due to any breach or default of this Agreement.

(No provision for TGL to terminate for convenience or if V Gallant fails to meet milestones.)

4. INTELLECTUAL PROPERTY
"IP Rights" means patents, rights to inventions, copyright, trademarks, trade secrets, and all other intellectual property rights.

(The Agreement defines IP Rights but does not specify ownership of the developed AI platform, digital human solutions, or any deliverables created under this Agreement.)

5. FORCE MAJEURE
Neither Party shall be liable for any failure or delay in performing its obligations under this Agreement if such failure or delay is caused by an Event of Force Majeure. "Event of Force Majeure" includes acts of God, war, terrorism, fire, flood, earthquake, epidemic, pandemic, government actions, sanctions, and any other circumstances beyond the reasonable control of the affected Party.

6. GOVERNING LAW
This Agreement shall be governed by and construed in accordance with the laws of Malaysia.

Signed by the Parties on 29 October 2024.
