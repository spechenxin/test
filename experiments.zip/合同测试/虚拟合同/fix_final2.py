#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Fix Chinese quotes in gen_answers.py - final approach"""

import re, sys

def fix_inner(s):
    """Keep first and last ", replace remaining with corner brackets"""
    positions = [i for i, c in enumerate(s) if c == '"']
    if len(positions) < 4:
        return s
    chars = list(s)
    keep = {positions[0], positions[-1]}
    inner = [p for p in positions if p not in keep]
    for i, p in enumerate(inner):
        chars[p] = '\u300c' if i % 2 == 0 else '\u300d'
    return ''.join(chars)

with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Restore original
content = ''.join(lines)
content = content.replace('\u300c', '"').replace('\u300d', '"')
lines = content.split('\n')
lines = [l + '\n' for l in lines[:-1]] + ([lines[-1]] if lines[-1] else [])

skip_prefixes = (
    '"""', '#', 'def ', 'import ', 'from ', 'for ', 'if ', 'elif ',
    'h =', 'add_', 'p ', 'p2', 'p3', 'p4', 'run ', 'output_', 'doc.',
    'print(', 'with ', 'return', 'else', 'try', 'except', 'finally',
    'style', 'font', 'content', 'h.alignment', 'for run', 'for t ',
    'answers.append', 'answers =', 'doc.add_', 'for idx', 'for ans',
    'for i,', 'for clause', 'for line', 'ans[', 'add_risk', 'add_body', 'add_title',
    'for run in', 'run.font',
)

fixed = []
i = 0
while i < len(lines):
    line = lines[i]
    s = line.strip()

    if not s:
        fixed.append(line); i += 1; continue
    if any(s.startswith(p) for p in skip_prefixes):
        fixed.append(line); i += 1; continue

    cnt = line.count('"')
    if cnt < 4:
        fixed.append(line); i += 1; continue

    # Skip lines that have key-value dict structure (contain "\": pattern)
    # These are structural lines, not content strings
    if re.search(r'\"\s*:\s', line):
        fixed.append(line); i += 1; continue

    # Dict value line: "key": "value with "inner" quotes",
    m = re.match(r'^(\s*"[^"]*"\s*:\s*)"(.*)"(\s*,\s*)$', line)
    if m:
        # Fix only the value part (group 2)
        wrapped = '"' + m.group(2) + '"'
        fv = fix_inner(wrapped)
        result = m.group(1) + fv + m.group(3)
        fixed.append(result); i += 1; continue

    # Tuple content line: ("label", "content with "inner" quotes"),
    m = re.match(r'^(\s*\("[^"]*"\s*,\s*)"(.*)"(\s*\)\s*,?\s*)$', line)
    if m:
        wrapped = '"' + m.group(2) + '"'
        fv = fix_inner(wrapped)
        result = m.group(1) + fv + m.group(3)
        fixed.append(result); i += 1; continue

    # Needs to also handle multi-line continuations
    # Generic content line
    fixed.append(fix_inner(line))
    i += 1

with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'w', encoding='utf-8') as f:
    f.writelines(fixed)

# Verify: try compiling
try:
    with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'r', encoding='utf-8') as f:
        compile(f.read(), 'gen_answers.py', 'exec')
    print('SUCCESS: File compiles without errors')
except SyntaxError as e:
    print(f'SYNTAX ERROR: line {e.lineno}: {e.msg}')
    # Show the problematic line
    with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'r', encoding='utf-8') as f:
        blines = f.readlines()
    if e.lineno and e.lineno <= len(blines):
        print(f'  Content: {blines[e.lineno-1].rstrip()[:200]}')
