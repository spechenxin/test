#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Build answer docx from data file (avoids quote conflicts)"""

from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
import json

# Load data
with open(r'C:\Users\infinite\Desktop\answers_data.json', 'r', encoding='utf-8') as f:
    answers = json.load(f)

doc = Document()
style = doc.styles['Normal']
font = style.font
font.name = '宋体'
font.size = Pt(10.5)
style.element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')

def add_title(text, level=1):
    h = doc.add_heading(text, level=level)
    for run in h.runs:
        run.font.color.rgb = RGBColor(0, 51, 102)
    return h

def add_body(text):
    p = doc.add_paragraph(text)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = Pt(17)
    return p

def add_risk_item(label, detail):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = Pt(17)
    run = p.add_run(label + ' ')
    run.bold = True
    run.font.color.rgb = RGBColor(180, 0, 0)
    p.add_run(detail)
    return p

# Cover
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.paragraph_format.space_before = Pt(120)
run = p.add_run('企业法律风险识别测试题库')
run.bold = True
run.font.size = Pt(22)
run.font.color.rgb = RGBColor(0, 51, 102)

p2 = doc.add_paragraph()
p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
run2 = p2.add_run('参考答案与解析')
run2.font.size = Pt(16)

p3 = doc.add_paragraph()
p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
p3.paragraph_format.space_before = Pt(20)
run3 = p3.add_run('20套模拟合同 \u00b7 风险点逐条拆解 + 修改建议')
run3.font.size = Pt(12)
run3.font.color.rgb = RGBColor(100, 100, 100)

p4 = doc.add_paragraph()
p4.alignment = WD_ALIGN_PARAGRAPH.CENTER
p4.paragraph_format.space_before = Pt(30)
run4 = p4.add_run('2026年6月28日')
run4.font.size = Pt(10)
run4.font.color.rgb = RGBColor(150, 150, 150)

doc.add_page_break()

# Generate content
for ans in answers:
    if ans['id'] == 1:
        add_title('第一部分：企业合同风险', level=1)
    elif ans['id'] == 6:
        doc.add_page_break()
        add_title('第二部分：用工风险', level=1)
    elif ans['id'] == 11:
        doc.add_page_break()
        add_title('第三部分：数据合规', level=1)
    elif ans['id'] == 16:
        doc.add_page_break()
        add_title('第四部分：国际贸易', level=1)

    doc.add_page_break()
    h = doc.add_heading('测试 {} \u2014 {}'.format(ans['id'], ans['title']), level=2)
    for run in h.runs:
        run.font.color.rgb = RGBColor(0, 51, 102)

    add_body('\u3010{}\u3011共识别 {} 个主要风险点。\n'.format(ans['category'], len(ans['risks'])))

    for i, risk in enumerate(ans['risks'], 1):
        add_risk_item('风险点 {}：{}'.format(i, risk['label']), risk['detail'])

output_path = r'C:\Users\infinite\Desktop\企业法律风险测试题库_参考答案.docx'
doc.save(output_path)
print('OK: ' + output_path)
