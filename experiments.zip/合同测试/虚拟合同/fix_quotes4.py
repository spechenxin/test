#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Fix Chinese quotation marks v4 - correct delimiter detection"""

import re

def find_prev_non_space(chars, pos):
    """Find previous non-whitespace char before pos"""
    for i in range(pos-1, -1, -1):
        if chars[i] not in ' \t':
            return chars[i], i
    return '', -1

def find_next_non_space(chars, pos):
    """Find next non-whitespace char after pos"""
    for i in range(pos+1, len(chars)):
        if chars[i] not in ' \t':
            return chars[i], i
    return '', -1

def is_python_delimiter(chars, pos):
    """Check if the " at pos is a Python string delimiter (not a Chinese quote)"""
    n = len(chars)

    # Closing delimiter: " followed by , ) ] : or at end of line/file
    if pos == n - 1:
        return True
    if chars[pos+1] in ',)]:\n':
        return True

    # Opening delimiter: " preceded by ( [ , = : (possibly with whitespace)
    if pos == 0:
        return True
    # If " is first non-whitespace character on its line
    line_start = True
    for i in range(pos-1, -1, -1):
        if chars[i] == '\n':
            break
        if chars[i] not in ' \t':
            line_start = False
            break
    if line_start:
        return True
    prev_ch = chars[pos-1]
    if prev_ch in '([,=:\n\t':
        return True
    if prev_ch in ' \t' and pos > 1:
        prev2 = chars[pos-2]
        if prev2 in '([,=:\t':
            return True
        if prev2 in ' \t' and pos > 2:
            prev3 = chars[pos-3]
            if prev3 in '([,=:\t':
                return True

    return False


def fix_line(line):
    positions = [i for i, c in enumerate(line) if c == '"']
    if len(positions) < 4:
        return line

    chars = list(line)
    cjk_pattern = re.compile(r'[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]')

    inner_positions = []
    for pos in positions:
        if is_python_delimiter(chars, pos):
            continue
        prev_ch = chars[pos-1] if pos > 0 else ''
        next_ch = chars[pos+1] if pos < len(chars)-1 else ''
        prev_cjk = bool(cjk_pattern.match(prev_ch))
        next_cjk = bool(cjk_pattern.match(next_ch))
        if prev_cjk or next_cjk:
            inner_positions.append(pos)

    if len(inner_positions) < 2:
        return line

    for i, pos in enumerate(sorted(inner_positions)):
        if i % 2 == 0:
            chars[pos] = '\u300c'
        else:
            chars[pos] = '\u300d'

    return ''.join(chars)


with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Undo all previous fixes: restore corner brackets to regular quotes
content = ''.join(lines)
content = content.replace('\u300c', '"').replace('\u300d', '"')
lines = content.split('\n')
lines = [l + '\n' for l in lines[:-1]] + ([lines[-1]] if lines[-1] else [])

skipped_prefixes = (
    '"""', '#', 'def ', 'import ', 'from ', 'for ', 'if ', 'elif ',
    'h =', 'add_', 'p ', 'p2', 'p3', 'p4', 'run ', 'output_', 'doc.',
    'print(', 'with ', 'return', 'else', 'try', 'except', 'finally',
    'style', 'font', 'content', 'h.alignment', 'ans[', 'answers.append',
    'answers =', 'doc.add_', 'for idx', 'for t in',
)

fixed = []
for line in lines:
    stripped = line.strip()

    if not stripped:
        fixed.append(line)
        continue

    if any(stripped.startswith(p) for p in skipped_prefixes):
        fixed.append(line)
        continue

    # For dict key-value lines, fix the VALUE part separately
    # Pattern: "key": "value with possible inner quotes",
    m = re.match(r'^(\s*"[^"]+"\s*:\s*")(.*)("\s*,?\s*\)?\s*)$', line)
    if m:
        prefix = m.group(1)
        value_part = m.group(2)
        suffix = m.group(3)
        # Fix inner Chinese quotes in the value part only
        fixed_value = fix_line('"' + value_part + '"')
        # Strip the outer quotes we added back
        fixed_value = fixed_value[1:-1]
        fixed.append(prefix + fixed_value + suffix)
        continue

    fixed.append(fix_line(line))

with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'w', encoding='utf-8') as f:
    f.writelines(fixed)

print('Fixed v4')
