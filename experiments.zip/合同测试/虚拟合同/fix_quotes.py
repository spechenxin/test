#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Fix Chinese quotation marks in gen_answers.py"""

import re

with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

fixed = []
for line in lines:
    # Count double quotes
    cnt = line.count('"')
    stripped = line.strip()

    # Skip lines that are clearly Python code or dict structures
    if (stripped.startswith('"""') or stripped.startswith('#') or
        stripped.startswith('def ') or stripped.startswith('import ') or
        stripped.startswith('from ') or stripped.startswith('for ') or
        stripped.startswith('if ') or stripped.startswith('elif ') or
        stripped.startswith('h =') or stripped.startswith('add_') or
        stripped.startswith('p ') or stripped.startswith('run ') or
        stripped.startswith('output_') or stripped.startswith('doc.') or
        stripped.startswith('print(') or stripped.startswith('ans[') or
        stripped == ''):
        fixed.append(line)
        continue

    # Dict key-value lines like "id": 1, "category": "X" are fine
    if '":' in stripped:
        fixed.append(line)
        continue

    if cnt < 3:
        fixed.append(line)
        continue

    # This line has inner Chinese quotes that need fixing
    # Strategy: find inner " pairs surrounded by CJK context
    chars = list(line)
    result = []
    i = 0
    while i < len(chars):
        ch = chars[i]
        if ch == '"':
            # Check context to determine if this is a Chinese quote
            prev_ch = chars[i-1] if i > 0 else '\0'
            next_ch = chars[i+1] if i < len(chars)-1 else '\0'

            # Chinese quote: preceded by CJK char or certain punctuation
            prev_cjk = (
                '\u4e00' <= prev_ch <= '\u9fff' or
                '\u3000' <= prev_ch <= '\u303f' or
                '\uff00' <= prev_ch <= '\uffef' or
                prev_ch in '>（—，。、；：）】》\u2014'
            )
            # Chinese quote: followed by CJK char
            next_cjk = (
                '\u4e00' <= next_ch <= '\u9fff' or
                '\u3000' <= next_ch <= '\u303f' or
                '\uff00' <= next_ch <= '\uffef'
            )

            # Opening Chinese quote: not preceded by CJK but followed by CJK
            if next_cjk and not prev_cjk:
                # But make sure this isn't a Python delimiter (start of string)
                if prev_ch not in '\n\t ([':
                    result.append('\u300c')  # 「
                    i += 1
                    continue

            # Closing Chinese quote: preceded by CJK but not followed by CJK
            if prev_cjk and not next_cjk:
                result.append('\u300d')  # 」
                i += 1
                continue

        result.append(ch)
        i += 1

    fixed.append(''.join(result))

with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'w', encoding='utf-8') as f:
    f.writelines(fixed)

print('Fixed gen_answers.py - Chinese quotes replaced with corner brackets')
