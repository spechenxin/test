#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Fix Chinese quotation marks: replace inner ASCII " used as Chinese quotes with corner brackets"""

import re

def fix_line(line):
    """Replace inner Chinese double quotes with corner brackets 「」"""
    positions = [i for i, c in enumerate(line) if c == '"']
    if len(positions) < 3:
        return line

    chars = list(line)
    cjk_pattern = re.compile(r'[\u4e00-\u9fff\u3000-\u303f\uff00-\uffef]')

    # Find "inner" quotes: those adjacent to CJK characters
    inner_positions = []
    for pos in positions:
        prev_ch = chars[pos-1] if pos > 0 else ''
        next_ch = chars[pos+1] if pos < len(chars)-1 else ''
        prev_cjk = bool(cjk_pattern.match(prev_ch))
        next_cjk = bool(cjk_pattern.match(next_ch))
        if prev_cjk or next_cjk:
            inner_positions.append(pos)

    if len(inner_positions) < 2:
        return line

    # Replace inner quotes with corner brackets in alternating pairs
    for i, pos in enumerate(inner_positions):
        if i % 2 == 0:
            chars[pos] = '\u300c'  # left corner bracket
        else:
            chars[pos] = '\u300d'  # right corner bracket

    return ''.join(chars)


with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# First, undo all previous fix attempts
content = ''.join(lines)
content = content.replace('\u300c', '"').replace('\u300d', '"')
lines = content.split('\n')
lines = [l + '\n' for l in lines[:-1]] + ([lines[-1]] if lines[-1] else [])

# Now apply the fix
fixed = []
for line in lines:
    stripped = line.strip()

    # Skip Python code, dict k-v, comments
    if (stripped.startswith('"""') or stripped.startswith('#') or
        stripped.startswith('def ') or stripped.startswith('import ') or
        stripped.startswith('from ') or stripped.startswith('for ') or
        stripped.startswith('if ') or stripped.startswith('elif ') or
        stripped.startswith('h =') or stripped.startswith('add_') or
        stripped.startswith('p ') or stripped.startswith('run ') or
        stripped.startswith('output_') or stripped.startswith('doc.') or
        stripped.startswith('print(') or stripped.startswith('ans[') or
        stripped.startswith('with ') or stripped.startswith('return') or
        stripped.startswith('else') or stripped.startswith('try') or
        stripped.startswith('except') or stripped.startswith('finally') or
        stripped == ''):
        fixed.append(line)
        continue

    # Dict lines with colon pattern are fine (count is even by design)
    if re.match(r'^\s*"[^"]+"\s*:', stripped):
        fixed.append(line)
        continue

    fixed.append(fix_line(line))

with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'w', encoding='utf-8') as f:
    f.writelines(fixed)

print('Fixed gen_answers.py')
