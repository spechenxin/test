#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Fix Chinese/English quotation marks in gen_answers.py
Strategy: for content lines, keep first and last " as Python delimiters,
replace all inner " pairs with corner brackets.
For complex lines (dict values, tuples), parse structure first.
"""

import re

def fix_inner_quotes(text):
    """
    Given a string that contains inner " used as Chinese/English quotation marks,
    keep the first and last " as delimiters, replace inner " pairs with corner brackets.
    """
    positions = [i for i, c in enumerate(text) if c == '"']
    if len(positions) < 4:
        return text

    chars = list(text)
    # Mark first and last position to keep
    keep = {positions[0], positions[-1]}

    # All other positions are inner quotes
    inner = [p for p in positions if p not in keep]

    for i, pos in enumerate(inner):
        if i % 2 == 0:
            chars[pos] = '\u300c'  # opening corner bracket
        else:
            chars[pos] = '\u300d'  # closing corner bracket

    return ''.join(chars)


with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Undo all previous fixes
content = ''.join(lines)
content = content.replace('\u300c', '"').replace('\u300d', '"')
lines = content.split('\n')
lines = [l + '\n' for l in lines[:-1]] + ([lines[-1]] if lines[-1] else [])

# Lines to skip entirely (pure Python, not data)
skip_prefixes = (
    '"""', '#', 'def ', 'import ', 'from ', 'for ', 'if ', 'elif ',
    'h =', 'add_', 'p ', 'p2', 'p3', 'p4', 'run ', 'output_', 'doc.',
    'print(', 'with ', 'return', 'else', 'try', 'except', 'finally',
    'style', 'font', 'content', 'h.alignment', 'for run', 'for t in',
    'answers.append', 'answers =', 'doc.add_', 'for idx', 'for ans',
)

fixed = []
i = 0
while i < len(lines):
    line = lines[i]
    stripped = line.strip()

    if not stripped:
        fixed.append(line)
        i += 1
        continue

    if any(stripped.startswith(p) for p in skip_prefixes):
        fixed.append(line)
        i += 1
        continue

    # Count quotes
    cnt = line.count('"')
    if cnt < 4:
        fixed.append(line)
        i += 1
        continue

    # For dict lines: "key": "value with "inner" quotes",
    # Keep the key and separator, fix only the value part
    m = re.match(r'^(\s*"([^"]*)"\s*:\s*)"(.*)"(\s*,?\s*\)?\s*)$', line)
    if m:
        prefix = m.group(1)   # "key":
        value = m.group(3)    # value content (without outer quotes)
        suffix = m.group(4)   # ", / "), etc.
        # Re-wrap value with quotes and fix
        wrapped = '"' + value + '"'
        fixed_val = fix_inner_quotes(wrapped)
        if fixed_val != wrapped:
            # Stripped outer quotes
            inner_fixed = fixed_val[1:-1]
            fixed.append(prefix + '"' + inner_fixed + '"' + suffix)
            i += 1
            continue

    # For tuple lines: ("label", "content with "inner" quotes"),
    m = re.match(r'^(\s*\()"([^"]*)"\s*,\s*"(.*)"(\s*\)\s*,?\s*)$', line)
    if m:
        prefix = m.group(1) + '"' + m.group(2) + '", "'
        content_part = m.group(3)
        suffix = '"' + m.group(4)
        wrapped = '"' + content_part + '"'
        fixed_val = fix_inner_quotes(wrapped)
        if fixed_val != wrapped:
            fixed.append(prefix + fixed_val[1:-1] + suffix)
            i += 1
            continue

    # Generic content line: "content with "inner" quotes",
    # Keep first and last ", fix inner
    fixed.append(fix_inner_quotes(line))
    i += 1

with open(r'C:\Users\infinite\Desktop\gen_answers.py', 'w', encoding='utf-8') as f:
    f.writelines(fixed)

print('Fixed (final)')
