"""
V4 五维评分评测 — LLM-as-Judge (MT-Bench 风格)
评测模型: DeepSeek V4 Pro
盲评设计: judge 不知道条件标签

五维: 指令遵循 学科交叉 逻辑严密 现实洞察 结构清晰
每维 1-10 分，总分 50
"""

import httpx
import asyncio
import time
import json
import os
import random
from datetime import datetime

API_KEY = os.environ.get("ANTHROPIC_API_KEY", "sk-8d69425407474284afbf9278c948b6a7")
API_BASE = os.environ.get("ANTHROPIC_BASE_URL", "https://api.deepseek.com/anthropic")
API_URL = f"{API_BASE}/v1/messages"
MODEL = "deepseek-v4-pro[1m]"
MAX_TOKENS = 1024
DELAY = 1.0

RESULTS_FILE = "D:/document/infinite/experiments/v3_routing_v2/results_v4_20260706_173652.json"
OUTPUT_FILE = "D:/document/infinite/experiments/v3_routing_v2/v4_evaluation_scores.json"

with open(RESULTS_FILE, "r", encoding="utf-8") as f:
    results = json.load(f)

# Load question texts
import sys
sys.path.insert(0, ".")
from run_v4 import QUESTIONS
QUESTION_MAP = {q["id"]: q["question"] for q in QUESTIONS}

EVAL_PROMPT = """你是一位严格的学术评审专家。请根据以下五个维度，对下列回答进行量化评分。每个维度1-10分（可以是小数，如7.5分）。

【评分维度】

1. 指令遵循度与身份代入感 (1-10)
   - 回答是否按题目要求使用了学科分析框架？是否明确了分析视角？
   - 10分：完全按照学科框架分析，每个维度都有对应的学科工具和术语
   - 5分：虽然涵盖要点，但缺乏学科特有的术语和深度
   - 1分：完全忽略题目要求的分析框架

2. 学科交叉的深度与适配性 (1-10)
   - 是否真正实现了多学科交叉分析？还是只是把学科名词并列堆砌？
   - 10分：不同学科视角之间有逻辑咬合，产生了跨域洞察
   - 5分：各学科分别论述但缺乏交叉互动
   - 1分：单一视角或各学科生拼硬凑

3. 逻辑推演的严密性 (1-10)
   - 从分析到结论是否有清晰的因果链条？是否存在逻辑断层？
   - 10分：因果闭环，有辩证思维（正反两面），逻辑链完整可追踪
   - 5分：线性思维，有基本逻辑但缺乏深度推理
   - 1分：逻辑混乱、自相矛盾或推理跳跃

4. 现实洞察与增量价值 (1-10)
   - 回答是否提供了超出常识的"新视角"？是否击中了问题的真正痛点？
   - 10分：提出了反直觉的洞察或具有实操价值的具体建议
   - 5分：观点正确但属于常规分析，无增量信息
   - 1分：老生常谈或脱离实际

5. 结构清晰度与可读性 (1-10)
   - 排版是否清晰？是否易于阅读和理解？
   - 10分：分段合理、有层次标题或逻辑标记、重点突出
   - 5分：有基本分段但结构不够清晰
   - 1分：大段堆砌、无结构

【输出格式】
仅输出以下JSON，不要输出任何其他文本：
{{
  "scores": {{
    "instruction_following": 0.0,
    "cross_disciplinary": 0.0,
    "logical_rigor": 0.0,
    "real_insight": 0.0,
    "structure": 0.0
  }},
  "total": 0.0,
  "comment": "一句话总评"
}}

---
【待评分的问题】
{question}

【待评分的回答】
{answer}

请评分（仅输出JSON）："""


async def evaluate_single(client, question, answer, label):
    prompt = EVAL_PROMPT.format(question=question, answer=answer[:6000])
    messages = [{"role": "user", "content": prompt}]

    for attempt in range(3):
        try:
            start_time = time.time()
            full_text = ""

            async with client.stream(
                "POST",
                API_URL,
                headers={
                    "x-api-key": API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": MODEL,
                    "max_tokens": MAX_TOKENS,
                    "messages": messages,
                    "stream": True,
                },
                timeout=120.0,
            ) as response:
                if response.status_code != 200:
                    body = await response.aread()
                    raise Exception(f"HTTP {response.status_code}")

                async for line in response.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str.strip() == "[DONE]":
                        break
                    try:
                        event = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue
                    etype = event.get("type", "")
                    if etype in ("content_block_delta",):
                        dt = event.get("delta", {}).get("text", "")
                        full_text += dt

            total_time = time.time() - start_time

            # Parse JSON from response
            full_text = full_text.strip()
            if full_text.startswith("```"):
                full_text = full_text.split("```")[1]
                if full_text.startswith("json"):
                    full_text = full_text[4:]
            try:
                scores = json.loads(full_text)
            except json.JSONDecodeError:
                # Try to extract JSON block
                import re
                match = re.search(r'\{.*\}', full_text, re.DOTALL)
                if match:
                    scores = json.loads(match.group(0))
                else:
                    raise ValueError(f"Cannot parse: {full_text[:200]}")

            return {
                "label": label,
                "scores": scores.get("scores", {}),
                "total": scores.get("total", sum(scores.get("scores", {}).values())),
                "comment": scores.get("comment", ""),
                "eval_time_s": round(total_time, 1),
                "error": None,
            }

        except Exception as e:
            if attempt < 2:
                await asyncio.sleep(2)
                continue
            return {
                "label": label,
                "scores": {},
                "total": 0,
                "comment": "",
                "eval_time_s": 0,
                "error": str(e)[:200],
            }


async def main():
    print(f"V4 五维评测 — MT-Bench 风格  样本数: {len(results)}")
    print(f"评测模型: {MODEL}  预计耗时: {len(results)*15/60:.0f}分钟")
    print("=" * 60)

    # Shuffle to avoid order bias
    idxs = list(range(len(results)))
    random.shuffle(idxs)

    all_evals = []
    start_time = time.time()

    async with httpx.AsyncClient() as client:
        for i, idx in enumerate(idxs):
            r = results[idx]
            q = r["question_title"] + "\n" + QUESTION_MAP.get(r["question_id"], "")
            ans = r.get("text", "")
            label = f"{r['question_id']}_{r['condition']}_R{r['round']}"

            elapsed = time.time() - start_time
            eta = (len(results) - i - 1) * (elapsed / (i + 1)) / 60 if i > 0 else 0

            print(f"[{i+1:>3}/{len(results)}] {label:<20} ", end="", flush=True)

            eval_result = await evaluate_single(client, q, ans, label)
            eval_result["question_id"] = r["question_id"]
            eval_result["question_title"] = r["question_title"]
            eval_result["condition"] = r["condition"]
            eval_result["round"] = r["round"]
            eval_result["eval_order"] = i + 1
            eval_result["rpu_r_ratio"] = r.get("rpu_r_ratio")

            all_evals.append(eval_result)

            if eval_result["error"]:
                print(f"❌ {eval_result['error'][:60]}")
            else:
                s = eval_result.get("scores", {})
                parts = [
                    f"指令={s.get('instruction_following',0):.0f}",
                    f"交叉={s.get('cross_disciplinary',0):.0f}",
                    f"逻辑={s.get('logical_rigor',0):.0f}",
                    f"洞察={s.get('real_insight',0):.0f}",
                    f"结构={s.get('structure',0):.0f}",
                    f"总分={eval_result['total']:.0f}",
                ]
                print(f"✅ {' '.join(parts)}")

            await asyncio.sleep(DELAY)

    # Save
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(all_evals, f, ensure_ascii=False, indent=2)

    # Summary
    valid = [e for e in all_evals if not e["error"]]
    print(f"\n{'='*60}")
    print(f"评测完成  成功: {len(valid)}/{len(all_evals)}  总耗时: {(time.time()-start_time)/60:.0f}min")
    print(f"结果: {OUTPUT_FILE}")

    if valid:
        # By condition
        print(f"\n--- 按条件汇总 ---")
        print(f"{'条件':<12} {'n':>4} {'指令':>6} {'交叉':>6} {'逻辑':>6} {'洞察':>6} {'结构':>6} {'总分':>7}  {'R比例':>6}")
        print("-" * 70)
        for cond in ["C1", "C2", "C3", "C4", "C5"]:
            ce = [e for e in valid if e["condition"] == cond]
            if not ce:
                continue
            n = len(ce)
            def avg(k):
                vals = [e["scores"].get(k, 0) for e in ce]
                return sum(vals)/len(vals) if vals else 0
            totals = [e["total"] for e in ce]
            rpu = [e.get("rpu_r_ratio", 0) or 0 for e in ce]
            print(
                f"{cond:<12} {n:>4}  "
                f"{avg('instruction_following'):>5.1f}  {avg('cross_disciplinary'):>5.1f}  "
                f"{avg('logical_rigor'):>5.1f}  {avg('real_insight'):>5.1f}  "
                f"{avg('structure'):>5.1f}  "
                f"{sum(totals)/len(totals):>6.1f}  "
                f"{sum(rpu)/len(rpu):>5.1%}"
            )


if __name__ == "__main__":
    asyncio.run(main())
