"""
V4 盲评配对 + Elo 排位 — Chatbot Arena 风格
同题内匿名配对比较，每对随机选轮次
"""

import httpx
import asyncio
import time
import json
import os
import random
from datetime import datetime
from collections import defaultdict

API_KEY = os.environ.get("ANTHROPIC_API_KEY", "sk-8d69425407474284afbf9278c948b6a7")
API_BASE = os.environ.get("ANTHROPIC_BASE_URL", "https://api.deepseek.com/anthropic")
API_URL = f"{{API_BASE}}/v1/messages"
MODEL = "deepseek-v4-pro[1m]"
MAX_TOKENS = 256
DELAY = 0.5

RESULTS_FILE = "D:/document/infinite/experiments/v3_routing_v2/results_v4_20260706_173652.json"
OUTPUT_FILE = "D:/document/infinite/experiments/v3_routing_v2/v4_elo_results.json"

API_URL = f"https://api.deepseek.com/anthropic/v1/messages"

with open(RESULTS_FILE, "r", encoding="utf-8") as f:
    results = json.load(f)

# Load question texts from run_v4.py
import sys
sys.path.insert(0, ".")
from run_v4 import QUESTIONS
QUESTION_MAP = {q["id"]: q["question"] for q in QUESTIONS}

# Group by question_id
by_question = defaultdict(list)
for r in results:
    if not r.get("error"):
        by_question[r["question_id"]].append(r)

COMPARE_PROMPT = """你是一位公正的评审。请比较以下两个对同一问题的回答，判断哪个更好。

【问题】
{question}

【回答 A】
{answer_a}

【回答 B】
{answer_b}

请只输出一个字母：A（如果回答A更好）、B（如果回答B更好）、或 T（如果两个回答质量相当，无法区分优劣）。

输出："""


async def compare_pair(client, question, answer_a, answer_b, label_a, label_b):
    # Randomize order
    if random.random() < 0.5:
        ans_a, ans_b = answer_a, answer_b
        lbl_a, lbl_b = label_a, label_b
    else:
        ans_a, ans_b = answer_b, answer_a
        lbl_a, lbl_b = label_b, label_a

    prompt = COMPARE_PROMPT.format(
        question=question,
        answer_a=ans_a[:4000],
        answer_b=ans_b[:4000],
    )
    messages = [{"role": "user", "content": prompt}]

    for attempt in range(3):
        try:
            full_text = ""
            async with client.stream(
                "POST",
                API_URL,
                headers={
                    "x-api-key": API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": MODEL,
                    "max_tokens": MAX_TOKENS,
                    "messages": messages,
                    "stream": True,
                },
                timeout=60.0,
            ) as response:
                if response.status_code != 200:
                    body = await response.aread()
                    raise Exception(f"HTTP {response.status_code}")
                async for line in response.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str.strip() == "[DONE]":
                        break
                    try:
                        event = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue
                    if event.get("type") in ("content_block_delta",):
                        full_text += event.get("delta", {}).get("text", "")

            choice = full_text.strip().upper()
            winner = None
            if choice.startswith("A"):
                winner = "A"
            elif choice.startswith("B"):
                winner = "B"
            elif choice.startswith("T"):
                winner = "T"
            else:
                # Try to find A, B, or T anywhere
                for c in ["A", "B", "T"]:
                    if c in choice[:5]:
                        winner = c
                        break

            # Map back to original labels considering randomization
            if winner == "A":
                result_winner = lbl_a
            elif winner == "B":
                result_winner = lbl_b
            else:
                result_winner = "TIE"

            return {
                "label_a": lbl_a, "label_b": lbl_b,
                "winner": result_winner,
                "raw_output": choice[:20],
                "error": None,
            }

        except Exception as e:
            if attempt < 2:
                await asyncio.sleep(1)
                continue
            return {
                "label_a": lbl_a, "label_b": lbl_b,
                "winner": None, "raw_output": "",
                "error": str(e)[:200],
            }


def compute_elo(comparisons, k=32):
    """Compute Elo ratings from pairwise comparison results"""
    players = set()
    for c in comparisons:
        if c["winner"]:
            players.add(c["label_a"])
            players.add(c["label_b"])

    elo = {p: 1500 for p in players}
    games = {p: 0 for p in players}

    for c in comparisons:
        a, b = c["label_a"], c["label_b"]
        winner = c["winner"]
        if winner == "TIE":
            continue
        if winner is None:
            continue

        if a not in elo or b not in elo:
            continue

        games[a] += 1
        games[b] += 1

        ea = 1 / (1 + 10 ** ((elo[b] - elo[a]) / 400))
        eb = 1 - ea

        if winner == a:
            sa, sb = 1, 0
        else:
            sa, sb = 0, 1

        elo[a] += k * (sa - ea)
        elo[b] += k * (sb - eb)

    return elo, games


async def main():
    # Build comparison pairs: for each question, 15 random cross-condition pairs
    COMPARISONS_PER_Q = 15

    all_pairs = []
    for qid, q_results in by_question.items():
        title = q_results[0]["question_title"]
        question_text = QUESTION_MAP.get(qid, title)

        # Group by condition
        by_cond = defaultdict(list)
        for r in q_results:
            by_cond[r["condition"]].append(r)

        conds = sorted(by_cond.keys())
        all_cond_pairs = [(c1, c2) for i, c1 in enumerate(conds) for c2 in conds[i + 1:]]

        # Randomly select pairs
        selected = random.sample(all_cond_pairs, min(COMPARISONS_PER_Q, len(all_cond_pairs)))

        for c1, c2 in selected:
            r1 = random.choice(by_cond[c1])
            r2 = random.choice(by_cond[c2])
            all_pairs.append({
                "question_id": qid,
                "question_title": title,
                "question": question_text,
                "answer_a": r1["text"],
                "answer_b": r2["text"],
                "label_a": f"{qid}_{c1}",
                "label_b": f"{qid}_{c2}",
                "cond_a": c1,
                "cond_b": c2,
            })

    random.shuffle(all_pairs)

    total = len(all_pairs)
    print(f"盲评配对 — Elo排位  配对: {total} ({COMPARISONS_PER_Q}对/题)")
    print(f"评测模型: {MODEL}  预计耗时: {total*6/60:.0f}分钟")
    print("=" * 60)

    comparisons = []
    start_time = time.time()

    async with httpx.AsyncClient() as client:
        for i, pair in enumerate(all_pairs):
            elapsed = time.time() - start_time
            eta = (total - i - 1) * (elapsed / (i + 1)) / 60 if i > 0 else 0

            result = await compare_pair(
                client,
                pair["question"],
                pair["answer_a"],
                pair["answer_b"],
                f"{pair['label_a']}_[{pair['cond_a']}]",
                f"{pair['label_b']}_[{pair['cond_b']}]",
            )
            result["question_id"] = pair["question_id"]
            result["cond_a"] = pair["cond_a"]
            result["cond_b"] = pair["cond_b"]
            comparisons.append(result)

            winner_str = result["winner"] or "ERR"
            print(f"[{i+1:>3}/{total}] {pair['label_a']:<12} vs {pair['label_b']:<12} → {winner_str:<5}  ETA:{eta:.0f}min")

            await asyncio.sleep(DELAY)

    # Compute Elo
    # First, aggregate by condition (not by question_condition combo)
    cond_comparisons = []
    for c in comparisons:
        if c["winner"] and c["winner"] != "TIE":
            cond_comparisons.append({
                "label_a": c["cond_a"],
                "label_b": c["cond_b"],
                "winner": c["cond_a"] if c["winner"].startswith(c["label_a"].split("_")[0]) else c["cond_b"],
            })

    elo, games = compute_elo(comparisons)
    # Aggregate Elo by condition
    cond_elo = defaultdict(list)
    for label, rating in elo.items():
        cond = label.split("[")[-1].rstrip("]") if "[" in label else label.split("_")[-1]
        cond_elo[cond].append(rating)

    print(f"\n{'='*60}")
    print(f"配对完成  成功: {sum(1 for c in comparisons if not c['error'])}/{total}")
    print(f"总耗时: {(time.time()-start_time)/60:.0f}min")

    print(f"\n--- Elo 排位（按条件汇总） ---")
    print(f"{'条件':<12} {'Elo':>8} {'σ':>8} {'胜率':>8} {'场次':>6}")
    print("-" * 50)
    cond_stats = []
    for cond in ["C1", "C2", "C3", "C4", "C5"]:
        ratings = cond_elo.get(cond, [])
        if ratings:
            avg_elo = sum(ratings) / len(ratings)
            std_elo = (sum((r - avg_elo) ** 2 for r in ratings) / len(ratings)) ** 0.5
            wins = sum(1 for c in comparisons if c["winner"] and c["cond_a"] == cond and c["winner"] == c["label_a"])
            wins += sum(1 for c in comparisons if c["winner"] and c["cond_b"] == cond and c["winner"] == c["label_b"])
            total_g = sum(1 for c in comparisons if c["cond_a"] == cond or c["cond_b"] == cond)
            wr = wins / total_g * 100 if total_g > 0 else 0
            cond_stats.append((cond, avg_elo, std_elo, wr, total_g))
            print(f"{cond:<12} {avg_elo:>8.1f} {std_elo:>8.1f} {wr:>7.1f}% {total_g:>6}")

    # Per-question win rates
    print(f"\n--- 按问题×条件 胜率 ---")
    for qid in sorted(by_question.keys()):
        title = by_question[qid][0]["question_title"]
        print(f"\n{qid} {title}")
        row = ""
        for cond in ["C1", "C2", "C3", "C4", "C5"]:
            wins = 0
            total_g = 0
            for c in comparisons:
                if c["question_id"] != qid:
                    continue
                if c["cond_a"] == cond and c["winner"] == c["label_a"]:
                    wins += 1
                if c["cond_b"] == cond and c["winner"] == c["label_b"]:
                    wins += 1
                if c["cond_a"] == cond or c["cond_b"] == cond:
                    total_g += 1
            wr = f"{wins/total_g*100:.0f}%({wins}/{total_g})" if total_g > 0 else "--"
            row += f"  {cond}: {wr}"
        print(row)

    # Save
    output = {
        "comparisons": comparisons,
        "elo": elo,
        "cond_elo": {c: sum(r)/len(r) for c, r in cond_elo.items() if r},
        "cond_stats": [(c, e, s, w, g) for c, e, s, w, g in cond_stats],
    }
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)
    print(f"\n结果: {OUTPUT_FILE}")


if __name__ == "__main__":
    asyncio.run(main())
