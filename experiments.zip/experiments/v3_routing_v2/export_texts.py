import json

results_file = "D:/document/infinite/experiments/v3_routing_v2/results_v4_20260706_173652.json"
output_file = "C:/Users/infinite/Desktop/V4_全部回答内容_20260706.md"

with open(results_file, "r", encoding="utf-8") as f:
    results = json.load(f)

COND_LABELS = {
    "C1": "正确框架", "C2": "裸问基线", "C3": "错误框架",
    "C4": "正确身份", "C5": "错误身份",
}

lines = []
lines.append("# V4 域路由实验 — 全部回答内容\n")
lines.append(f"**总调用：{len(results)} 次  成功率：{sum(1 for r in results if not r['error'])}/{len(results)}**\n")
lines.append("---\n")

for i, r in enumerate(results, 1):
    qid = r["question_id"]
    title = r["question_title"]
    cond = r["condition"]
    label = COND_LABELS.get(cond, cond)
    rnd = r["round"]
    err = r.get("error")
    text = r.get("text", "")
    text_len = r.get("text_length", 0)
    out_tok = r.get("output_tokens", "?")
    rpu_r = r.get("rpu_r_ratio")

    lines.append(f"## [{i}/{len(results)}] R{rnd} {qid} {title} — {label} ({cond})\n")
    lines.append(f"- **Output tokens:** {out_tok}  **Text length:** {text_len}")
    if rpu_r is not None:
        lines.append(f"  **R比例:** {rpu_r:.1%}")
    lines.append("")

    if err:
        lines.append(f"❌ **ERROR:** {err}\n")
    elif text:
        lines.append(text)
    else:
        lines.append("（空回答）\n")

    lines.append("\n---\n")

with open(output_file, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

# Also export a compact index
index_lines = []
index_lines.append("# V4 回答索引\n")
index_lines.append("| # | Round | Q | 条件 | Tokens | TextLen | R比例 |\n")
index_lines.append("|---|---|---|---|---|---|---|\n")
for i, r in enumerate(results, 1):
    qid = r["question_id"]
    cond = r["condition"]
    label = COND_LABELS.get(cond, cond)
    rnd = r["round"]
    out_tok = r.get("output_tokens", "?")
    text_len = r.get("text_length", 0)
    rpu_r = r.get("rpu_r_ratio")
    err = r.get("error")
    status = "❌" if err else ""
    r_str = f"{rpu_r:.1%}" if rpu_r is not None else "-"
    index_lines.append(f"| {i} | R{rnd} | {qid} | {label} {status} | {out_tok} | {text_len} | {r_str} |\n")

index_file = "C:/Users/infinite/Desktop/V4_回答索引_20260706.md"
with open(index_file, "w", encoding="utf-8") as f:
    f.write("\n".join(index_lines))

print(f"Done. Full: {output_file}  Index: {index_file}")
print(f"Total chars: {sum(len(r.get('text','')) for r in results)}")
