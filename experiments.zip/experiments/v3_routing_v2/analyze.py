"""
V3域分类实验 V2 — 升级版分析脚本
基于三方审视反馈的严格化分析

改进:
  P0修复: 多维指标替代单一R/P/U (增加实体密度、域相关性)
  P1修复: Prompt长度纳入分析 (length-aware R ratio)
  P2新增: C5/C6专项分析
  P3新增: 统计检验 (Cohen's d, bootstrap CI)
  P4新增: 截断率分析 (验证4096是否解决截断问题)
"""
import json
import re
import os
import math
import random
from collections import defaultdict
from datetime import datetime

# ============================================================
# 配置
# ============================================================
OUTPUT_DIR = "D:/document/infinite/experiments/v3_routing_v2"

# 自动找最新的results文件
def find_latest_results():
    files = [f for f in os.listdir(OUTPUT_DIR) if f.startswith("results_") and f.endswith(".json")]
    if not files:
        raise FileNotFoundError(f"No results_*.json found in {OUTPUT_DIR}")
    files.sort(reverse=True)
    return os.path.join(OUTPUT_DIR, files[0])

RESULTS_FILE = find_latest_results()

with open(RESULTS_FILE, "r", encoding="utf-8") as f:
    results = json.load(f)

COND_LABELS_V2 = {
    "C1": "正确路由", "C2": "无框架(等长)", "C3": "错误路由",
    "C4": "伪路由(等长)", "C5": "通用框架", "C6": "正确+通用",
}
COND_LABELS_V3 = {
    "C1": "正确域路由", "C2": "裸问基线", "C3": "错误域路由", "C4": "专家伪路由",
}
# 从数据自动检测条件
all_conds_in_data = sorted(set(r["condition"] for r in results))
if len(all_conds_in_data) == 4:
    COND_LABELS = COND_LABELS_V3
else:
    COND_LABELS = COND_LABELS_V2
ALL_CONDS = all_conds_in_data

# ============================================================
# 0. DATA QUALITY CHECK
# ============================================================
print("=" * 80)
print("📊 数据质量检查")
print("=" * 80)

valid = [r for r in results if not r["error"]]
errors = [r for r in results if r["error"]]
print(f"  总调用: {len(results)}  成功: {len(valid)}  失败: {len(errors)}")

# 截断率分析
MAX_TOKENS = 4096
capped = [r for r in valid if r.get("output_tokens") and r["output_tokens"] >= MAX_TOKENS - 10]
print(f"  输出截断: {len(capped)}/{len(valid)} = {len(capped)/len(valid)*100:.1f}%")
for cond in ALL_CONDS:
    cr = [r for r in valid if r["condition"] == cond]
    capped_c = len([r for r in cr if r.get("output_tokens") and r["output_tokens"] >= MAX_TOKENS - 10])
    print(f"    {cond} ({COND_LABELS[cond]}): {capped_c}/{len(cr)} = {capped_c/len(cr)*100:.1f}%")

# Prompt长度检查
print(f"\n  Prompt等长控制:")
for cond in ALL_CONDS:
    cr = [r for r in valid if r["condition"] == cond]
    sys_lens = [r.get("system_chars", 0) for r in cr]
    avg_len = sum(sys_lens) / len(sys_lens) if sys_lens else 0
    print(f"    {cond}: system prompt avg={avg_len:.0f} chars [min={min(sys_lens)}, max={max(sys_lens)}]")

# ============================================================
# 1. SPEED & TOKEN ANALYSIS
# ============================================================
print("\n" + "=" * 80)
print("📊 维度1+2: 响应速度 + Token消耗")
print("=" * 80)

def summarize(vals):
    """返回avg/min/max/std"""
    if not vals:
        return {"avg": 0, "min": 0, "max": 0, "std": 0, "n": 0}
    avg = sum(vals) / len(vals)
    variance = sum((v - avg) ** 2 for v in vals) / len(vals)
    return {"avg": avg, "min": min(vals), "max": max(vals),
            "std": math.sqrt(variance), "n": len(vals)}

print(f"\n{'条件':<16} {'TTFB':>9} {'σ':>6} {'总时间':>8} {'σ':>6} {'InTok':>6} {'OutTok':>7} {'σ':>6}")
print("-" * 78)
for cond in ALL_CONDS:
    cr = [r for r in valid if r["condition"] == cond]
    ttfb = summarize([r["ttfb_ms"] for r in cr if r["ttfb_ms"]])
    total = summarize([r["total_time_ms"] for r in cr])
    inp = summarize([r["input_tokens"] for r in cr if r["input_tokens"]])
    outp = summarize([r["output_tokens"] for r in cr if r["output_tokens"]])

    print(
        f"{cond:<6} {COND_LABELS[cond]:<8} "
        f"{ttfb['avg']:>7.0f}ms {ttfb['std']:>5.0f} "
        f"{total['avg']/1000:>7.1f}s {total['std']/1000:>5.1f} "
        f"{inp['avg']:>5.0f}  "
        f"{outp['avg']:>6.0f}  {outp['std']:>5.0f}"
    )

# ============================================================
# 2. ENHANCED R/P/U CODING
# ============================================================
print("\n" + "=" * 80)
print("📊 维度3-A: 物质还原比例 (R/P/U增强编码)")
print("=" * 80)

# 增强版R模式: 更全面的物质对应物检测
R_PATTERNS_ENHANCED = [
    # 数值类
    r'\d+[%％]',
    r'\d+[\.\,]\d+[%％]?',
    r'\d+[万亿千百]?(?:元|美元|人民币|万元|亿元|万亿)',
    r'\d+[万千百]?(?:米|公里|千米|平方米|平米|㎡|亩|公顷|吨|千克|克)',
    r'\d+[万千百]?(?:人|人次|户|家|个|例|起|件|宗)',
    r'(?:20\d{2}|19\d{2})年',
    r'(?:第[一二三四五六七八九十\d]+条|第[一二三四五六七八九十\d]+款|第[一二三四五六七八九十\d]+项)',
    r'\d+[\.\-]\d+',
    r'(?:GB|GB/T|ISO|HJ)\s*\d+',
    # 比率分数
    r'\d+\s*/\s*\d+',
    r'\d+\s*[:：]\s*\d+',
    # 技术指标
    r'(?:AUC|PPV|NPV|ROI|NPV|IRR|NPV|CAGR|YoY|QoQ|MoM)',
    r'(?:灵敏度|特异度|准确率|召回率|精确率|F1)\s*[：:]\s*\d+',
    r'\d+\s*(?:dB|Hz|kg|mm|cm|km|m/s|km/h|kWh|MW|GW|tCO2)',
    # 具体机构/地名+数字
    r'(?:覆盖|涉及|包含|涉及|服务)\s*\d+[万余]?(?:个|家|省|市|县|区)',
    r'(?:单价|均价|成本|价格|费用|投资|预算|收入|利润)\s*[：:：]?\s*\d+',
    # 法律条文
    r'《[^》]+》\s*第\s*\d+\s*条',
]

U_PATTERNS_ENHANCED = [
    r'(?:坚持|贯彻|落实|推进|深化|强化).{0,15}(?:思想|理念|方针|路线|战略|精神|要求)',
    r'(?:具有|有着|具备|富有).{0,15}(?:重大|重要|深远|关键|核心|根本).{0,10}(?:意义|价值|作用|地位|影响)',
    r'(?:需要|应当|必须|要|应该).{0,15}(?:重视|加强|强化|提升|改善|完善|优化|促进)',
    r'综合.{0,10}(?:治理|施策|推进|协调|管理)',
    r'(?:系统|全面|深入|大力|着力).{0,8}(?:推进|展开|实施|开展|进行)',
    r'(?:新形势|新时代|新发展|高质量|新格局|新征程).{0,8}(?:要求|需要|呼唤)',
    r'(?:以.{0,10}为).{0,8}(?:指导|引领|核心|中心|主线|抓手|导向|牵引)',
]

# 命名实体模式: 检测不含数字但具物质性的实体引用
ENTITY_PATTERNS = [
    r'(?:国家标准|行业标准|地方标准|团体标准|国际标准)',
    r'(?:最高人民法院|最高人民检察院|国务院|发改委|财政部|住建部|生态环境部|工信部)',
    r'(?:三甲医院|二甲医院|社区卫生服务中心|乡镇卫生院)',
    r'(?:一线城市|新一线|二线城市|三四线城市|县域|乡镇|农村)',
    r'(?:上市公司|国有企业|民营企业|外资企业|小微企业|个体工商户)',
    r'(?:临床试验|队列研究|随机对照|Meta分析|系统综述)',
    r'(?:医保局|卫健委|药监局|市场监管总局|证监会)',
    r'(?:《[^》]+》|"[^"]+"|\'[^\']+\')',  # 书名号和引号
]

def code_enhanced(text):
    """增强版R/P/U编码 + 实体密度"""
    sentences = re.split(r'[。；;\.!\?\n]+', text)
    sentences = [s.strip() for s in sentences if len(s.strip()) >= 5]

    counts = {"R": 0, "P": 0, "U": 0}
    entity_count = 0

    for sent in sentences:
        r_hits = sum(1 for pat in R_PATTERNS_ENHANCED if re.search(pat, sent))
        u_hits = sum(1 for pat in U_PATTERNS_ENHANCED if re.search(pat, sent))
        e_hits = sum(1 for pat in ENTITY_PATTERNS if re.search(pat, sent))

        entity_count += e_hits

        if u_hits >= 2:
            counts["U"] += 1
        elif u_hits == 1 and r_hits == 0:
            counts["U"] += 1
        elif r_hits >= 2:
            counts["R"] += 1
        elif r_hits == 1:
            counts["R"] += 1
        elif u_hits == 1:
            counts["P"] += 1
        else:
            # 具体性检查: 有命名实体但没有数字 → 半R
            if e_hits >= 2:
                counts["R"] += 1
            elif e_hits == 1:
                counts["P"] += 1
            else:
                counts["P"] += 1

    return counts, entity_count


# 编码
for r in results:
    if r.get("text"):
        counts, entity_count = code_enhanced(r["text"])
        r["rpu"] = counts
        total = counts["R"] + counts["P"] + counts["U"]
        r["rpu_r_ratio"] = counts["R"] / total if total > 0 else 0
        r["rpu_weighted"] = (counts["R"] * 1 + counts["P"] * 0.5) / total if total > 0 else 0
        r["rpu_total"] = total
        r["entity_density"] = entity_count / max(len(r["text"]), 1) * 1000  # 每千字

# 汇总
rpu_summary = {}
for cond in ALL_CONDS:
    cr = [r for r in valid if r["condition"] == cond and "rpu" in r]
    if not cr:
        continue

    total_R = sum(r["rpu"]["R"] for r in cr)
    total_P = sum(r["rpu"]["P"] for r in cr)
    total_U = sum(r["rpu"]["U"] for r in cr)
    total_all = total_R + total_P + total_U

    r_ratios = [r["rpu_r_ratio"] for r in cr]
    w_ratios = [r["rpu_weighted"] for r in cr]
    e_densities = [r.get("entity_density", 0) for r in cr]

    rpu_summary[cond] = {
        "R": total_R, "P": total_P, "U": total_U, "total": total_all,
        "r_ratio": total_R / total_all,
        "w_ratio": (total_R * 1 + total_P * 0.5) / total_all,
        "r_ratio_avg": sum(r_ratios) / len(r_ratios),
        "r_ratio_std": math.sqrt(sum((x - sum(r_ratios)/len(r_ratios))**2 for x in r_ratios)/len(r_ratios)),
        "entity_density_avg": sum(e_densities) / len(e_densities) if e_densities else 0,
    }

print(f"\n{'条件':<16} {'R':>6} {'P':>6} {'U':>6} {'总计':>6} {'R比例':>8} {'加权':>8} {'σ(R)':>6} {'实体/千字':>9}")
print("-" * 85)
for cond in ALL_CONDS:
    if cond in rpu_summary:
        s = rpu_summary[cond]
        print(f"{cond:<6} {COND_LABELS[cond]:<8} {s['R']:>6} {s['P']:>6} {s['U']:>6} {s['total']:>6} "
              f"{s['r_ratio']:>7.1%} {s['w_ratio']:>8.1%} {s['r_ratio_std']:>6.3f} "
              f"{s['entity_density_avg']:>8.1f}")

# ============================================================
# 3. KEY COMPARISONS WITH EFFECT SIZES
# ============================================================
print("\n" + "=" * 80)
print("📊 关键对比 (Cohen's d + Bootstrap 95% CI)")
print("=" * 80)

def cohens_d(group1, group2):
    """Cohen's d for independent groups"""
    n1, n2 = len(group1), len(group2)
    if n1 < 2 or n2 < 2:
        return 0
    m1 = sum(group1) / n1
    m2 = sum(group2) / n2
    v1 = sum((x - m1)**2 for x in group1) / n1
    v2 = sum((x - m2)**2 for x in group2) / n2
    pooled_sd = math.sqrt(((n1-1)*v1 + (n2-1)*v2) / (n1+n2-2))
    return (m1 - m2) / pooled_sd if pooled_sd > 0 else 0

def bootstrap_ci(group1, group2, n_bootstrap=10000):
    """Bootstrap 95% CI for mean difference"""
    diffs = []
    for _ in range(n_bootstrap):
        s1 = [random.choice(group1) for _ in range(len(group1))]
        s2 = [random.choice(group2) for _ in range(len(group2))]
        diffs.append(sum(s1)/len(s1) - sum(s2)/len(s2))
    diffs.sort()
    lo = diffs[int(n_bootstrap * 0.025)]
    hi = diffs[int(n_bootstrap * 0.975)]
    return lo, hi

comparisons = [
    ("C1 vs C4 (域框架 vs 伪路由)", "C1", "C4"),
    ("C1 vs C2 (域框架 vs 无框架)", "C1", "C2"),
    ("C3 vs C1 (错误路由 vs 正确)", "C3", "C1"),
]
if "C5" in ALL_CONDS:
    comparisons += [
        ("C1 vs C5 (域框架 vs 通用框架)", "C1", "C5"),
        ("C1 vs C6 (域框架 vs 域+通用)", "C1", "C6"),
        ("C5 vs C4 (通用框架 vs 伪路由)", "C5", "C4"),
        ("C5 vs C2 (通用框架 vs 无框架)", "C5", "C2"),
    ]

print(f"\n{'对比':<38} {'ΔR':>8} {'d':>7} {'95% CI':>20} {'解读':>15}")
print("-" * 95)

for label, c1, c2 in comparisons:
    g1 = [r["rpu_r_ratio"] for r in valid if r["condition"] == c1 and "rpu_r_ratio" in r]
    g2 = [r["rpu_r_ratio"] for r in valid if r["condition"] == c2 and "rpu_r_ratio" in r]
    if not g1 or not g2:
        continue

    delta = (sum(g1)/len(g1)) - (sum(g2)/len(g2))
    d = cohens_d(g1, g2)
    ci_lo, ci_hi = bootstrap_ci(g1, g2)

    if abs(d) > 0.8:
        interp = "大效应 ✓"
    elif abs(d) > 0.5:
        interp = "中效应"
    elif abs(d) > 0.2:
        interp = "小效应"
    else:
        interp = "可忽略"

    print(f"  {label:<36} {delta:>+7.1%} {d:>+6.2f}  [{ci_lo:>+7.3f}, {ci_hi:>+7.3f}]  {interp:>12}")

# ============================================================
# 4. PER-QUESTION × PER-CONDITION MATRIX
# ============================================================
print("\n" + "=" * 80)
print("📊 按问题×条件分解 (R比例)")
print("=" * 80)

question_ids = sorted(set(r["question_id"] for r in valid))
print(f"\n{'问题':<24}", end="")
for cond in ALL_CONDS:
    print(f" {cond:<8}", end="")
print(" 最大分歧")

for qid in question_ids:
    qr = [r for r in valid if r["question_id"] == qid and "rpu_r_ratio" in r]
    if not qr:
        continue
    title = qr[0].get("question_title", qid)
    vals = {}
    for cond in ALL_CONDS:
        cr = [r["rpu_r_ratio"] for r in qr if r["condition"] == cond]
        vals[cond] = sum(cr)/len(cr) if cr else 0

    max_val = max(vals.values())
    min_val = min(vals.values())
    spread = max_val - min_val

    print(f"  {qid} {title:<20}", end="")
    for cond in ALL_CONDS:
        marker = " *" if vals[cond] == max_val else ""
        print(f" {vals[cond]:>6.1%}{marker}", end="")
    print(f"  {spread:>+6.1%}")

# ============================================================
# 5. C5/C6 专项分析
# ============================================================
print("\n" + "=" * 80)
print("📊 C5/C6 新增条件专项分析")
print("=" * 80)

# C5 vs C1: 通用结构 vs 域知识 — 谁更重要？
c5_r = [r["rpu_r_ratio"] for r in valid if r["condition"] == "C5" and "rpu_r_ratio" in r]
c1_r = [r["rpu_r_ratio"] for r in valid if r["condition"] == "C1" and "rpu_r_ratio" in r]
c6_r = [r["rpu_r_ratio"] for r in valid if r["condition"] == "C6" and "rpu_r_ratio" in r]

if c5_r and c1_r:
    d_c1c5 = cohens_d(c1_r, c5_r)
    print(f"\n  C5(通用框架) vs C1(正确域):")
    print(f"    C1 R={sum(c1_r)/len(c1_r):.1%}  C5 R={sum(c5_r)/len(c5_r):.1%}  "
          f"Δ={sum(c1_r)/len(c1_r)-sum(c5_r)/len(c5_r):+.1%}  d={d_c1c5:+.2f}")
    if d_c1c5 > 0.5:
        print(f"    → 域知识激活 > 通用结构化，域框架提供额外价值")
    elif d_c1c5 < -0.5:
        print(f"    → 通用结构化 > 域知识激活，结构比领域更重要")
    else:
        print(f"    → 域知识和通用结构效果相近，效应不显著")

if c6_r and c1_r:
    d_c1c6 = cohens_d(c6_r, c1_r)
    print(f"\n  C6(正确+通用) vs C1(仅正确域):")
    print(f"    C6 R={sum(c6_r)/len(c6_r):.1%}  C1 R={sum(c1_r)/len(c1_r):.1%}  "
          f"Δ={sum(c6_r)/len(c6_r)-sum(c1_r)/len(c1_r):+.1%}  d={d_c1c6:+.2f}")
    if d_c1c6 > 0.3:
        print(f"    → 叠加通用框架有增益 (但C6 prompt更长，需谨慎归因)")
    elif d_c1c6 < -0.3:
        print(f"    → 叠加通用框架反而降低质量 (结构化指令过于冗长可能分散注意力)")
    else:
        print(f"    → 叠加通用框架无显著影响 (域框架已足够，通用框架是冗余信息)")

# ============================================================
# 6. LENGTH-AWARE ANALYSIS
# ============================================================
print("\n" + "=" * 80)
print("📊 Prompt长度×R比例 相关性分析")
print("=" * 80)

sys_lens_all = [r.get("system_chars", 0) for r in valid if "rpu_r_ratio" in r]
r_ratios_all = [r["rpu_r_ratio"] for r in valid if "rpu_r_ratio" in r]

if sys_lens_all and r_ratios_all:
    n = len(sys_lens_all)
    mx = sum(sys_lens_all) / n
    my = sum(r_ratios_all) / n
    cov = sum((sys_lens_all[i] - mx) * (r_ratios_all[i] - my) for i in range(n)) / n
    sx = math.sqrt(sum((x - mx)**2 for x in sys_lens_all) / n)
    sy = math.sqrt(sum((y - my)**2 for y in r_ratios_all) / n)
    corr = cov / (sx * sy) if sx > 0 and sy > 0 else 0

    print(f"  Pearson r(prompt长度, R比例) = {corr:+.3f}")
    if abs(corr) > 0.3:
        print(f"  ⚠️  Prompt长度与R比例存在中等以上相关，等长控制是必要的")
    else:
        print(f"  ✓ Prompt长度与R比例相关较弱，等长控制有效")

# 条件内长度方差
print(f"\n  条件内prompt长度变异系数:")
for cond in ALL_CONDS:
    cr = [r.get("system_chars", 0) for r in valid if r["condition"] == cond]
    if cr:
        avg = sum(cr) / len(cr)
        std = math.sqrt(sum((x-avg)**2 for x in cr) / len(cr))
        cv = std / avg * 100 if avg > 0 else 0
        print(f"    {cond}: avg={avg:.0f} chars, CV={cv:.1f}%")

# C6长度偏差提示
c6_lens = [r.get("system_chars", 0) for r in valid if r["condition"] == "C6"]
c1_lens = [r.get("system_chars", 0) for r in valid if r["condition"] == "C1"]
if c6_lens and c1_lens:
    print(f"\n  ⚠️  C6 prompt长度偏差: C6={sum(c6_lens)/len(c6_lens):.0f} vs C1={sum(c1_lens)/len(c1_lens):.0f} chars")
    print(f"    C6比C1长{sum(c6_lens)/len(c6_lens)/sum(c1_lens)*len(c1_lens)-100:.0f}%，C6相关比较需标注此混淆因素")

# ============================================================
# 7. SAVE
# ============================================================
# 保存增强结果
save_results = []
for r in results:
    sr = {k: v for k, v in r.items() if k != "text"}
    save_results.append(sr)

enriched_file = os.path.join(OUTPUT_DIR, "results_enriched.json")
with open(enriched_file, "w", encoding="utf-8") as f:
    json.dump(save_results, f, ensure_ascii=False, indent=2)

# 保存摘要
summary_data = {
    "timestamp": datetime.now().isoformat(),
    "total_calls": len(results),
    "valid": len(valid),
    "errors": len(errors),
    "cap_rate": len(capped) / len(valid) * 100 if valid else 0,
    "rpu_summary": rpu_summary,
    "comparisons": {},
}
for label, c1, c2 in comparisons:
    g1 = [r["rpu_r_ratio"] for r in valid if r["condition"] == c1 and "rpu_r_ratio" in r]
    g2 = [r["rpu_r_ratio"] for r in valid if r["condition"] == c2 and "rpu_r_ratio" in r]
    if g1 and g2:
        summary_data["comparisons"][label] = {
            "delta_r": (sum(g1)/len(g1)) - (sum(g2)/len(g2)),
            "cohens_d": cohens_d(g1, g2),
            "c1_n": len(g1), "c2_n": len(g2),
        }

summary_file = os.path.join(OUTPUT_DIR, "analysis_summary.json")
with open(summary_file, "w", encoding="utf-8") as f:
    json.dump(summary_data, f, ensure_ascii=False, indent=2)

print(f"\n📁 增强结果: {enriched_file}")
print(f"📁 分析摘要: {summary_file}")
print(f"\n✅ 分析完成 — 结果文件: {RESULTS_FILE}")

# ============================================================
# 8. EXPERIMENT REPORT (markdown)
# ============================================================
report = []
report.append("# V3域分类实验 — 分析报告\n")
report.append(f"> 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
report.append(f"> 模型: DeepSeek V4 Pro\n")
n_conds = len(ALL_CONDS)
cond_label_str = f"{n_conds}条件({'/'.join(COND_LABELS.get(c, c) for c in ALL_CONDS)})"
n_questions = len(set(r["question_id"] for r in results))
report.append(f"> 设计: {n_questions}题 × {cond_label_str} × 5轮 = {len(results)}次\n")
report.append(f"> 数据文件: {RESULTS_FILE}\n")

report.append("\n## 1. 数据质量\n")
report.append(f"- 成功率: {len(valid)}/{len(results)} ({len(valid)/len(results)*100:.1f}%)\n")
report.append(f"- 输出截断率: {len(capped)}/{len(valid)} ({len(capped)/len(valid)*100:.1f}%)\n")

report.append("\n## 2. R/P/U汇总\n")
report.append("\n| 条件 | R | P | U | 总计 | R比例 | 加权 | σ(R) | 实体/千字 |\n")
report.append("|---|---|---|---|---|---|---|---|---|\n")
for cond in ALL_CONDS:
    if cond in rpu_summary:
        s = rpu_summary[cond]
        report.append(f"| {cond} {COND_LABELS[cond]} | {s['R']} | {s['P']} | {s['U']} | {s['total']} | "
                     f"{s['r_ratio']:.1%} | {s['w_ratio']:.1%} | {s['r_ratio_std']:.3f} | "
                     f"{s['entity_density_avg']:.1f} |\n")

report.append("\n## 3. 关键对比\n")
report.append("\n| 对比 | ΔR | Cohen's d | 解读 |\n")
report.append("|---|---|---|---|\n")
for label, c1, c2 in comparisons:
    g1 = [r["rpu_r_ratio"] for r in valid if r["condition"] == c1 and "rpu_r_ratio" in r]
    g2 = [r["rpu_r_ratio"] for r in valid if r["condition"] == c2 and "rpu_r_ratio" in r]
    if not g1 or not g2:
        continue
    delta = (sum(g1)/len(g1)) - (sum(g2)/len(g2))
    d = cohens_d(g1, g2)
    if abs(d) > 0.8:
        interp = "大效应"
    elif abs(d) > 0.5:
        interp = "中效应"
    elif abs(d) > 0.2:
        interp = "小效应"
    else:
        interp = "可忽略"
    report.append(f"| {label} | {delta:+.1%} | {d:+.2f} | {interp} |\n")

report_file = os.path.join(OUTPUT_DIR, f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.md")
with open(report_file, "w", encoding="utf-8") as f:
    f.writelines(report)

print(f"📁 实验报告: {report_file}")
