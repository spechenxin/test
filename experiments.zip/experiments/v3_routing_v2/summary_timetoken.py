import json

for ver, fname in [
    ("V3", "results_v3_20260706_122650.json"),
    ("V4", "results_v4_20260706_173652.json"),
]:
    with open(fname, "r", encoding="utf-8") as f:
        results = json.load(f)

    LABELS = {
        "C1": "正确框架", "C2": "裸问基线", "C3": "错误框架",
        "C4": "正确身份", "C5": "错误身份",
    }
    V3_LABELS = {
        "C1": "正确域路由", "C2": "裸问基线", "C3": "错误域路由", "C4": "专家伪路由",
    }
    if ver == "V3":
        LABELS = V3_LABELS

    qids = sorted(set(r["question_id"] for r in results))
    conds = sorted(set(r["condition"] for r in results))

    sep = "=" * 105
    print(f"\n{sep}")
    print(f"  {ver} — 每问题×条件用时(秒)和输出Token（5轮平均）")
    print(sep)

    # Header
    parts = ["问题" + " " * 18]
    for c in conds:
        lbl = LABELS.get(c, c)
        parts.append(f"{c}({lbl})")
    parts.append("平均")
    header = f"{'':<22} " + " ".join(f"{p:>16}" for p in parts[1:])
    print(header)
    print("-" * 135)

    for qid in qids:
        qname = next(r["question_title"] for r in results if r["question_id"] == qid)
        tag = f"{qid} {qname}"
        all_times = []
        all_toks = []
        cells = []
        for c in conds:
            cr = [r for r in results if r["question_id"] == qid and r["condition"] == c and not r.get("error")]
            if cr:
                avg_t = sum(r["total_time_ms"] / 1000 for r in cr) / len(cr)
                avg_o = sum(r["output_tokens"] for r in cr) / len(cr)
                all_times.append(avg_t)
                all_toks.append(avg_o)
                cells.append(f"{avg_t:>5.1f}s {avg_o:>5.0f}tk")
            else:
                cells.append(f"{'--':>12}")
        avg_all_t = sum(all_times) / len(all_times) if all_times else 0
        avg_all_o = sum(all_toks) / len(all_toks) if all_toks else 0
        print(f"{tag:<22} " + " ".join(f"{c:>14}" for c in cells) + f"  {avg_all_t:>5.1f}s {avg_all_o:>5.0f}tk")

    # Condition averages
    print("-" * 135)
    cells = []
    all_cond_t = []
    all_cond_o = []
    for c in conds:
        cr = [r for r in results if r["condition"] == c and not r.get("error")]
        avg_t = sum(r["total_time_ms"] / 1000 for r in cr) / len(cr)
        avg_o = sum(r["output_tokens"] for r in cr) / len(cr)
        all_cond_t.append(avg_t)
        all_cond_o.append(avg_o)
        cells.append(f"{avg_t:>5.1f}s {avg_o:>5.0f}tk")
    avg_all_ct = sum(all_cond_t) / len(all_cond_t)
    avg_all_co = sum(all_cond_o) / len(all_cond_o)
    print(f"{'条件平均':<22} " + " ".join(f"{c:>14}" for c in cells) + f"  {avg_all_ct:>5.1f}s {avg_all_co:>5.0f}tk")

    # Per-question variance
    print(f"\n--- 问题内条件间差异 ---")
    print(f"{'问题':<22} {'最快':>11} {'最慢':>11} {'比':>5}  {'最少Tok':>11} {'最多Tok':>11} {'比':>5}")
    print("-" * 80)
    for qid in qids:
        qname = next(r["question_title"] for r in results if r["question_id"] == qid)
        cr_times = {}
        cr_toks = {}
        for c in conds:
            cr = [r for r in results if r["question_id"] == qid and r["condition"] == c and not r.get("error")]
            if cr:
                cr_times[c] = sum(r["total_time_ms"] / 1000 for r in cr) / len(cr)
                cr_toks[c] = sum(r["output_tokens"] for r in cr) / len(cr)
        min_t = min(cr_times.values())
        max_t = max(cr_times.values())
        min_o = min(cr_toks.values())
        max_o = max(cr_toks.values())
        min_tc = min(cr_times, key=cr_times.get)
        max_tc = max(cr_times, key=cr_times.get)
        min_oc = min(cr_toks, key=cr_toks.get)
        max_oc = max(cr_toks, key=cr_toks.get)
        print(
            f"{qid} {qname:<18}"
            f" {min_t:>5.1f}s({min_tc}) {max_t:>5.1f}s({max_tc}) {max_t/min_t:>4.1f}x"
            f"  {min_o:>5.0f}({min_oc}) {max_o:>6.0f}({max_oc}) {max_o/min_o:>4.1f}x"
        )

    # Cross-version note
    print(f"\n--- {ver} 总体 ---")
    valid = [r for r in results if not r.get("error")]
    total_t = sum(r["total_time_ms"] / 1000 for r in valid)
    total_o = sum(r.get("output_tokens", 0) for r in valid)
    print(f"  总用时: {total_t/60:.0f}min  Token: {total_o}  平均/次: {total_t/len(valid):.1f}s  {total_o/len(valid):.0f}tk")
