"""
V3域分类实验 V3 — 四条件纯净设计
基于V2复盘：去掉推理要求，C2改为裸问基线，C4改为纯角色卡

设计: 8题 × 4条件(C1-C4) × 5轮 = 160次API调用
模型: DeepSeek V4 Pro (Anthropic兼容API)

条件:
  C1: 正确域路由 — 仅正确学科框架，无推理要求
  C2: 裸问基线 — system=None
  C3: 错误域路由 — 仅错误学科框架，无推理要求
  C4: 专家伪路由 — 仅角色卡("你是跨领域分析专家")，无学科框架/推理要求
"""

import httpx
import asyncio
import time
import json
import os
from datetime import datetime

API_KEY = os.environ.get("ANTHROPIC_API_KEY", "sk-8d69425407474284afbf9278c948b6a7")
API_BASE = os.environ.get("ANTHROPIC_BASE_URL", "https://api.deepseek.com/anthropic")
API_URL = f"{API_BASE}/v1/messages"
MODEL = os.environ.get("ANTHROPIC_MODEL", "deepseek-v4-pro[1m]")
OUTPUT_DIR = "D:/document/infinite/experiments/v3_routing_v2"
MAX_TOKENS = 4096
DELAY = 2.0

# ============================================================
# 8道跨域问题 (同V2)
# ============================================================

QUESTIONS = [
    {
        "id": "Q1",
        "title": "15分钟生活圈",
        "question": (
            "某一线城市推出'15分钟生活圈'规划，要求所有居民步行15分钟内可达"
            "基本公共服务（医疗、教育、商业）。请分析该政策的可行性，"
            "评估主要障碍和关键成功条件。"
        ),
        "correct_domains": (
            "城乡规划学(0833): 空间布局约束、用地性质、设施分布标准、路网密度\n"
            "社会学(0303): 社区动力学、利益相关方行为模式、服务均等化的社会维度\n"
            "区域经济学(0202): 公共资源空间配置效率、成本收益结构、规模经济门槛\n"
            "公共管理学(1204): 政策可行性评估、治理结构、实施机制"
        ),
        "wrong_domains": (
            "计算机算法(0812): 图论最短路径、NP-hard支配集问题、贪心/遗传算法选址优化、时间复杂度分析\n"
            "计算数学(0701): 运筹学k-center问题、设施选址数学模型、约束优化"
        ),
    },
    {
        "id": "Q2",
        "title": "AI医疗诊断",
        "question": (
            "评估AI辅助医疗影像诊断在中国三甲医院大规模推广的可行性。"
            "请分析技术成熟度、制度障碍、经济可行性和社会接受度四个维度。"
        ),
        "correct_domains": (
            "临床医学(1002): 诊断准确率(灵敏度/特异度/PPV)、不同场景下的临床效用、假阴性/假阳性后果\n"
            "智能科学与技术(1405): AI模型泛化能力、跨设备鲁棒性、训练数据分布偏差\n"
            "公共管理学(1204): 医疗器械审批监管(三类证)、收费编码与医保支付、法律责任归属\n"
            "卫生经济学(0202): 医院采购ROI、DRG/DIP支付改革下的成本效益、替代/补充效应"
        ),
        "wrong_domains": (
            "市场营销(1202): B2B技术产品渗透策略、品牌定位、KOL学术营销、采购决策单元分析、创新扩散S曲线\n"
            "新闻传播学(0503): 舆论引导、公众科学传播、意见领袖背书"
        ),
    },
    {
        "id": "Q3",
        "title": "直播带货县域农产品",
        "question": (
            "分析直播带货对中西部县域农产品供应链的结构性影响。"
            "请评估其对生产者收入、中间商角色、冷链物流和区域品牌形成的长期效应。"
        ),
        "correct_domains": (
            "农业经济学(0202): 农产品定价权、流通环节利润分配、生产者剩余变化\n"
            "供应链管理(1201): 冷链物流瓶颈、产地仓处理能力、瞬时流量冲击下的履约\n"
            "市场营销(1202): 渠道结构变迁、品牌依附性、流量议价权\n"
            "农村社会学(0303): 县域劳动力结构变化、'新农人'群体、合作社组织能力"
        ),
        "wrong_domains": (
            "计算机视觉(0812): 农产品图像品质检测、色域失真对购买意愿的影响、AR虚拟试吃\n"
            "信息与通信工程(0810): 视频编码压缩、直播延迟优化、带宽适配"
        ),
    },
    {
        "id": "Q4",
        "title": "老旧小区加装电梯",
        "question": (
            "城市老旧小区加装电梯面临业主意见不统一、资金筹措困难、施工技术复杂等多重障碍。"
            "请分析这些障碍的深层原因，并提出系统性的破解路径。"
        ),
        "correct_domains": (
            "物权法学(0301): 建筑物共有部分处分规则、《民法典》第278条表决门槛、少数业主救济权\n"
            "公共管理学(1204): 行政审批协调、基层治理能力、'一站式'服务窗口机制\n"
            "城市经济学(0202): 加装电梯的成本分摊与房价重分布、低层业主补偿定价、长期维护融资\n"
            "社会学(0303): 社区协商机制、老年居民支付能力、出租户vs自住户的利益分化"
        ),
        "wrong_domains": (
            "机械工程(0802): 曳引/液压电梯参数选型、井道钢结构设计、振动频率传导、新旧基础沉降差异\n"
            "工程力学(0801): 风荷载计算(GB50009)、抗震设防、连接节点应力分析"
        ),
    },
    {
        "id": "Q5",
        "title": "预制菜进校园",
        "question": (
            "多地推动预制菜进入中小学校园食堂，引发家长和社会广泛争议。"
            "请从食品安全、营养健康、供应链管理和政策监管四个维度，"
            "分析预制菜进校园的可行性条件和风险控制措施。"
        ),
        "correct_domains": (
            "食品科学与工程(0832): 中央厨房HACCP体系、冷链断链风险、营养素衰减动力学、添加剂残留标准\n"
            "公共卫生与预防医学(1004): 学龄儿童营养需求(DRIs)、食源性疾病爆发模型、长期健康影响监测\n"
            "公共管理学(1204): 校园食品安全监管体系、'明厨亮灶'与预制菜监管的适配性、教育局招标机制\n"
            "供应链管理(1201): 从中央厨房到教室的冷链全链条、批量配送与个性化需求的矛盾、应急预案"
        ),
        "wrong_domains": (
            "机械工程(0802): 中央厨房设备选型、自动化生产线节拍优化、设备清洗CIP系统设计\n"
            "工程力学(0801): 食品包装材料力学性能、运输振动对包装完整性的影响"
        ),
    },
    {
        "id": "Q6",
        "title": "碳交易市场机制",
        "question": (
            "中国全国碳排放权交易市场已从电力行业起步。"
            "请评估该市场扩展到钢铁、水泥、化工等高排放行业的可行性和关键障碍，"
            "分析配额分配机制、碳价形成效率和市场监管三个核心问题。"
        ),
        "correct_domains": (
            "环境经济学(0202): 边际减排成本曲线(MACC)、碳价发现效率、碳泄漏风险与CBAM应对\n"
            "公共管理学(1204): MRV体系(监测报告核查)、配额分配的政治经济学、央地监管博弈\n"
            "能源科学与工程(0805): 行业基准线设定、间接排放核算、CCUS技术成熟度与成本曲线\n"
            "法学(0301): 《碳排放权交易管理办法》法律位阶、碳配额的法律属性(行政许可vs财产权)"
        ),
        "wrong_domains": (
            "计算机算法(0812): 碳排放数据区块链存证、智能合约自动清缴、大数据异常排放检测\n"
            "计算数学(0701): 碳价随机微分方程建模、配额拍卖机制设计(VCG)、预测模型优化"
        ),
    },
    {
        "id": "Q7",
        "title": "自动驾驶事故责任",
        "question": (
            "L4级自动驾驶车辆在公开道路上发生交通事故后，"
            "现行法律框架难以明确划分制造商、软件开发商和「驾驶员」的责任。"
            "请从技术、法律和保险三个维度，提出系统的责任认定框架。"
        ),
        "correct_domains": (
            "交通运输工程(0823): 自动驾驶ODD(运行设计域)边界、传感器融合失效模式、事故数据记录(EDR)标准\n"
            "法学(0301): 《道路交通安全法》修订方向、产品责任vs交通事故责任的竞合、'理性算法'标准\n"
            "智能科学与技术(1405): 感知-决策-控制链的可解释性、训练数据与边缘场景的覆盖差距\n"
            "保险学(0202): UBI保险精算模型、从个人责任险向产品责任险的范式转移、赔偿基金机制"
        ),
        "wrong_domains": (
            "市场营销(1202): 消费者对自动驾驶的购买意愿调查、品牌信任危机公关策略、舆情管理\n"
            "新闻传播学(0503): 自动驾驶事故的媒体报道框架分析、公众风险感知与信息传播机制"
        ),
    },
    {
        "id": "Q8",
        "title": "农村宅基地流转",
        "question": (
            "农村宅基地'三权分置'改革试点多年，但跨集体流转仍面临法律模糊、"
            "市场缺失和农民权益保障三重困境。请分析这些困境的制度根源，"
            "并提出兼顾效率与公平的改革路径。"
        ),
        "correct_domains": (
            "土地资源管理(1204): 宅基地确权登记与'一户多宅'清理、集体经营性建设用地入市的经验映射\n"
            "法学(0301): 《土地管理法》第62条与改革试点的授权冲突、资格权与使用权的法理分离\n"
            "农村社会学(0303): '空心村'家庭生命周期与宅基地退出意愿、代际公平与继承权争议\n"
            "农业经济学(0202): 宅基地资产化的财富效应、农民'带权进城'的城市化路径、金融杠杆风险"
        ),
        "wrong_domains": (
            "计算机算法(0812): 宅基地空间数据库的拓扑一致性、地理信息系统(GIS)的最优合并分区\n"
            "信息与通信工程(0810): 农村宅基地确权的遥感影像解译精度、无人机倾斜摄影测量"
        ),
    },
]

COND_LABELS = {
    "C1": "正确域路由",
    "C2": "裸问基线",
    "C3": "错误域路由",
    "C4": "专家伪路由",
}

# C4: 纯角色卡 — 不给学科框架，不给推理要求
C4_EXPERT_PROMPT = (
    "你是一位经验丰富的跨领域分析专家，拥有多学科的知识背景和深入的行业洞察。"
    "请以专家的严谨性和全面性来分析以下问题。"
)


def build_messages(question_obj, condition):
    """
    构建 messages。V3四条件纯净设计：

    C1: 正确域路由 — 仅正确学科框架（无推理要求）
    C2: 裸问基线 — system=None
    C3: 错误域路由 — 仅错误学科框架（无推理要求）
    C4: 专家伪路由 — 仅角色卡（无学科框架/推理要求）

    核心原则：C1/C3/C4 的区别仅在于"给什么框架内容"。
    所有条件均不包含"怎么思考"的方法论指令。
    """
    q = question_obj["question"]

    if condition == "C1":
        system = (
            "分析以下问题时，请运用以下学科分析框架进行推衍：\n\n"
            f"{question_obj['correct_domains']}"
        )
    elif condition == "C2":
        system = None
    elif condition == "C3":
        system = (
            "分析以下问题时，请运用以下学科分析框架进行推衍：\n\n"
            f"{question_obj['wrong_domains']}"
        )
    elif condition == "C4":
        system = C4_EXPERT_PROMPT
    else:
        raise ValueError(f"Unknown condition: {condition}")

    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": q})
    return messages


async def run_single(client, messages, label, max_retries=2):
    """单次API调用，测量TTFB/总时间/Token/完整文本"""
    for attempt in range(max_retries + 1):
        try:
            start_time = time.time()
            ttfb = None
            full_text = ""
            usage = {}
            input_tokens_est = None

            async with client.stream(
                "POST",
                API_URL,
                headers={
                    "x-api-key": API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": MODEL,
                    "max_tokens": MAX_TOKENS,
                    "messages": messages,
                    "stream": True,
                },
                timeout=180.0,
            ) as response:
                if response.status_code != 200:
                    body = await response.aread()
                    raise Exception(f"HTTP {response.status_code}: {body[:300]}")

                async for line in response.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str.strip() == "[DONE]":
                        break
                    try:
                        event = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue

                    etype = event.get("type", "")

                    if etype == "message_start":
                        msg = event.get("message", {})
                        u = msg.get("usage", {})
                        if u.get("input_tokens"):
                            input_tokens_est = u["input_tokens"]
                    elif etype == "content_block_delta":
                        delta_text = event.get("delta", {}).get("text", "")
                        if ttfb is None and delta_text:
                            ttfb = time.time() - start_time
                        full_text += delta_text
                    elif etype == "message_delta":
                        u = event.get("usage", {})
                        if u:
                            usage.update(u)
                    elif etype == "message_stop":
                        if not usage:
                            usage = event.get("usage", {})
                            if not usage:
                                amz = event.get("amazon-bedrock", {}) or {}
                                usage = amz.get("usage", {})

            total_time = time.time() - start_time

            return {
                "label": label,
                "ttfb_ms": round(ttfb * 1000, 1) if ttfb else None,
                "total_time_ms": round(total_time * 1000, 1),
                "input_tokens": usage.get("input_tokens") or input_tokens_est,
                "output_tokens": usage.get("output_tokens"),
                "text": full_text,
                "text_length": len(full_text),
                "attempts": attempt + 1,
                "error": None,
            }

        except Exception as e:
            if attempt < max_retries:
                wait = 2 ** attempt
                await asyncio.sleep(wait)
                continue
            return {
                "label": label,
                "ttfb_ms": None,
                "total_time_ms": round((time.time() - start_time) * 1000, 1),
                "input_tokens": None,
                "output_tokens": None,
                "text": "",
                "text_length": 0,
                "attempts": attempt + 1,
                "error": str(e)[:300],
            }


async def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    ROUNDS = 5
    CONDS = ["C1", "C2", "C3", "C4"]
    total_calls = len(QUESTIONS) * len(CONDS) * ROUNDS

    print(f"╔══════════════════════════════════════════════════════╗")
    print(f"║  V3域分类实验 V3 — 四条件纯净设计                       ║")
    print(f"╠══════════════════════════════════════════════════════╣")
    print(f"║  模型: {MODEL:<43s} ║")
    print(f"║  设计: {len(QUESTIONS)}题 × {len(CONDS)}条件 × {ROUNDS}轮 = {total_calls}次{'':>17s} ║")
    print(f"║  max_tokens: {MAX_TOKENS}{'':>38s} ║")
    print(f"║  关键变更: 去掉推理要求 / C2裸问 / C4纯角色卡{'':>7s} ║")
    print(f"╚══════════════════════════════════════════════════════╝")

    all_results = []
    call_idx = 0
    start_time = time.time()

    async with httpx.AsyncClient() as client:
        for round_num in range(1, ROUNDS + 1):
            print(f"\n{'='*60}")
            print(f"  Round {round_num}/{ROUNDS}")
            print(f"{'='*60}")

            for question in QUESTIONS:
                for condition in CONDS:
                    messages = build_messages(question, condition)
                    call_idx += 1
                    label = f"R{round_num}_{question['id']}_{condition}"

                    sys_len = sum(len(m.get("content", "")) for m in messages if m["role"] == "system")
                    elapsed = time.time() - start_time
                    eta_min = (total_calls - call_idx) * (elapsed / call_idx) / 60 if call_idx > 1 else 0

                    print(
                        f"[{call_idx:>3}/{total_calls}] {label:<16} "
                        f"({COND_LABELS[condition]:<8}) "
                        f"sys={sys_len:>3}c ",
                        end="",
                        flush=True,
                    )

                    result = await run_single(client, messages, label)

                    result["round"] = round_num
                    result["question_id"] = question["id"]
                    result["question_title"] = question["title"]
                    result["condition"] = condition
                    result["condition_label"] = COND_LABELS[condition]
                    result["system_chars"] = sys_len

                    all_results.append(result)

                    if result["error"]:
                        print(f"❌ {result['error'][:80]}")
                    else:
                        hit_cap = "⚠️CAP" if result.get("output_tokens") and result["output_tokens"] >= MAX_TOKENS - 10 else ""
                        print(
                            f"✅ TTFB={result['ttfb_ms']}ms "
                            f"Total={result['total_time_ms']/1000:.1f}s "
                            f"in={result['input_tokens']} out={result['output_tokens']} "
                            f"len={result['text_length']} {hit_cap}"
                        )

                    await asyncio.sleep(DELAY)

    # ============================================================
    # 保存
    # ============================================================
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_file = os.path.join(OUTPUT_DIR, f"results_v3_{timestamp}.json")
    with open(results_file, "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    print(f"\n📁 完整结果: {results_file}")

    print_summary(all_results)
    return results_file


def print_summary(results):
    errors = [r for r in results if r["error"]]
    valid = [r for r in results if not r["error"]]

    print("\n" + "=" * 60)
    print(f"📊 实验摘要  成功: {len(valid)}  失败: {len(errors)}  "
          f"成功率: {len(valid)/len(results)*100:.1f}%")
    if errors:
        print(f"   错误: {', '.join(r['label'] for r in errors[:5])}")
    print("=" * 60)

    # Token截断率
    capped = [r for r in valid if r.get("output_tokens") and r["output_tokens"] >= MAX_TOKENS - 10]
    print(f"\n⚠️  输出截断: {len(capped)}/{len(valid)} ({len(capped)/len(valid)*100:.1f}%)")

    # 按条件汇总
    print(f"\n{'条件':<16} {'n':>4} {'TTFB':>8} {'Total':>8} {'InTok':>6} {'OutTok':>7} "
          f"{'TextLen':>8} {'Cap%':>6} {'sys_chars':>10}")
    print("-" * 85)
    for cond in ["C1", "C2", "C3", "C4"]:
        cr = [r for r in valid if r["condition"] == cond]
        if not cr:
            continue
        n = len(cr)
        ttfb = [r["ttfb_ms"] for r in cr if r["ttfb_ms"]]
        total = [r["total_time_ms"] for r in cr]
        in_t = [r["input_tokens"] for r in cr if r["input_tokens"]]
        out_t = [r["output_tokens"] for r in cr if r["output_tokens"]]
        tlen = [r["text_length"] for r in cr if r["text_length"]]
        cap_count = len([r for r in cr if r.get("output_tokens") and r["output_tokens"] >= MAX_TOKENS - 10])
        sys_chars = [r.get("system_chars", 0) for r in cr]

        def avg(lst):
            return sum(lst) / len(lst) if lst else 0

        print(
            f"{cond:<6} {COND_LABELS[cond]:<8} {n:>4}  "
            f"{avg(ttfb):>7.0f}ms "
            f"{avg(total)/1000:>7.1f}s "
            f"{avg(in_t):>5.0f}  "
            f"{avg(out_t):>6.0f}  "
            f"{avg(tlen):>7.0f}  "
            f"{cap_count/n*100:>5.0f}%  "
            f"{avg(sys_chars):>8.0f}"
        )

    # 按条件×问题
    print(f"\n--- 按条件×问题输出Token ---")
    for cond in ["C1", "C2", "C3", "C4"]:
        parts = []
        for qid in [q["id"] for q in QUESTIONS]:
            cr = [r for r in valid if r["condition"] == cond and r["question_id"] == qid]
            out_t = [r["output_tokens"] for r in cr if r["output_tokens"]]
            parts.append(f"{qid}:{avg(out_t):.0f}" if out_t else f"{qid}:--")
        print(f"  {cond:<6} {'  '.join(parts)}")


if __name__ == "__main__":
    asyncio.run(main())
