"""
V3域分类实验 — 分析脚本
读取API实验结果JSON，产出三维指标统计 + R/P/U自动编码
"""
import json
import re
import os
from collections import defaultdict

RESULTS_FILE = "D:/document/infinite/experiments/v3_routing_api/results_20260702_101025.json"
OUTPUT_DIR = "D:/document/infinite/experiments/v3_routing_api"

with open(RESULTS_FILE, "r", encoding="utf-8") as f:
    results = json.load(f)

COND_LABELS = {"C1": "正确路由", "C2": "无路由", "C3": "错误路由", "C4": "伪路由"}

# ============================================================
# 1. SPEED + TOKEN ANALYSIS
# ============================================================
print("=" * 80)
print("📊 维度1+2: 响应速度 + Token消耗 (n=160, API实测)")
print("=" * 80)

# Only use results with valid TTFB
def summarize(cond_results, metric_key):
    vals = [r[metric_key] for r in cond_results if r.get(metric_key) is not None]
    if not vals:
        return {"avg": 0, "min": 0, "max": 0, "n": 0}
    return {"avg": sum(vals) / len(vals), "min": min(vals), "max": max(vals), "n": len(vals)}

for cond in ["C1", "C2", "C3", "C4"]:
    cr = [r for r in results if r["condition"] == cond]
    n = len(cr)
    ttfb = summarize(cr, "ttfb_ms")
    total = summarize(cr, "total_time_ms")
    in_tok = summarize(cr, "input_tokens")
    out_tok = summarize(cr, "output_tokens")

    # TTFB capture rate
    ttfb_captured = len([r for r in cr if r.get("ttfb_ms") is not None])

    print(f"\n{cond} ({COND_LABELS[cond]}): n={n}")
    print(f"  TTFB:      avg={ttfb['avg']:.0f}ms  [{ttfb['min']:.0f}-{ttfb['max']:.0f}]  捕获率={ttfb_captured}/{n} ({ttfb_captured/n*100:.0f}%)")
    print(f"  总时间:    avg={total['avg']:.0f}ms  [{total['min']:.0f}-{total['max']:.0f}]")
    print(f"  输入Token: avg={in_tok['avg']:.0f}  [{in_tok['min']:.0f}-{in_tok['max']:.0f}]")
    print(f"  输出Token: avg={out_tok['avg']:.0f}  [{out_tok['min']:.0f}-{out_tok['max']:.0f}]")
    print(f"  总Token:   avg={in_tok['avg']+out_tok['avg']:.0f}")

# C1 vs C4 comparison
print("\n--- 关键对比 (Total Time, 仅有效TTFB) ---")
c1_valid = [r for r in results if r["condition"] == "C1" and r.get("ttfb_ms")]
c4_valid = [r for r in results if r["condition"] == "C4" and r.get("ttfb_ms")]
c2_valid = [r for r in results if r["condition"] == "C2" and r.get("ttfb_ms")]

for name, c1v, c4v in [("TTFB", c1_valid, c4_valid), ("总时间",
    [r for r in results if r["condition"]=="C1"],
    [r for r in results if r["condition"]=="C4"])]:
    if name == "总时间":
        c1_vals = [r["total_time_ms"] for r in c1v]
        c4_vals = [r["total_time_ms"] for r in c4v]
    else:
        c1_vals = [r["ttfb_ms"] for r in c1v]
        c4_vals = [r["ttfb_ms"] for r in c4v]

    c1_avg = sum(c1_vals)/len(c1_vals)
    c4_avg = sum(c4_vals)/len(c4_vals)
    delta = c1_avg - c4_avg
    delta_pct = (delta/c4_avg*100) if c4_avg else 0
    print(f"  {name}: C1={c1_avg:.0f}ms  C4={c4_avg:.0f}ms  Δ={delta:+.0f}ms ({delta_pct:+.1f}%)")

# ============================================================
# 2. R/P/U AUTOMATED CODING
# ============================================================
print("\n" + "=" * 80)
print("📊 维度3: 物质还原比例 (R/P/U自动编码)")
print("=" * 80)

# 编码规则: 基于中文文本特征
R_PATTERNS = [
    r'\d+[%％]',                          # 百分比
    r'\d+[万亿千百]?(?:元|美元|人民币|万元|亿元)',  # 金额
    r'\d+[万千百]?(?:米|公里|千米|平方米|平米|㎡|亩|公顷)', # 面积/距离
    r'\d+[万千百]?(?:人|人次|户|家|个|例)',  # 数量
    r'(?:20\d{2}|19\d{2})年',            # 年份
    r'(?:第[一二三四五六七八九十\d]+条|第[一二三四五六七八九十\d]+款)', # 法条
    r'\d+[\.-]\d+',                       # 小数/范围
    r'(?:AUC|PPV|ROI|NPV|dB|Hz|kg|mm|cm|km|m/s)',  # 技术指标
    r'GB\d+',                              # 国标
    r'\d+/\d+',                            # 分数比率
]

U_PATTERNS = [
    r'(?:坚持|贯彻|落实|推进).{0,10}(?:思想|理念|方针|路线|战略)',
    r'(?:具有|有着|具备).{0,10}(?:意义|价值|作用|地位)',
    r'(?:需要|应当|必须|要).{0,10}(?:重视|加强|强化|提升|改善)',
    r'综合.{0,8}(?:治理|施策|推进|协调)',
    r'(?:系统|全面|深入).{0,6}(?:推进|展开|实施)',
    r'(?:新形势|新时代|新发展|高质量).{0,6}(?:要求|需要)',
]

def code_rpu(text):
    """对文本逐句进行R/P/U编码，返回计数"""
    # 分句
    sentences = re.split(r'[。；;\.!\?\n]+', text)
    sentences = [s.strip() for s in sentences if len(s.strip()) >= 5]

    counts = {"R": 0, "P": 0, "U": 0}

    for sent in sentences:
        r_hits = sum(1 for pat in R_PATTERNS if re.search(pat, sent))
        u_hits = sum(1 for pat in U_PATTERNS if re.search(pat, sent))

        if u_hits >= 2:
            counts["U"] += 1
        elif u_hits == 1 and r_hits == 0:
            counts["U"] += 1
        elif r_hits >= 2:
            counts["R"] += 1
        elif r_hits == 1:
            counts["R"] += 1
        elif u_hits == 1:
            # Has U pattern but also context - borderline
            counts["P"] += 1
        else:
            # Default: if sentence has concrete nouns, lean R; otherwise P
            concrete = re.search(r'(?:医院|学校|商场|超市|地铁|公交|道路|电梯|楼房|小区|医生|患者|居民|业主|农民|商户|消费者|政府|部门|法院|法律|法规|条例|政策|市场|价格|成本|收入|利润)', sent)
            if concrete:
                counts["R"] += 1
            else:
                counts["P"] += 1

    return counts

# 对每条输出编码
for r in results:
    if r.get("text"):
        counts = code_rpu(r["text"])
        r["rpu"] = counts
        total = counts["R"] + counts["P"] + counts["U"]
        r["rpu_r_ratio"] = counts["R"] / total if total > 0 else 0
        r["rpu_weighted"] = (counts["R"] * 1 + counts["P"] * 0.5) / total if total > 0 else 0
        r["rpu_total"] = total

# 按条件汇总R/P/U
rpu_summary = {}
for cond in ["C1", "C2", "C3", "C4"]:
    cr = [r for r in results if r["condition"] == cond and "rpu" in r]
    if not cr:
        continue

    total_R = sum(r["rpu"]["R"] for r in cr)
    total_P = sum(r["rpu"]["P"] for r in cr)
    total_U = sum(r["rpu"]["U"] for r in cr)
    total_all = total_R + total_P + total_U

    r_ratios = [r["rpu_r_ratio"] for r in cr]
    w_ratios = [r["rpu_weighted"] for r in cr]

    import statistics
    rpu_summary[cond] = {
        "R": total_R, "P": total_P, "U": total_U, "total": total_all,
        "r_ratio": total_R / total_all,
        "w_ratio": (total_R * 1 + total_P * 0.5) / total_all,
        "r_ratio_avg": sum(r_ratios) / len(r_ratios),
        "r_ratio_std": statistics.stdev(r_ratios) if len(r_ratios) > 1 else 0,
    }

print(f"\n{'条件':<12} {'R':>6} {'P':>6} {'U':>6} {'总计':>6} {'R比例':>8} {'加权比例':>8} {'σ(R)':>6}")
print("-" * 60)
for cond in ["C1", "C2", "C3", "C4"]:
    if cond in rpu_summary:
        s = rpu_summary[cond]
        print(f"{cond} {COND_LABELS[cond]:<6} {s['R']:>6} {s['P']:>6} {s['U']:>6} {s['total']:>6} {s['r_ratio']:>7.1%} {s['w_ratio']:>9.1%} {s['r_ratio_std']:>6.3f}")

# 关键对比
print("\n--- 关键对比 (R/P/U) ---")
c1_rr = rpu_summary["C1"]["r_ratio"]
c4_rr = rpu_summary["C4"]["r_ratio"]
c2_rr = rpu_summary["C2"]["r_ratio"]
c3_rr = rpu_summary["C3"]["r_ratio"]

print(f"  C1 vs C4 ΔR: {c1_rr-c4_rr:+.1%}  (C1是C4的{c1_rr/c4_rr:.1f}倍)")
print(f"  C1 vs C2 ΔR: {c1_rr-c2_rr:+.1%}  (C1是C2的{c1_rr/c2_rr:.1f}倍)")
print(f"  C3 vs C1 ΔR: {c3_rr-c1_rr:+.1%}")
print(f"  C2 vs C4 ΔR: {c2_rr-c4_rr:+.1%}")
print(f"  C1 R比例稳定性: σ={rpu_summary['C1']['r_ratio_std']:.3f}")

# ============================================================
# 3. PER-QUESTION BREAKDOWN
# ============================================================
print("\n" + "=" * 80)
print("📊 按问题×条件分解 (R比例)")
print("=" * 80)
for qid in ["Q1", "Q2", "Q3", "Q4"]:
    qr = [r for r in results if r["question_id"] == qid and "rpu" in r]
    title = qr[0]["question_title"] if qr else qid
    print(f"\n{qid} ({title}):")
    for cond in ["C1", "C2", "C3", "C4"]:
        cr = [r for r in qr if r["condition"] == cond]
        if not cr:
            continue
        r_vals = [r["rpu_r_ratio"] for r in cr]
        avg_r = sum(r_vals)/len(r_vals)
        # Bar chart
        bar = "█" * int(avg_r * 50)
        print(f"  {cond} ({COND_LABELS[cond]:<6}): R={avg_r:.1%} {bar}")

# ============================================================
# 4. SAVE ENRICHED RESULTS
# ============================================================
# Remove text to keep file manageable, keep rpu counts
save_results = []
for r in results:
    sr = {k: v for k, v in r.items() if k != "text"}
    save_results.append(sr)

enriched_file = os.path.join(OUTPUT_DIR, "results_enriched.json")
with open(enriched_file, "w", encoding="utf-8") as f:
    json.dump(save_results, f, ensure_ascii=False, indent=2)

# Save summary
summary_data = {
    "speed_tokens": {},
    "rpu_summary": rpu_summary,
}
for cond in ["C1", "C2", "C3", "C4"]:
    cr = [r for r in results if r["condition"] == cond]
    ttfb = [r["ttfb_ms"] for r in cr if r.get("ttfb_ms")]
    total = [r["total_time_ms"] for r in cr]
    inp = [r["input_tokens"] for r in cr if r.get("input_tokens")]
    outp = [r["output_tokens"] for r in cr if r.get("output_tokens")]
    summary_data["speed_tokens"][cond] = {
        "ttfb_avg": sum(ttfb)/len(ttfb) if ttfb else 0,
        "ttfb_captured": len(ttfb),
        "total_n": len(cr),
        "total_avg": sum(total)/len(total),
        "input_avg": sum(inp)/len(inp) if inp else 0,
        "output_avg": sum(outp)/len(outp) if outp else 0,
    }

summary_file = os.path.join(OUTPUT_DIR, "analysis_summary.json")
with open(summary_file, "w", encoding="utf-8") as f:
    json.dump(summary_data, f, ensure_ascii=False, indent=2)

print(f"\n📁 分析数据已保存: {enriched_file}")
print(f"📁 摘要已保存: {summary_file}")
print("\n✅ 分析完成")
