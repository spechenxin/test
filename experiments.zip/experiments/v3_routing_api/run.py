"""
V3域分类实验 — API真实调用版
4跨域题 × 4条件(C1正确/C2无/C3错误/C4伪) × 10轮 = 160次API调用
测量: TTFB, 总时间, input/output tokens, 完整输出文本
模型: DeepSeek V4 Pro (Anthropic兼容API)
"""

import httpx
import asyncio
import time
import json
import os
from datetime import datetime

API_KEY = os.environ.get("ANTHROPIC_API_KEY", "sk-8d69425407474284afbf9278c948b6a7")
API_BASE = os.environ.get("ANTHROPIC_BASE_URL", "https://api.deepseek.com/anthropic")
API_URL = f"{API_BASE}/v1/messages"
MODEL = os.environ.get("ANTHROPIC_MODEL", "deepseek-v4-pro[1m]")
OUTPUT_DIR = "D:/document/infinite/experiments/v3_routing_api"
MAX_TOKENS = 1024  # 足够实质性回答，保持速度可控

# ============================================================
# 4道跨域问题 + 域框架定义
# ============================================================
QUESTIONS = [
    {
        "id": "Q1",
        "title": "15分钟生活圈",
        "question": "某一线城市推出'15分钟生活圈'规划，要求所有居民步行15分钟内可达基本公共服务（医疗、教育、商业）。请分析该政策的可行性，评估主要障碍和关键成功条件。",
        "correct_domains": (
            "城乡规划学(0833): 空间布局约束、用地性质、设施分布标准、路网密度\n"
            "社会学(0303): 社区动力学、利益相关方行为模式、服务均等化的社会维度\n"
            "区域经济学(0202): 公共资源空间配置效率、成本收益结构、规模经济门槛\n"
            "公共管理学(1204): 政策可行性评估、治理结构、实施机制"
        ),
        "wrong_domains": (
            "计算机算法(0812): 图论最短路径、NP-hard支配集问题、贪心/遗传算法选址优化、时间复杂度分析\n"
            "计算数学(0701): 运筹学k-center问题、设施选址数学模型、约束优化"
        ),
    },
    {
        "id": "Q2",
        "title": "AI医疗诊断",
        "question": "评估AI辅助医疗影像诊断在中国三甲医院大规模推广的可行性。请分析技术成熟度、制度障碍、经济可行性和社会接受度四个维度。",
        "correct_domains": (
            "临床医学(1002): 诊断准确率(灵敏度/特异度/PPV)、不同场景下的临床效用、假阴性/假阳性后果\n"
            "智能科学与技术(1405): AI模型泛化能力、跨设备鲁棒性、训练数据分布偏差\n"
            "公共管理学(1204): 医疗器械审批监管(三类证)、收费编码与医保支付、法律责任归属\n"
            "卫生经济学(0202): 医院采购ROI、DRG/DIP支付改革下的成本效益、替代/补充效应"
        ),
        "wrong_domains": (
            "市场营销(1202): B2B技术产品渗透策略、品牌定位、KOL学术营销、采购决策单元分析、创新扩散S曲线\n"
            "新闻传播学(0503): 舆论引导、公众科学传播、意见领袖背书"
        ),
    },
    {
        "id": "Q3",
        "title": "直播带货县域农产品",
        "question": "分析直播带货对中西部县域农产品供应链的结构性影响。请评估其对生产者收入、中间商角色、冷链物流和区域品牌形成的长期效应。",
        "correct_domains": (
            "农业经济学(0202): 农产品定价权、流通环节利润分配、生产者剩余变化\n"
            "供应链管理(1201): 冷链物流瓶颈、产地仓处理能力、瞬时流量冲击下的履约\n"
            "市场营销(1202): 渠道结构变迁、品牌依附性、流量议价权\n"
            "农村社会学(0303): 县域劳动力结构变化、'新农人'群体、合作社组织能力"
        ),
        "wrong_domains": (
            "计算机视觉(0812): 农产品图像品质检测、色域失真对购买意愿的影响、AR虚拟试吃\n"
            "信息与通信工程(0810): 视频编码压缩、直播延迟优化、带宽适配"
        ),
    },
    {
        "id": "Q4",
        "title": "老旧小区加装电梯",
        "question": "城市老旧小区加装电梯面临业主意见不统一、资金筹措困难、施工技术复杂等多重障碍。请分析这些障碍的深层原因，并提出系统性的破解路径。",
        "correct_domains": (
            "物权法学(0301): 建筑物共有部分处分规则、《民法典》第278条表决门槛、少数业主救济权\n"
            "公共管理学(1204): 行政审批协调、基层治理能力、'一站式'服务窗口机制\n"
            "城市经济学(0202): 加装电梯的成本分摊与房价重分布、低层业主补偿定价、长期维护融资\n"
            "社会学(0303): 社区协商机制、老年居民支付能力、出租户vs自住户的利益分化"
        ),
        "wrong_domains": (
            "机械工程(0802): 曳引/液压电梯参数选型、井道钢结构设计、振动频率传导、新旧基础沉降差异\n"
            "工程力学(0801): 风荷载计算(GB50009)、抗震设防、连接节点应力分析"
        ),
    },
]

COND_LABELS = {"C1": "正确路由", "C2": "无路由", "C3": "错误路由", "C4": "伪路由"}


def build_messages(question_obj, condition):
    """
    构建 messages。
    C1: 域路由框架 — 提供正确域的分析框架(非角色扮演)
    C2: 无 system prompt — 裸提问
    C3: 域路由框架 — 提供错误域的分析框架
    C4: 伪路由 — 泛化"专家"但无具体域框架
    """
    q = question_obj["question"]

    if condition == "C1":
        system = (
            "分析以下问题时，请运用以下学科分析框架进行推衍：\n\n"
            f"{question_obj['correct_domains']}\n\n"
            "推理要求：\n"
            "1. 每个核心断言必须给出可观测的物质对应物（数字、百分比、价格、法律条文编号、可测量物理量）\n"
            "2. 不可使用缺乏物质定义的抽象概念作为推理前提\n"
            "3. 分析必须覆盖问题涉及的多个维度"
        )
    elif condition == "C2":
        system = None
    elif condition == "C3":
        system = (
            "分析以下问题时，请运用以下学科分析框架进行推衍：\n\n"
            f"{question_obj['wrong_domains']}\n\n"
            "推理要求：\n"
            "1. 每个核心断言必须给出可观测的物质对应物（数字、百分比、公式、参数、技术指标）\n"
            "2. 不可使用缺乏物质定义的抽象概念作为推理前提\n"
            "3. 分析必须覆盖问题涉及的多个维度"
        )
    elif condition == "C4":
        system = (
            "你是一位在多个领域拥有深厚造诣的资深专家。"
            "请以专家的身份，深入、全面地分析以下问题。"
        )
    else:
        raise ValueError(f"Unknown condition: {condition}")

    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": q})
    return messages


async def run_single(client, messages, label, max_retries=2):
    """单次API调用，测量TTFB/总时间/Token/文本"""
    for attempt in range(max_retries + 1):
        try:
            start_time = time.time()
            ttfb = None
            full_text = ""
            usage = {}
            input_tokens_est = None

            async with client.stream(
                "POST",
                API_URL,
                headers={
                    "x-api-key": API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": MODEL,
                    "max_tokens": MAX_TOKENS,
                    "messages": messages,
                    "stream": True,
                },
                timeout=120.0,
            ) as response:
                if response.status_code != 200:
                    body = await response.aread()
                    raise Exception(f"HTTP {response.status_code}: {body[:300]}")

                async for line in response.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str.strip() == "[DONE]":
                        break
                    try:
                        event = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue

                    etype = event.get("type", "")

                    if etype == "message_start":
                        msg = event.get("message", {})
                        u = msg.get("usage", {})
                        if u.get("input_tokens"):
                            input_tokens_est = u["input_tokens"]
                    elif etype == "content_block_delta":
                        delta_text = event.get("delta", {}).get("text", "")
                        if ttfb is None and delta_text:
                            ttfb = time.time() - start_time
                        full_text += delta_text
                    elif etype == "message_delta":
                        u = event.get("usage", {})
                        if u:
                            usage.update(u)
                    elif etype == "message_stop":
                        if not usage:
                            usage = event.get("usage", {})
                            if not usage:
                                amz = event.get("amazon-bedrock", {}) or {}
                                usage = amz.get("usage", {})

            total_time = time.time() - start_time

            return {
                "label": label,
                "ttfb_ms": round(ttfb * 1000, 1) if ttfb else None,
                "total_time_ms": round(total_time * 1000, 1),
                "input_tokens": usage.get("input_tokens") or input_tokens_est,
                "output_tokens": usage.get("output_tokens"),
                "text": full_text,
                "text_length": len(full_text),
                "attempts": attempt + 1,
                "error": None,
            }

        except Exception as e:
            if attempt < max_retries:
                wait = 2 ** attempt
                await asyncio.sleep(wait)
                continue
            return {
                "label": label,
                "ttfb_ms": None,
                "total_time_ms": round((time.time() - start_time) * 1000, 1),
                "input_tokens": None,
                "output_tokens": None,
                "text": "",
                "text_length": 0,
                "attempts": attempt + 1,
                "error": str(e)[:300],
            }


async def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    ROUNDS = 10
    total_calls = len(QUESTIONS) * 4 * ROUNDS

    print(f"V3域分类实验 — API调用版")
    print(f"模型: {MODEL}")
    print(f"设计: {len(QUESTIONS)}题 × 4条件 × {ROUNDS}轮 = {total_calls}次")
    print(f"max_tokens: {MAX_TOKENS}")
    print("=" * 60)

    all_results = []
    call_idx = 0

    async with httpx.AsyncClient() as client:
        for round_num in range(1, ROUNDS + 1):
            print(f"\n--- Round {round_num}/{ROUNDS} ---")
            for question in QUESTIONS:
                for condition in ["C1", "C2", "C3", "C4"]:
                    messages = build_messages(question, condition)
                    call_idx += 1
                    label = f"R{round_num}_{question['id']}_{condition}"

                    sys_len = sum(len(m.get("content", "")) for m in messages)
                    print(
                        f"[{call_idx}/{total_calls}] {label} "
                        f"({COND_LABELS[condition]})...",
                        end=" ",
                        flush=True,
                    )

                    result = await run_single(client, messages, label)

                    result["round"] = round_num
                    result["question_id"] = question["id"]
                    result["question_title"] = question["title"]
                    result["condition"] = condition
                    result["condition_label"] = COND_LABELS[condition]
                    result["system_chars"] = sys_len

                    all_results.append(result)

                    if result["error"]:
                        print(f"❌ {result['error'][:80]}")
                    else:
                        print(
                            f"✅ TTFB={result['ttfb_ms']}ms "
                            f"Total={result['total_time_ms']}ms "
                            f"in={result['input_tokens']} out={result['output_tokens']}"
                        )

                    await asyncio.sleep(0.8)  # 速度控制

    # ============================================================
    # 保存
    # ============================================================
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    results_file = os.path.join(OUTPUT_DIR, f"results_{timestamp}.json")
    with open(results_file, "w", encoding="utf-8") as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    print(f"\n📁 完整结果: {results_file}")

    # 摘要
    print_summary(all_results)
    return results_file


def print_summary(results):
    errors = [r for r in results if r["error"]]
    valid = [r for r in results if not r["error"]]

    print("\n" + "=" * 60)
    print(f"📊 实验摘要  成功: {len(valid)}  失败: {len(errors)}")
    if errors:
        print(f"   错误: {', '.join(r['label'] for r in errors[:5])}")
    print("=" * 60)

    # 按条件汇总
    print(f"\n{'条件':<12} {'n':>4} {'TTFB avg':>9} {'TTFB min':>9} {'TTFB max':>9} {'Total avg':>9} {'InTok':>6} {'OutTok':>7}")
    print("-" * 70)
    for cond in ["C1", "C2", "C3", "C4"]:
        cr = [r for r in valid if r["condition"] == cond]
        if not cr:
            continue
        n = len(cr)
        ttfb = [r["ttfb_ms"] for r in cr if r["ttfb_ms"]]
        total = [r["total_time_ms"] for r in cr]
        in_t = [r["input_tokens"] for r in cr if r["input_tokens"]]
        out_t = [r["output_tokens"] for r in cr if r["output_tokens"]]

        def avg(lst):
            return sum(lst) / len(lst) if lst else 0

        print(
            f"{cond} {COND_LABELS[cond]:<6} {n:>4}  "
            f"{avg(ttfb):>8.0f}ms  "
            f"{min(ttfb) if ttfb else 0:>8.0f}ms  "
            f"{max(ttfb) if ttfb else 0:>8.0f}ms  "
            f"{avg(total):>8.0f}ms  "
            f"{avg(in_t):>5.0f}  "
            f"{avg(out_t):>6.0f}"
        )

    # C1 vs C4
    c1 = [r for r in valid if r["condition"] == "C1"]
    c4 = [r for r in valid if r["condition"] == "C4"]
    c2 = [r for r in valid if r["condition"] == "C2"]
    if c1 and c4:
        print("\n--- 关键对比 ---")
        for metric, key, unit in [
            ("TTFB", "ttfb_ms", "ms"),
            ("总时间", "total_time_ms", "ms"),
            ("输出Token", "output_tokens", "tokens"),
        ]:
            c1_vals = [r[key] for r in c1 if r[key]]
            c4_vals = [r[key] for r in c4 if r[key]]
            if c1_vals and c4_vals:
                c1_avg = sum(c1_vals) / len(c1_vals)
                c4_avg = sum(c4_vals) / len(c4_vals)
                delta = c1_avg - c4_avg
                delta_pct = (delta / c4_avg * 100) if c4_avg else 0
                print(
                    f"  {metric}: C1={c1_avg:.0f}{unit}  "
                    f"C4={c4_avg:.0f}{unit}  "
                    f"Δ={delta:+.0f}{unit} ({delta_pct:+.1f}%)"
                )


if __name__ == "__main__":
    asyncio.run(main())
